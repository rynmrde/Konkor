# V6.1.5 Urgent Rescue

- Removed the Final-Hours named feature and all calendar/day-selection UI by explicit user request.
- Replaced it with one live current rescue plan driven by actual Room progress, ROI, due reviews and protected SIM gates.
- Exact Tehran exam cutoff remains a safety boundary; no fixed sleep/meal/hygiene/logistics reserve is subtracted.
- Preserved Review, persistent Question Map, structured stimuli, themes, density, motion, text scale 90–140%, focus audio/SFX, haptic, break reminder, mastery/weakness, backup/restore, offline behavior and active-session persistence.
- Frozen V6.1 bank is not modified by this overlay.
- CI hardening: bounded 4 GiB Gradle heap / 2 workers to prevent D8 dex-merge OOM on GitHub-hosted runners.
