# Changelog — Candidate V6.1.5

## Release-Critical Changes

The Final-Hours scheduler now uses actual time to the Iran exam cutoff and reliable-correct ROI without fixed mandatory sleep, rest, meal, hygiene, or logistics reserves. It retains active-session priority, SIM1/SIM2 protections, holdouts, distinct TRAIN selection, and non-repeating fallback behavior.

The Test and Review surfaces now render canonical immutable structured-stimulus fields, including paired statements, tables, graphs, source-crop routes, and generic non-empty payloads. Review carries the original question context, options, user answer, correct outcome, confidence, reasoning, and distractor information. The persistent Question Map uses session-backed question order, answer, flag, test/review position, and result state for direct navigation.

Room schema v4, non-destructive migrations, backup compatibility, active-session persistence, and SIM-review completion are retained. SIM review witness creation and active-session completion are now committed in one Room transaction.

## Preserved Features

Day Selector, Study Modes, themes, density, motion controls, 90–140% text scaling, focus audio/SFX, haptic/vibration, Break Reminder, Review/error types, mastery/weakness, backup/restore, offline bank behavior, active-session persistence, SIM1/SIM2/FINAL protections, and existing navigation/settings remain in the composed source.

## Intentionally Changed Behavior

Fixed mandatory sleep, rest, meal, hygiene, and logistics reserve logic is removed from Final-Hours scheduling. The optional user-controlled Break Reminder remains available.

## Not Included

No non-reproducible Physics material-bank rewrite or broad authored-bank rewrite is included. No immutable bank asset is intentionally modified by this candidate.
