# V6.1.5 Release Gate Summary

Release is valid only after GitHub Actions passes BANK_FINAL_GATE, live-rescue source/unit gates, Kotlin/JVM/lint/debug build, signed APK + apksigner, packaged frozen-bank inspection, Android API 35 instrumentation, install and launch smoke. Calendar/Day Selector and Final-Hours surfaces are intentionally absent in this build.
