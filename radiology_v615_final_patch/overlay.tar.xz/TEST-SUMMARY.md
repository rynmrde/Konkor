# Konkor V6.1.5 Composed Candidate — Test Summary

> **Status: NOT RELEASEABLE.** This document records observed local evidence only. No APK was built, signed, installed, or published because the immutable V6.1.4 source workspace and packaged bank asset are unavailable in this sandbox while the existing project connection remains disabled.

## Composed Release-Critical Changes

The local candidate combines the attached no-reserve Final-Hours overlay (`4e3111d963da36d80afb90fbcca7bd2629da8cb0bb74ef080774c83ff3725224`) with the attached full-source Review/Question Map overlay (`a6cb639111058858b374f9b744157f91a51f4d240c9decba6828bb55a7d73e6d`). The current candidate preserves Final-Hours version `6.1.5` / code `166`, adds the structured-stimulus Robolectric dependency, retains the Final-Hours repository/selector behavior, and adds only the durable full-question projection required by the Review/Map UI.

| Gate | Observed result | Evidence |
|---|---|---|
| Attached artifact hashes | PASS | Final-Hours and UI/Map archives match the two SHA-256 values stated above. |
| Archive safety | PASS | No symlink or path-traversal entry found in either attached archive. |
| No-reserve Final-Hours static gate | PASS | `tests/verify_final_hours_v615.py` returned `PASS — V6.1.5 Final-Hours source gate` on the composed source. |
| Fixed-reserve UI wording | PASS | Stale mandatory sleep and fixed-count presentation strings were removed; only user-controlled Break Reminder remains. |
| Full Review / structured stimulus source | PASS at source level | UI candidate provides canonical immutable stimulus parsing, Review context, all-21 paired witness coverage, Chemistry structured-witness coverage, RTL, and 90–140% typography tests. |
| Persistent Question Map source | PASS at source level | Composed `SessionSummary` projects durable question order; final repository keeps persisted test/review positions and Room-backed map reconstruction. |
| Atomic SIM review completion | PASS at source level | `markSimulationReviewed()` and session phase completion are wrapped in one `database.withTransaction`. |
| Feature preservation scan | PASS at source level | Day Selector, Study Modes, themes, density, motion, typography, Break Reminder, audio/SFX/haptic controller, backup/restore, offline BankStore, active session, and SIM references remain present. |
| Kotlin / JVM / lint / debug APK | NOT RUN | Complete Gradle root, wrapper, Android SDK, and immutable source workspace are absent. |
| BANK_FINAL_GATE | FAIL / BLOCKED | `tests/validate_v6_1.py` fails before validation because `app/src/main/assets/radiology1405_bank_v6_1.db.gz` is absent. |
| Packaged APK bank inspection | NOT RUN | No APK can be produced without the missing base asset/workspace. |
| Signed APK / apksigner | NOT RUN | No buildable workspace or signing artifact. |
| API 35 instrumentation / install / launch | NOT RUN | No buildable workspace or Android device/emulator. |

## BANK_FINAL_GATE

| Required check | Result | Basis |
|---|---|---|
| Accepted release-critical corrections landed | PARTIAL | Structured-stimulus rendering, UI Review/Map, and no-reserve scheduler source were staged. No scientific material-bank rewrite was accepted. |
| Rejected/unverified material bank rewrites excluded | PASS at source staging | The rejected non-reproducible Physics bank rewrite was not included in the local candidate. |
| Stable IDs, active 4-option/key validation, 17 verified real_exam, 16 quarantined conflicts | BLOCKED | Requires the missing immutable packaged bank and composed APK inspection. |
| SIM holdout disjointness / no holdout leak | BLOCKED | Requires the missing bank asset and selector execution. |
| Normal-block duplicate prevention / unique mastery | PASS at source level; runtime blocked | Final-Hours static gate passes and final selection source is retained; empirical selector trials need the bank. |
| Canonical stimulus fields rendered without bank mutation | PASS at source level | `Models.kt` reads the immutable stimulus JSON and UI renders it; no bank asset is present or rewritten. |
| Packaged APK bank hash/count/schema | BLOCKED | No packaged APK or immutable bank asset is available. |
| Migration/progress mapping for changed bank records | N/A / safe at source staging | No material bank record was accepted or changed in this candidate. Room migration v4 source remains present. |

> **Release decision:** FAIL. The candidate must not be signed or released until a checksum-verified full V6.1.4 workspace with the immutable bank is restored, the composed tree is built, and the blocked bank, APK, runtime, and signing gates have observed PASS outputs.

## Intentional Behavior Change

The only intentionally changed user-facing scheduling behavior is removal of fixed mandatory sleep, rest, meal, hygiene, and logistics reserves. Scheduling must use actual time to exam cutoff and ROI. Existing Break Reminder and all other V6.1.4 user-facing capabilities remain preserved.

## Exact Current Blocker

The existing project connection repeatedly returns `server is disabled`; project instructions prohibit bypassing it with a standalone GitHub or Drive route. The local sandbox contains only overlays, not the full V6.1.4 source workspace, immutable bank asset, Gradle root/wrapper, Android SDK, or signing material.

