#!/usr/bin/env python3
"""Standalone runtime-asset verification for the reconstructed V6.1 bank.

Content identity is pinned by the official V6.1 JSON SHA in CI. This verifier
checks that the exact DB/GZIP bytes referenced by BankStore are packaged and
that their logical V6.1 contracts remain intact.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import pathlib
import re
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSET = ROOT / "app/src/main/assets/radiology1405_bank_v6_1.db.gz"
BANKSTORE = ROOT / "app/src/main/java/com/radiology1405/prep/data/BankStore.kt"
OFFICIAL_JSON_SHA = "54f349cbcd731b89d440d2f9486c2126efef564b57f223082610a344913b263d"


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def expected_hashes() -> tuple[str, str]:
    text = BANKSTORE.read_text(encoding="utf-8")
    db = re.search(r'EXPECTED_DB_SHA256\s*=\s*"([0-9a-f]{64})"', text)
    gz = re.search(r'EXPECTED_GZIP_SHA256\s*=\s*"([0-9a-f]{64})"', text)
    assert db and gz, "BankStore runtime hashes missing"
    return db.group(1), gz.group(1)


expected_db, expected_gz = expected_hashes()
assert ASSET.is_file() and ASSET.stat().st_size > 0
assert sha(ASSET) == expected_gz, "packaged gzip differs from BankStore pin"

with tempfile.NamedTemporaryFile(suffix=".db") as tmp:
    with gzip.open(ASSET, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            tmp.write(block)
    tmp.flush()
    db_path = pathlib.Path(tmp.name)
    assert sha(db_path) == expected_db, "expanded DB differs from BankStore pin"
    db = sqlite3.connect(tmp.name)
    assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    assert db.execute("SELECT COUNT(*) FROM question").fetchone()[0] == 1216
    counts = dict(db.execute("SELECT source_type, COUNT(*) FROM question GROUP BY source_type"))
    assert counts == {
        "authored": 1112,
        "official_exam_stem_training": 71,
        "quarantined_key_conflict": 16,
        "real_exam": 17,
    }
    pools = dict(db.execute("SELECT access_pool, COUNT(*) FROM question GROUP BY access_pool"))
    assert pools == {"FINAL": 10, "QUARANTINE": 16, "SIM1": 117, "SIM2": 117, "TRAIN": 956}
    blueprints = json.loads(db.execute("SELECT json FROM bank_root WHERE key='simulation_blueprints'").fetchone()[0])
    sim1, sim2, final = (set(blueprints[key]["question_ids"]) for key in ("SIM1", "SIM2", "FINAL"))
    assert len(sim1) == 117 and len(sim2) == 117 and len(final) == 10
    assert not sim1 & sim2 and not sim1 & final and not sim2 & final
    rows = db.execute("SELECT full_json FROM question").fetchall()
    assert len(rows) == 1216
    ids = set()
    for (raw,) in rows:
        q = json.loads(raw)
        ids.add(q["id"])
        assert len(q.get("options") or []) == 4
        if q.get("access_pool") in {"SIM1", "SIM2", "FINAL"}:
            assert q.get("source_type") == "authored"
            assert q.get("eligible_for_safety_evidence") is True
            assert q.get("needs_human_review") is False
    assert len(ids) == 1216
    db.close()

print("PASS: V6.1 packaged asset hashes, SQLite integrity, counts and pool isolation")
print("OFFICIAL_V61_JSON_SHA=", OFFICIAL_JSON_SHA)
