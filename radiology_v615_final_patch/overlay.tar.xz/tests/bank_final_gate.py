#!/usr/bin/env python3
"""Release-critical immutable-bank validation for the assembled V6.1.5 candidate."""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
import pathlib
import re
import sqlite3
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSET = ROOT / "app/src/main/assets/radiology1405_bank_v6_1.db.gz"
OUT = ROOT / "build/release-gates"
OUT.mkdir(parents=True, exist_ok=True)
DB = OUT / "bank-final-gate.db"
EXPECTED_GZ = "b5f47e9803638a37798be398ff4a087f336aafa78470e6f5ad94ac3aa5d7fe14"
EXPECTED_DB = "d63219dd6f1621644df495f6b195763924b5c282961cfecf544f7541ab3b673c"

def sha(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def norm(value: object) -> str:
    return re.sub(r"\s+", " ", json.dumps(value, ensure_ascii=False, sort_keys=True).casefold()).strip()

def fail(label: str, detail: object) -> None:
    print(f"FAIL {label}: {json.dumps(detail, ensure_ascii=False, sort_keys=True)}")
    raise SystemExit(1)

def require(label: str, ok: bool, detail: object) -> None:
    if not ok:
        fail(label, detail)
    print(f"PASS {label}")

require("frozen gzip asset hash", sha(ASSET) == EXPECTED_GZ, {"observed": sha(ASSET), "expected": EXPECTED_GZ})
with gzip.open(ASSET, "rb") as src, DB.open("wb") as dst:
    while True:
        block = src.read(1024 * 1024)
        if not block:
            break
        dst.write(block)
require("expanded SQLite hash", sha(DB) == EXPECTED_DB, {"observed": sha(DB), "expected": EXPECTED_DB})

con = sqlite3.connect(DB)
con.row_factory = sqlite3.Row
require("SQLite integrity", con.execute("PRAGMA integrity_check").fetchone()[0] == "ok", {})
tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
require("bank schema tables", {"question", "bank_root"} <= tables, sorted(tables))
rows = list(con.execute("SELECT id, full_json FROM question ORDER BY id"))
root_rows = {r[0]: json.loads(r[1]) for r in con.execute("SELECT key, json FROM bank_root")}
questions = [json.loads(r["full_json"]) for r in rows]
ids = [q.get("id") for q in questions]
require("1,216 stable unique IDs", len(questions) == len(set(ids)) == 1216, {"count": len(questions), "unique": len(set(ids))})
require("SQLite IDs match JSON IDs", set(ids) == {r["id"] for r in rows}, {})
source_counts = collections.Counter(q.get("source_type") for q in questions)
pool_counts = collections.Counter(q.get("access_pool") for q in questions)
require("source-type counts", source_counts == {"authored":1112,"real_exam":17,"official_exam_stem_training":71,"quarantined_key_conflict":16}, dict(source_counts))
require("access-pool counts", pool_counts == {"TRAIN":956,"SIM1":117,"SIM2":117,"FINAL":10,"QUARANTINE":16}, dict(pool_counts))
bad_options = [q["id"] for q in questions if len(q.get("options") or []) != 4 or any(not str(x).strip() for x in q.get("options") or [])]
bad_keys = [q["id"] for q in questions if not isinstance(q.get("correct_index"), int) or q["correct_index"] not in range(4)]
require("exactly four non-empty options", not bad_options, bad_options[:20])
require("correct keys in option range", not bad_keys, bad_keys[:20])
real = [q for q in questions if q.get("source_type") == "real_exam"]
quarantine = [q for q in questions if q.get("source_type") == "quarantined_key_conflict"]
require("17 verified real_exam records", len(real) == 17 and all(q.get("official_origin") is True for q in real), [q["id"] for q in real if q.get("official_origin") is not True])
q_bad = [q["id"] for q in quarantine if q.get("access_pool") != "QUARANTINE" or q.get("eligible_for_training") is not False or q.get("eligible_for_safety_evidence") is not False]
require("16 quarantined key-conflict records isolated", len(quarantine) == 16 and not q_bad, q_bad)
by_id = {q["id"]:q for q in questions}
blueprints = root_rows.get("simulation_blueprints")
require("simulation blueprint present", isinstance(blueprints, dict), type(blueprints).__name__)
pools = {name:set(blueprints[name]["question_ids"]) for name in ("SIM1","SIM2","FINAL")}
require("SIM pool sizes", (len(pools["SIM1"]),len(pools["SIM2"]),len(pools["FINAL"])) == (117,117,10), {k:len(v) for k,v in pools.items()})
require("holdout and FINAL disjointness", not (pools["SIM1"] & pools["SIM2"] or pools["SIM1"] & pools["FINAL"] or pools["SIM2"] & pools["FINAL"]), {"sim1_sim2":sorted(pools["SIM1"] & pools["SIM2"]),"sim1_final":sorted(pools["SIM1"] & pools["FINAL"]),"sim2_final":sorted(pools["SIM2"] & pools["FINAL"])})
sim_bad = [qid for pool, members in pools.items() for qid in members if qid not in by_id or by_id[qid].get("access_pool") != pool or by_id[qid].get("source_type") != "authored" or by_id[qid].get("needs_human_review") or by_id[qid].get("eligible_for_safety_evidence") is not True]
require("holdout member eligibility", not sim_bad, sim_bad[:20])
fp = collections.defaultdict(list)
for q in questions:
    stimulus = dict(q.get("stimulus") or {})
    for key in ("source_crop_data_uri","source_crop_sha256","source_crop_asset","crop_metadata","source_file","source_page","display_contract","alt_text"):
        stimulus.pop(key, None)
    fp[(norm(stimulus),norm(q.get("stem")),norm(q.get("options")))].append(q["id"])
duplicates = [v for v in fp.values() if len(v)>1]
require("no exact active-bank duplicate identity", not duplicates, duplicates[:10])
java = "\n".join(p.read_text(encoding="utf-8") for p in (ROOT/"app/src/main/java").rglob("*.kt"))
required_source = {
    "normal-block duplicate signature": all(token in java for token in ("practiceSignature", "excludedPracticeSignatures", "distinctAlternative")),
    "persistent map session projection": "SessionSummary" in java and "questionIdsJson" in java and "QuestionMap" in java,
    "review structured-stimulus rendering": all(token in java for token in ("TestQuestion", "ReviewQuestion", "stimulusJson")),
    "no destructive Room fallback": "fallbackToDestructiveMigration" not in java,
}
require("duplicate/session/mastery source contracts", all(required_source.values()), required_source)
summary = {"gzip_sha256":sha(ASSET),"sqlite_sha256":sha(DB),"questions":len(questions),"source_counts":dict(source_counts),"pool_counts":dict(pool_counts),"real_exam":len(real),"quarantine":len(quarantine),"sim_sizes":{k:len(v) for k,v in pools.items()},"exact_duplicates":duplicates,"source_contracts":required_source}
(OUT/"BANK_FINAL_GATE.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print("BANK_FINAL_GATE=PASS")
con.close()
