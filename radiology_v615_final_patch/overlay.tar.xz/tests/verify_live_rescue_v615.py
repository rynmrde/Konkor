#!/usr/bin/env python3
"""Deterministic source gate for the V6.1.5 Live Rescue overlay.

This gate is intentionally structural. Behaviour is covered by LiveRescuePlannerTest;
this script verifies that the delivery overlay still contains the required integration
surfaces without opening or mutating the frozen bank.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(path: str, *needles: str) -> None:
    target = ROOT / path
    if not target.is_file():
        raise SystemExit(f"missing required file: {path}")
    text = target.read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            raise SystemExit(f"{path}: missing required evidence: {needle}")


def forbid(path: str, *needles: str) -> None:
    text = (ROOT / path).read_text(encoding="utf-8")
    for needle in needles:
        if needle in text:
            raise SystemExit(f"{path}: forbidden stale rescue rule: {needle}")


def main() -> None:
    require(
        "app/src/main/java/com/radiology1405/prep/engine/LiveRescuePlanner.kt",
        'ZoneId.of("Asia/Tehran")',
        "EXAM_INSTANT",
        "availableStudyMinutes",
        "actual remaining whole minutes until the exam cutoff",
        "uniqueTrainingQuestions",
        "reviewRepeats",
        "simulationQuestions",
        "activeSession",
        "sim1UnrepairedTopics",
        "SIM2",
        "EXTRA_TIME_C",
        "ExtraTimeCWitness",
        "extraTimeCWitness",
        "MIXED_DIAGNOSTIC",
    )
    forbid(
        "app/src/main/java/com/radiology1405/prep/engine/LiveRescuePlanner.kt",
        "468",
        "ZoneId.systemDefault()",
        "PROTECTED_SLEEP_MINUTES",
        "PROTECTED_LOGISTICS_MINUTES",
        "NEW_PREREQUISITE_CUTOFF_MINUTES",
        "SLEEP_AND_LOGISTICS",
        "RecommendationKind.REST",
    )
    require(
        "app/src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt",
        "version = 4",
        "MIGRATION_3_4",
        "reviewedEpochMs",
        "markSimulationReviewed",
        "addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)",
    )
    require(
        "app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt",
        "LiveRescuePlanner.decide",
        "liveRescueDecisionInternal",
        "unresolvedSim1Topics",
        "markSimulationReviewed",
        "liveRescue=${decision.kind.name}",
        "No distinct eligible TRAIN questions remain",
        "ids.distinct().size == ids.size",
    )
    forbid(
        "app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt",
        "Exact repeat is a last resort",
        "poolIds(\"TRAIN\", allowedTopics",
        "stage=$stage",
    )
    forbid(
        "app/src/main/java/com/radiology1405/prep/engine/RescuePlanner.kt",
        "fun dayPlans(",
        "fun nextStage(",
        "secondaryUnlocked",
        "extraUnlocked",
    )
    require(
        "app/src/test/java/com/radiology1405/prep/engine/LiveRescuePlannerTest.kt",
        "iranTimezoneAndMidnightUseActualExamCountdownWithoutForcedReserve",
        "noForcedSleepOrLogisticsReserveBeforeActualExamCutoff",
        "roomShapedAttempts",
        "sim2RequiresReviewedSim1",
        "noTimingEvidencePreservesSim2",
        "activeSessionAlwaysResumes",
        "historicalABCTierDoesNotGate",
        "reviewedButUnrepairedSim1",
        "extraTimeC",
    )
    print("PASS — V6.1.5 Live Rescue source gate")


if __name__ == "__main__":
    main()
