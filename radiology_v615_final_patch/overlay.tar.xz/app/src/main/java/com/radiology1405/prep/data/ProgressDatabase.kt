package com.radiology1405.prep.data

import android.content.Context
import androidx.room.Dao
import androidx.room.ColumnInfo
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "active_session")
data class ActiveSessionEntity(
    @PrimaryKey val name: String,
    val date: String,
    val mode: String,
    val pool: String,
    val phase: String,
    val questionIdsJson: String,
    val position: Int,
    val reviewPosition: Int,
    val answersJson: String,
    val confidenceJson: String,
    val optionOrdersJson: String,
    val flagsJson: String,
    val elapsedJson: String,
    val analysesSeenJson: String,
    val errorTypesJson: String,
    val startedEpochMs: Long,
    val updatedEpochMs: Long,
    val cueShown: Boolean = false,
)

@Entity(
    tableName = "attempt",
    indices = [
        Index("questionId"), Index("microtopic"), Index("createdEpochMs"),
        Index(value = ["sessionName", "questionId"], unique = true),
    ],
)
data class AttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionId: String,
    val sessionName: String,
    val date: String,
    val subject: String,
    val microtopic: String,
    val pool: String,
    val selectedOriginal: Int?,
    val correctIndex: Int,
    val status: String,
    val confidence: String,
    val errorType: String?,
    val solveSeconds: Int,
    @ColumnInfo(defaultValue = "2") val difficulty: Int = 2,
    @ColumnInfo(defaultValue = "''") val scenarioFamily: String = "",
    @ColumnInfo(defaultValue = "0") val strictOrVerifiedReal: Boolean = false,
    @ColumnInfo(defaultValue = "0") val spacedRetrieval: Boolean = false,
    val createdEpochMs: Long,
)

@Entity(tableName = "mastery", indices = [Index("subject"), Index("nextDueEpochMs")])
data class MasteryEntity(
    @PrimaryKey val microtopic: String,
    val subject: String,
    val mastery: Double,
    val memoryStrength: Double,
    val attempts: Int,
    val distinctQuestions: Int,
    val examAttempts: Int,
    val confidentCorrectStreak: Int,
    val recurringError: String?,
    val lastAttemptEpochMs: Long,
    val nextDueEpochMs: Long,
)

@Entity(tableName = "due_credit", indices = [Index("microtopic"), Index("dueEpochMs"), Index("consumed")])
data class DueCreditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val microtopic: String,
    val reason: String,
    val priority: Int,
    val remaining: Int,
    val dueEpochMs: Long,
    val sourceQuestionId: String,
    val createdEpochMs: Long,
    val consumed: Boolean = false,
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val theme: String = ThemeFamily.MIDNIGHT.name,
    val studyMode: String = StudyMode.AGGRESSIVE_SAFETY.name,
    val motion: String = MotionMode.CALM.name,
    val textScale: Int = 100,
    val focusMode: Boolean = true,
    val longStudyMode: Boolean = false,
    val breaksEnabled: Boolean = true,
    val breakEvery: Int = 40,
)

@Entity(tableName = "progress_snapshot")
data class ProgressSnapshotEntity(
    @PrimaryKey val name: String,
    val rawJson: String,
    val sha256: String,
    val updatedEpochMs: Long,
)

@Entity(tableName = "simulation_result")
data class SimulationResultEntity(
    @PrimaryKey val pool: String,
    val date: String,
    val questionIdsJson: String,
    val subjectReliableJson: String,
    val durationSeconds: Int,
    val leakCount: Int,
    val passed: Boolean,
    @ColumnInfo(defaultValue = "'{}'") val remediationJson: String = "{}",
    /** Null means the submitted simulation has not completed its standalone review. */
    val reviewedEpochMs: Long? = null,
)

@Entity(tableName = "legacy_import")
data class LegacyImportEntity(
    @PrimaryKey val id: Int = 1,
    val rawJson: String,
    val status: String,
    val importedEpochMs: Long,
)

@Dao
interface ProgressDao {
    @Query("SELECT * FROM active_session WHERE name=:name LIMIT 1")
    suspend fun activeSession(name: String = "current"): ActiveSessionEntity?

    @Query("SELECT * FROM active_session WHERE name=:name LIMIT 1")
    fun observeActiveSession(name: String = "current"): Flow<ActiveSessionEntity?>

    @Upsert suspend fun upsertSession(session: ActiveSessionEntity)

    @Query("DELETE FROM active_session WHERE name=:name")
    suspend fun deleteSession(name: String = "current")

    @Query("DELETE FROM active_session") suspend fun clearSessions()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempts(attempts: List<AttemptEntity>)

    @Query("SELECT * FROM attempt ORDER BY createdEpochMs DESC")
    suspend fun allAttempts(): List<AttemptEntity>

    @Query("DELETE FROM attempt") suspend fun clearAttempts()

    @Query("SELECT questionId FROM attempt")
    suspend fun attemptedQuestionIds(): List<String>

    @Query("SELECT COUNT(*) FROM attempt WHERE date=:date")
    suspend fun attemptCountForDate(date: String): Int

    @Query("SELECT COUNT(*) FROM attempt WHERE date=:date AND pool='TRAIN'")
    suspend fun trainingAttemptCountForDate(date: String): Int

    @Query("SELECT * FROM attempt WHERE microtopic=:microtopic ORDER BY createdEpochMs DESC")
    suspend fun attemptsFor(microtopic: String): List<AttemptEntity>

    @Query("UPDATE attempt SET errorType=:errorType WHERE sessionName=:sessionName AND questionId=:questionId")
    suspend fun updateAttemptError(sessionName: String, questionId: String, errorType: String?)

    @Upsert suspend fun upsertMastery(mastery: MasteryEntity)

    @Query("SELECT * FROM mastery ORDER BY mastery ASC")
    fun observeMastery(): Flow<List<MasteryEntity>>

    @Query("SELECT * FROM mastery ORDER BY microtopic")
    suspend fun allMastery(): List<MasteryEntity>

    @Query("DELETE FROM mastery") suspend fun clearMastery()

    @Query("SELECT * FROM mastery WHERE microtopic=:microtopic LIMIT 1")
    suspend fun mastery(microtopic: String): MasteryEntity?

    @Insert suspend fun insertCredits(credits: List<DueCreditEntity>)

    @Query("SELECT * FROM due_credit WHERE consumed=0 AND dueEpochMs<=:now ORDER BY priority DESC, dueEpochMs ASC LIMIT :limit")
    suspend fun dueCredits(now: Long, limit: Int): List<DueCreditEntity>

    @Query("SELECT COUNT(*) FROM due_credit WHERE consumed=0 AND microtopic=:microtopic")
    suspend fun openCreditCount(microtopic: String): Int

    @Query("UPDATE due_credit SET consumed=1 WHERE id IN (:ids)")
    suspend fun consumeCredits(ids: List<Long>)

    @Query("SELECT * FROM due_credit ORDER BY id")
    suspend fun allCredits(): List<DueCreditEntity>

    @Query("DELETE FROM due_credit") suspend fun clearCredits()

    @Query("SELECT * FROM app_settings WHERE id=1 LIMIT 1")
    fun observeSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id=1 LIMIT 1")
    suspend fun settings(): AppSettingsEntity?

    @Query("DELETE FROM app_settings") suspend fun clearSettings()

    @Upsert suspend fun upsertSettings(settings: AppSettingsEntity)

    @Upsert suspend fun upsertSnapshot(snapshot: ProgressSnapshotEntity)

    @Query("SELECT * FROM progress_snapshot WHERE name=:name LIMIT 1")
    suspend fun snapshot(name: String): ProgressSnapshotEntity?

    @Upsert suspend fun upsertSimulation(result: SimulationResultEntity)

    @Query("SELECT * FROM simulation_result ORDER BY date")
    fun observeSimulations(): Flow<List<SimulationResultEntity>>

    @Query("SELECT * FROM simulation_result ORDER BY date")
    suspend fun simulations(): List<SimulationResultEntity>

    @Query("UPDATE simulation_result SET reviewedEpochMs=:reviewedEpochMs WHERE pool=:pool")
    suspend fun markSimulationReviewed(pool: String, reviewedEpochMs: Long)

    @Query("DELETE FROM simulation_result") suspend fun clearSimulations()

    @Upsert suspend fun upsertLegacyImport(value: LegacyImportEntity)

    @Query("DELETE FROM legacy_import") suspend fun clearLegacyImport()

    @Query("SELECT * FROM legacy_import WHERE id=1 LIMIT 1")
    suspend fun legacyImport(): LegacyImportEntity?

    @Transaction
    suspend fun persistSubmittedSession(
        session: ActiveSessionEntity,
        attempts: List<AttemptEntity>,
        mastery: List<MasteryEntity>,
        credits: List<DueCreditEntity>,
    ) {
        insertAttempts(attempts)
        mastery.forEach { upsertMastery(it) }
        if (credits.isNotEmpty()) insertCredits(credits)
        upsertSession(session)
    }
}

@Database(
    entities = [
        ActiveSessionEntity::class, AttemptEntity::class, MasteryEntity::class,
        DueCreditEntity::class, AppSettingsEntity::class, ProgressSnapshotEntity::class,
        SimulationResultEntity::class, LegacyImportEntity::class,
    ],
    version = 4,
    exportSchema = true,
)
abstract class ProgressDatabase : RoomDatabase() {
    abstract fun progressDao(): ProgressDao

    companion object {
        private const val NAME = "radiology1405_progress_v6.db"

        /**
         * V1 was used by the internal V6 prototype.  The migration is explicit and never
         * falls back to destructive recreation, so a future packaged prototype is safe.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE active_session ADD COLUMN cueShown INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS simulation_result (" +
                        "pool TEXT NOT NULL PRIMARY KEY, date TEXT NOT NULL, " +
                        "questionIdsJson TEXT NOT NULL, subjectReliableJson TEXT NOT NULL, " +
                        "durationSeconds INTEGER NOT NULL, leakCount INTEGER NOT NULL, passed INTEGER NOT NULL)"
                )
            }
        }

        /** V6.1 adds evidence needed for mastery caps and a persisted post-simulation remediation map. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE attempt ADD COLUMN difficulty INTEGER NOT NULL DEFAULT 2")
                db.execSQL("ALTER TABLE attempt ADD COLUMN scenarioFamily TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE attempt ADD COLUMN strictOrVerifiedReal INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attempt ADD COLUMN spacedRetrieval INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE simulation_result ADD COLUMN remediationJson TEXT NOT NULL DEFAULT '{}'")
            }
        }

        /** V6.1.5 keeps every existing row and adds an explicit independent-review witness for SIM gating. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE simulation_result ADD COLUMN reviewedEpochMs INTEGER")
            }
        }

        @Volatile private var instance: ProgressDatabase? = null

        fun get(context: Context): ProgressDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, ProgressDatabase::class.java, NAME)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
                .build()
                .also { instance = it }
        }
    }
}
