package com.radiology1405.prep.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistence-side contract for the Question Map. It deliberately holds no question wording,
 * options, or UI labels: the bank and the presentation module remain their respective sources
 * of truth. The active Room session already persists answers, flags, current positions, and phase,
 * so no second mutable map state is needed.
 */
enum class QuestionMapResult { CORRECT, WRONG, BLANK }

data class PersistedQuestionMapEntry(
    val questionId: String,
    val selectedOriginalIndex: Int?,
    val isFlagged: Boolean,
    val result: QuestionMapResult?,
)

data class PersistedQuestionMapSnapshot(
    val selectedQuestionId: String,
    val submitted: Boolean,
    val entries: List<PersistedQuestionMapEntry>,
) {
    init {
        require(entries.isNotEmpty()) { "Question Map needs at least one question." }
        require(entries.map { it.questionId }.distinct().size == entries.size) { "Question Map IDs must be unique." }
        require(entries.any { it.questionId == selectedQuestionId }) { "Selected Question Map ID is missing." }
    }

    fun indexOf(questionId: String): Int = entries.indexOfFirst { it.questionId == questionId }
        .also { require(it >= 0) { "Question ID is not in this persisted session." } }
}

/** Converts persisted session state into a UI-neutral map snapshot, including review outcomes. */
object QuestionMapSessionProjection {
    fun snapshot(session: ActiveSessionEntity, attempts: List<AttemptEntity>): PersistedQuestionMapSnapshot {
        val ids = stringList(session.questionIdsJson)
        require(ids.isNotEmpty()) { "Active session has no Question Map IDs." }
        require(ids.distinct().size == ids.size) { "Active session contains duplicate Question Map IDs." }
        val answers = JSONObject(session.answersJson)
        val flags = JSONObject(session.flagsJson)
        val submitted = session.phase in setOf("review", "done")
        val outcomes = if (submitted) attempts
            .filter { it.sessionName == sessionKey(session) }
            .associate { attempt -> attempt.questionId to attempt.status.asMapResult() }
        else emptyMap()
        val selectedIndex = if (submitted) session.reviewPosition else session.position
        val selectedId = ids[selectedIndex.coerceIn(0, ids.lastIndex)]
        return PersistedQuestionMapSnapshot(
            selectedQuestionId = selectedId,
            submitted = submitted,
            entries = ids.map { id ->
                PersistedQuestionMapEntry(
                    questionId = id,
                    selectedOriginalIndex = if (answers.has(id)) answers.optInt(id) else null,
                    isFlagged = flags.optBoolean(id),
                    result = outcomes[id],
                )
            },
        )
    }

    fun sessionKey(session: ActiveSessionEntity): String = "${session.date}-${session.pool}-${session.startedEpochMs}"

    private fun stringList(raw: String): List<String> {
        val array = JSONArray(raw)
        return List(array.length()) { index -> array.getString(index) }
    }

    private fun String.asMapResult(): QuestionMapResult = when (this) {
        "correct" -> QuestionMapResult.CORRECT
        "wrong" -> QuestionMapResult.WRONG
        else -> QuestionMapResult.BLANK
    }
}
