package com.radiology1405.prep.engine

import com.radiology1405.prep.data.Confidence
import kotlin.math.roundToInt

enum class RescueTier(val fa: String) {
    A("A — تسلط اجباری"),
    B("B — مشروط"),
    C("C — فقط وقت اضافه"),
    Q("Q — قرنطینه"),
}

data class RescueProfile(
    val subject: String,
    val microtopic: String,
    val expectedQuestions: Double,
    val recentFrequency: Double,
    val historicalFrequency: Double,
    val stability: Double,
    val learningMinutes: Int,
    val prerequisiteCost: Int,
    val averageDifficulty: Int,
    val errorRisk: Double,
    val trapRisk: Int,
    val calculationLoad: Int,
    val masteryProbability11Days: Double,
    val safeTrainQuestions: Int,
)

data class RescueTopic(
    val profile: RescueProfile,
    val tier: RescueTier,
    val adjustedLearningMinutes: Int,
    val masteryProbability3Days: Double,
    val retentionProbability: Double,
    val expectedReliableCorrectGain: Double,
    val reliableGainPerMinute: Double,
)

data class RescueMetrics(
    val baselineMicrotopics: Int,
    val mandatoryMicrotopics: Int,
    val secondaryMicrotopics: Int,
    val lowPriorityMicrotopics: Int,
    val quarantinedMicrotopics: Int,
    val baselineQuestionBudget: Int,
    val mandatoryQuestionBudget: Int,
    val baselineStudyMinutes: Int,
    val mandatoryStudyMinutes: Int,
    val baselineRawCoverage: Double,
    val mandatoryRawCoverage: Double,
    val baselineReliableGain: Double,
    val mandatoryReliableGain: Double,
) {
    val mandatoryScopeReductionPercent = percent(baselineMicrotopics - mandatoryMicrotopics, baselineMicrotopics)
    val lowPriorityPercent = percent(lowPriorityMicrotopics, baselineMicrotopics)
    val questionBudgetReductionPercent = percent(baselineQuestionBudget - mandatoryQuestionBudget, baselineQuestionBudget)
    val studyTimeReductionPercent = percent(baselineStudyMinutes - mandatoryStudyMinutes, baselineStudyMinutes)
    val rawCoverageReductionPercent = percent(baselineRawCoverage - mandatoryRawCoverage, baselineRawCoverage)
    val reliableGainReductionPercent = percent(baselineReliableGain - mandatoryReliableGain, baselineReliableGain)

    companion object {
        private fun percent(part: Int, total: Int): Double = if (total == 0) 0.0 else 100.0 * part / total
        private fun percent(part: Double, total: Double): Double = if (total == 0.0) 0.0 else 100.0 * part / total
    }
}

data class TeachingEvidence(
    val level: String,
    val status: String,
    val confidence: String,
)

object RescuePlanner {
    const val MANDATORY_LEARNING_MINUTE_CEILING = 900
    const val SECONDARY_GAIN_PER_MINUTE_FLOOR = 0.0087

    // Exact budgets from the frozen V6.1 eight-day plan and the executable three-day plan.
    const val BASELINE_STUDY_MINUTES = 5_955
    const val RESCUE_STUDY_MINUTES = 1_950
    const val BASELINE_QUESTION_BUDGET = 544
    const val RESCUE_QUESTION_BUDGET = 354

    private val initialKnowledge = mapOf(
        "زیست" to 0.58,
        "شیمی" to 0.45,
        "فیزیک" to 0.26,
        "ریاضی" to 0.14,
        "زمین" to 0.18,
    )
    private val learningTimeFactor = mapOf(
        "زیست" to 0.78,
        "شیمی" to 0.88,
        "فیزیک" to 1.12,
        "ریاضی" to 1.25,
        "زمین" to 0.68,
    )

    fun triage(profiles: List<RescueProfile>): List<RescueTopic> {
        val scored = profiles.map(::score).sortedWith(
            compareByDescending<RescueTopic> { it.reliableGainPerMinute }
                .thenBy { it.profile.microtopic }
        )
        var mandatoryMinutes = 0
        return scored.map { topic ->
            val tier = when {
                topic.profile.safeTrainQuestions == 0 -> RescueTier.Q
                topic.profile.safeTrainQuestions >= 3 &&
                    mandatoryMinutes + topic.adjustedLearningMinutes <= MANDATORY_LEARNING_MINUTE_CEILING -> {
                    mandatoryMinutes += topic.adjustedLearningMinutes
                    RescueTier.A
                }
                topic.profile.safeTrainQuestions >= 2 &&
                    topic.reliableGainPerMinute >= SECONDARY_GAIN_PER_MINUTE_FLOOR -> RescueTier.B
                else -> RescueTier.C
            }
            topic.copy(tier = tier)
        }
    }

    private fun score(profile: RescueProfile): RescueTopic {
        val prior = initialKnowledge.getValue(profile.subject)
        val timeFactor = learningTimeFactor.getValue(profile.subject)
        val knowledgeFactor = 0.72 + 0.45 * prior
        val complexityFactor = 1.0 -
            0.035 * (profile.prerequisiteCost - 1).coerceAtLeast(0) -
            0.022 * (profile.calculationLoad - 1).coerceAtLeast(0) -
            0.018 * (profile.averageDifficulty - 2).coerceAtLeast(0) -
            0.025 * (profile.errorRisk - 0.5).coerceAtLeast(0.0) -
            0.010 * (profile.trapRisk - 3).coerceAtLeast(0)
        val mastery3 = (profile.masteryProbability11Days * knowledgeFactor * complexityFactor * 0.96)
            .coerceIn(0.12, 0.90)
        val retention = (0.82 + 0.14 * profile.stability + 0.025 * prior).coerceIn(0.72, 0.96)
        // expectedQuestions already carries the official frequency forecast. Recent and
        // historical observations therefore calibrate confidence slightly, rather than
        // being counted a second time as another full frequency multiplier.
        val frequencyEvidence = 0.70 * profile.recentFrequency + 0.30 * profile.historicalFrequency
        val frequencyCalibration = 0.995 + 0.010 * frequencyEvidence / (frequencyEvidence + 2.0)
        val adjustedMinutes = (
            profile.learningMinutes * timeFactor *
                (1.0 + 0.035 * (profile.prerequisiteCost - 1).coerceAtLeast(0) +
                    0.025 * (profile.calculationLoad - 1).coerceAtLeast(0))
            ).roundToInt().coerceAtLeast(1)
        val gain = profile.expectedQuestions * frequencyCalibration * mastery3 * retention
        return RescueTopic(
            profile = profile,
            tier = RescueTier.C,
            adjustedLearningMinutes = adjustedMinutes,
            masteryProbability3Days = mastery3,
            retentionProbability = retention,
            expectedReliableCorrectGain = gain,
            reliableGainPerMinute = gain / adjustedMinutes,
        )
    }

    fun metrics(topics: List<RescueTopic>): RescueMetrics {
        fun List<RescueTopic>.sumCoverage() = sumOf { it.profile.expectedQuestions }
        fun List<RescueTopic>.sumGain() = sumOf { it.expectedReliableCorrectGain }
        val mandatory = topics.filter { it.tier == RescueTier.A }
        return RescueMetrics(
            baselineMicrotopics = topics.size,
            mandatoryMicrotopics = mandatory.size,
            secondaryMicrotopics = topics.count { it.tier == RescueTier.B },
            lowPriorityMicrotopics = topics.count { it.tier == RescueTier.C },
            quarantinedMicrotopics = topics.count { it.tier == RescueTier.Q },
            baselineQuestionBudget = BASELINE_QUESTION_BUDGET,
            mandatoryQuestionBudget = RESCUE_QUESTION_BUDGET,
            baselineStudyMinutes = BASELINE_STUDY_MINUTES,
            mandatoryStudyMinutes = RESCUE_STUDY_MINUTES,
            baselineRawCoverage = topics.sumCoverage(),
            mandatoryRawCoverage = mandatory.sumCoverage(),
            baselineReliableGain = topics.sumGain(),
            mandatoryReliableGain = mandatory.sumGain(),
        )
    }

    fun preferredTeachingLevels(evidence: List<TeachingEvidence>): List<String> {
        if (evidence.isEmpty()) return listOf("L1_DIRECT")
        val recent = evidence.first()
        if (recent.status != "correct" || recent.confidence != Confidence.CONFIDENT.name) {
            return listOf("L2_CONCEPT", "L1_DIRECT")
        }
        val confidentSimple = evidence.count {
            it.level in setOf("L1_DIRECT", "L2_CONCEPT") &&
                it.status == "correct" && it.confidence == Confidence.CONFIDENT.name
        }
        if (confidentSimple >= 2) {
            return listOf("L3_TRAP", "L4_TRANSFER", "L5_STRICT_EXAM", "L6_VERIFIED_REAL")
        }
        val completed = evidence.filter { it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }.map { it.level }.toSet()
        return when {
            "L1_DIRECT" !in completed -> listOf("L1_DIRECT")
            "L2_CONCEPT" !in completed -> listOf("L2_CONCEPT", "L3_TRAP")
            "L3_TRAP" !in completed -> listOf("L3_TRAP", "L4_TRANSFER")
            "L4_TRANSFER" !in completed -> listOf("L4_TRANSFER", "L5_STRICT_EXAM")
            "L5_STRICT_EXAM" !in completed -> listOf("L5_STRICT_EXAM", "L6_VERIFIED_REAL")
            else -> listOf("L6_VERIFIED_REAL", "L4_TRANSFER", "L5_STRICT_EXAM")
        }
    }
}
