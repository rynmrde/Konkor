package com.radiology1405.prep.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit

private const val LRI = '\u2066'
private const val PDI = '\u2069'

private val scienceRun = Regex(
    "[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪|]+(?:[ \\t]*[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪]+)*"
)

/** Unicode bidi isolation keeps formula direction intact inside a Persian paragraph. */
fun isolateScientificRuns(value: String): String = scienceRun.replace(value) { match ->
    "$LRI${match.value}$PDI"
}

fun removeScientificIsolates(value: String): String = value.replace(LRI.toString(), "").replace(PDI.toString(), "")

@Composable
fun ScienceText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = LocalContentColor.current,
    fontSize: TextUnit = TextUnit.Unspecified,
    style: TextStyle? = null,
    textAlign: TextAlign? = null,
) {
    Text(
        text = isolateScientificRuns(text),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        style = style ?: LocalTextStyle.current,
        textAlign = textAlign,
    )
}
