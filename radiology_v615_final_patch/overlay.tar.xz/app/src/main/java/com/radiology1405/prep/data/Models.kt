package com.radiology1405.prep.data

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

enum class ThemeFamily(val fa: String) {
    MIDNIGHT("نیمه‌شب آبی"), OLED("OLED مشکی"), GRAPHITE("تاریک نرم"), EMERALD("جنگلی"),
    VIOLET("بنفش"), ICE("یخی"), SUNSET("غروب"), WARM("شب گرم"), LIGHT("کاغذ روشن"), CONTRAST("کنتراست بالا");

    companion object {
        fun fromStored(value: String): ThemeFamily = when (value) {
            "SOFT_DARK", "soft", "graphite", "GRAPHITE" -> GRAPHITE
            "WARM_NIGHT", "warm", "WARM" -> WARM
            "PAPER_WARM", "paper", "light", "LIGHT" -> LIGHT
            "HIGH_CONTRAST", "contrast", "CONTRAST" -> CONTRAST
            "oled", "OLED" -> OLED
            "midnight", "MIDNIGHT" -> MIDNIGHT
            "forest", "emerald", "EMERALD" -> EMERALD
            "violet", "VIOLET" -> VIOLET
            "ice", "ICE" -> ICE
            "sunset", "SUNSET" -> SUNSET
            else -> entries.firstOrNull { it.name == value } ?: MIDNIGHT
        }
    }
}

enum class StudyMode(val fa: String) {
    BALANCED_SMART("هوشمند متعادل"), AGGRESSIVE_SAFETY("ایمنی تهاجمی"), DEEP_FOCUS("تمرکز عمیق"), HARD_EXAM("آزمون سخت")
}

enum class MotionMode(val fa: String) {
    MINIMAL("حداقلی"), CALM("آرام"), DYNAMIC("پویا"), LIVELY("سرزنده بدون چشمک")
}

enum class Confidence(val fa: String) { CONFIDENT("مطمئن"), UNSURE("نامطمئن") }

data class SubjectOutcome(val correct: Int, val wrong: Int, val blank: Int)
data class SessionOutcome(
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val total: Int,
    val bySubject: Map<String, SubjectOutcome>,
)

enum class ErrorType(val key: String, val fa: String) {
    KNOWLEDGE_GAP("knowledge_gap", "کمبود دانش"),
    FORGOTTEN_RULE("forgotten_rule", "فراموشی قاعده"),
    CALCULATION_ERROR("calculation_error", "خطای محاسبات"),
    MISREAD("misread", "بدخوانی سؤال"),
    TRAP("trap", "افتادن در دام"),
    TIME_MANAGEMENT("time_management", "مدیریت زمان"),
    CARELESS_ERROR("careless_error", "بی‌دقتی")
}

data class SourceCrop(
    val dataUri: String,
    val altText: String,
    val sha256: String,
)

/** Canonical paired statements stored in the immutable question stimulus payload. */
data class StatementStimulus(
    val left: String,
    val right: String,
)

private fun normalizedPracticeText(value: String): String =
    Normalizer.normalize(value, Normalizer.Form.NFKC)
        .replace('ي', 'ی')
        .replace('ك', 'ک')
        .lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}+−-]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

private val nonSemanticStemFrames = listOf(
    "داده‌های زیر را با مدل مناسب پیوند دهید. کدام مقدار پس از کنترل واحد و شرط به‌دست می‌آید؟",
    "برای حل مسئلهٔ زیر، کدام پاسخ نهایی با مسیر کنترل درست جفت شده است؟",
).map(::normalizedPracticeText)

private fun practiceCoreStem(value: String): String =
    nonSemanticStemFrames.fold(normalizedPracticeText(value)) { core, frame -> core.replace(frame, "").trim() }

private fun normalizedStimulusSignature(raw: String?): String {
    if (raw.isNullOrBlank()) return ""
    return runCatching {
        val stimulus = JSONObject(raw)
        for (key in listOf("source_crop_data_uri", "source_crop_sha256", "source_crop_asset", "crop_metadata", "source_file", "source_page", "display_contract", "alt_text")) {
            stimulus.remove(key)
        }
        normalizedPracticeText(stimulus.toString())
    }.getOrDefault(normalizedPracticeText(raw))
}

data class Question(
    val id: String,
    val subject: String,
    val microtopic: String,
    val sourceType: String,
    val sourceFile: String?,
    val sourcePage: Int?,
    val difficulty: Int,
    val estimatedSeconds: Int,
    val questionForm: String,
    val scenarioFamily: String,
    val stem: String,
    val options: List<String>,
    val correctIndex: Int,
    val correctAnalysis: String,
    val optionAnalyses: Map<Int, String>,
    val shortLesson: String,
    val fastMethod: String,
    val mainTrap: String,
    val teachingLevel: String,
    val accessPool: String,
    val needsHumanReview: Boolean,
    val eligibleForSafetyEvidence: Boolean,
    val strictOrVerifiedReal: Boolean,
    val sourceCrop: SourceCrop?,
    val statementStimulus: StatementStimulus? = null,
    /** Original immutable stimulus payload; presentation derives only from its canonical fields. */
    val stimulusJson: String? = null,
) {
    /** Same-block identity: stem plus the complete canonical structured stimulus; short stems also include unordered options. */
    val practiceSignature: String
        get() {
            val content = listOf(practiceCoreStem(stem), normalizedStimulusSignature(stimulusJson))
                .filter { it.isNotBlank() }
                .joinToString("||")
            return if (content.length >= 24) content
            else "$content||${options.map(::normalizedPracticeText).sorted().joinToString("||")}" 
        }

    companion object {
        fun fromJson(raw: String): Question {
            val o = JSONObject(raw)
            val optionsArray = o.getJSONArray("options")
            val options = buildList { for (i in 0 until optionsArray.length()) add(optionsArray.getString(i)) }
            require(options.size == 4) { "Question ${o.optString("id")} does not have four options" }
            val analysesObject = o.getJSONObject("distractor_analyses")
            val analyses = (0..3).associateWith { analysesObject.optString(it.toString()) }
            val stimulus = o.optJSONObject("stimulus")
            val crop = if (stimulus?.optString("type") == "official_source_crop") {
                SourceCrop(
                    dataUri = stimulus.optString("source_crop_data_uri"),
                    altText = stimulus.optString("alt_text"),
                    sha256 = stimulus.optString("source_crop_sha256"),
                )
            } else null
            val statements = stimulus?.optJSONObject("statements") ?: stimulus ?: o.optJSONObject("paired_statements")
            fun statementValue(vararg keys: String): String? = keys.asSequence()
                .map { statements?.optString(it).orEmpty().trim() }
                .firstOrNull { it.isNotEmpty() }
            val pairedStatements = statementValue("left", "statement_a", "a")?.let { left ->
                statementValue("right", "statement_b", "b")?.let { right -> StatementStimulus(left, right) }
            }
            return Question(
                id = o.getString("id"),
                subject = o.getString("subject"),
                microtopic = o.getString("microtopic"),
                sourceType = o.getString("source_type"),
                sourceFile = o.optString("source_file").takeIf { it.isNotBlank() && it != "null" },
                sourcePage = o.optInt("source_page", -1).takeIf { it >= 0 },
                difficulty = o.optInt("difficulty", 2),
                estimatedSeconds = o.optInt("estimated_solve_time_seconds", 90),
                questionForm = o.optString("question_form"),
                scenarioFamily = o.optString("scenario_family", o.optString("scenario_model")),
                stem = o.getString("stem"),
                options = options,
                correctIndex = o.getInt("correct_index"),
                correctAnalysis = o.getString("correct_analysis"),
                optionAnalyses = analyses,
                shortLesson = o.getString("short_lesson"),
                fastMethod = o.optString("fast_method", o.optString("start_method")),
                mainTrap = o.optString("main_trap"),
                teachingLevel = o.optString("teaching_ladder_level"),
                accessPool = o.optString("access_pool", "TRAIN"),
                needsHumanReview = o.optBoolean("needs_human_review", false),
                eligibleForSafetyEvidence = o.optBoolean("eligible_for_safety_evidence", true),
                strictOrVerifiedReal = o.optString("teaching_ladder_level") in setOf("L5_STRICT_EXAM", "L6_VERIFIED_REAL") ||
                    (o.optString("source_type") == "real_exam" && o.optBoolean("official_key_verified", true)),
                sourceCrop = crop,
                statementStimulus = pairedStatements,
                stimulusJson = stimulus?.toString(),
            ).also { require(it.correctIndex in 0..3) }
        }
    }
}

data class DayPlan(
    val date: String,
    val day: Int,
    val phase: String,
    val totalStudyMinutes: Int,
    val attemptBudget: Int,
    val microtopics: List<String>,
) {
    companion object {
        fun fromRootJson(raw: String): List<DayPlan> {
            val root = JSONObject(raw)
            return root.keys().asSequence().map { key ->
                val o = root.getJSONObject(key)
                val topics = o.optJSONArray("new_microtopics") ?: JSONArray()
                DayPlan(
                    date = key,
                    day = o.getInt("day"),
                    phase = o.getString("phase"),
                    totalStudyMinutes = o.optInt("total_study_minutes"),
                    attemptBudget = o.optInt("attempt_budget"),
                    microtopics = buildList { for (i in 0 until topics.length()) add(topics.getString(i)) },
                )
            }.sortedBy { it.date }.toList()
        }
    }
}

data class SafetyState(
    val eligible: Boolean,
    val label: String,
    val detail: String,
)
