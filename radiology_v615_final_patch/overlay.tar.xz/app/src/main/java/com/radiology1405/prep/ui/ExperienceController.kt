package com.radiology1405.prep.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.radiology1405.prep.R
import com.radiology1405.prep.engine.AdaptiveEngine
import java.io.Closeable

enum class ReaderFont(val key: String, val fa: String) {
    SYSTEM("system", "سیستمی روان"), READABLE("readable", "Sans خوانا"), BOOK("book", "کتابی / Serif");
    companion object { fun from(value: String) = entries.firstOrNull { it.key == value } ?: SYSTEM }
}

enum class UiDensity(val key: String, val fa: String) {
    COMFORTABLE("comfortable", "راحت"), COMPACT("compact", "فشرده");
    companion object { fun from(value: String) = entries.firstOrNull { it.key == value } ?: COMFORTABLE }
}

enum class HapticStrength(val key: String, val fa: String, val factor: Float) {
    LIGHT("light", "ملایم", .65f), MEDIUM("medium", "متوسط", 1f), STRONG("strong", "قوی", 1.45f);
    companion object { fun from(value: String) = entries.firstOrNull { it.key == value } ?: MEDIUM }
}

data class ExperienceSettings(
    val sfxEnabled:Boolean=true,
    val sfxVolume:Int=45,
    val hapticsEnabled:Boolean=true,
    val hapticStrength:String=HapticStrength.MEDIUM.key,
    val readerFont:String=ReaderFont.SYSTEM.key,
    val density:String=UiDensity.COMFORTABLE.key,
    val focusTrack:String="none",
    val focusVolume:Int=35,
    val adhdMode:Boolean=true,
    val reducedMotion:Boolean=false,
    val highContrast:Boolean=false,
    val keepAwake:Boolean=true,
    val focusMinutes:Int=25,
)

class ExperienceController(context:Context):Closeable {
    private val app=context.applicationContext
    private val prefs=app.getSharedPreferences("radiology1405_experience_v61",Context.MODE_PRIVATE)
    var settings by mutableStateOf(load()); private set
    var focusPlaying by mutableStateOf(false); private set
    var focusTimerRunning by mutableStateOf(false); private set
    var focusRemainingSeconds by mutableStateOf(settings.focusMinutes*60); private set
    var focusError by mutableStateOf<String?>(null); private set
    var breakRevision by mutableStateOf(0); private set

    private val vibrator=app.getSystemService(Vibrator::class.java)
    private val soundPool=SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val loadedSounds=mutableSetOf<Int>()
    private val sounds:Map<String,Int>
    private var focusPlayer:MediaPlayer?=null

    init {
        soundPool.setOnLoadCompleteListener { _, sampleId, status -> if(status==0) loadedSounds += sampleId }
        sounds=mapOf(
            "select" to soundPool.load(app,R.raw.sfx_select,1), "submit" to soundPool.load(app,R.raw.sfx_submit,1),
            "correct" to soundPool.load(app,R.raw.sfx_correct,1), "wrong" to soundPool.load(app,R.raw.sfx_wrong,1),
            "complete" to soundPool.load(app,R.raw.sfx_complete,1), "focus_start" to soundPool.load(app,R.raw.sfx_focus_start,1),
            "focus_end" to soundPool.load(app,R.raw.sfx_focus_end,1))
    }

    private fun load()=ExperienceSettings(
        sfxEnabled=prefs.getBoolean("sfx",true), sfxVolume=prefs.getInt("sfxVolume",45).coerceIn(0,100),
        hapticsEnabled=prefs.getBoolean("haptics",true), hapticStrength=prefs.getString("hapticStrength",HapticStrength.MEDIUM.key)?:HapticStrength.MEDIUM.key,
        readerFont=prefs.getString("readerFont",ReaderFont.SYSTEM.key)?:ReaderFont.SYSTEM.key,
        density=prefs.getString("density",UiDensity.COMFORTABLE.key)?:UiDensity.COMFORTABLE.key,
        focusTrack=prefs.getString("focusTrack","none")?:"none", focusVolume=prefs.getInt("focusVolume",35).coerceIn(0,100),
        adhdMode=prefs.getBoolean("adhd",true), reducedMotion=prefs.getBoolean("reducedMotion",false), highContrast=prefs.getBoolean("highContrast",false),
        keepAwake=prefs.getBoolean("keepAwake",true), focusMinutes=prefs.getInt("focusMinutes",25).coerceIn(10,90))

    private fun persist(next:ExperienceSettings){
        settings=next
        prefs.edit().putBoolean("sfx",next.sfxEnabled).putInt("sfxVolume",next.sfxVolume)
            .putBoolean("haptics",next.hapticsEnabled).putString("hapticStrength",next.hapticStrength).putString("readerFont",next.readerFont).putString("density",next.density)
            .putString("focusTrack",next.focusTrack).putInt("focusVolume",next.focusVolume)
            .putBoolean("adhd",next.adhdMode).putBoolean("reducedMotion",next.reducedMotion).putBoolean("highContrast",next.highContrast)
            .putBoolean("keepAwake",next.keepAwake).putInt("focusMinutes",next.focusMinutes).apply()
        applyFocusVolume(next.focusVolume)
    }

    fun setSfxEnabled(v:Boolean)=persist(settings.copy(sfxEnabled=v))
    fun previewSfxVolume(v:Int){ settings=settings.copy(sfxVolume=v.coerceIn(0,100)) }
    fun setSfxVolume(v:Int)=persist(settings.copy(sfxVolume=v.coerceIn(0,100)))
    fun setHapticsEnabled(v:Boolean)=persist(settings.copy(hapticsEnabled=v))
    fun setHapticStrength(v:String)=persist(settings.copy(hapticStrength=HapticStrength.from(v).key))
    fun setReaderFont(v:String)=persist(settings.copy(readerFont=ReaderFont.from(v).key))
    fun setDensity(v:String)=persist(settings.copy(density=UiDensity.from(v).key))
    fun setAdhdMode(v:Boolean)=persist(settings.copy(adhdMode=v))
    fun setReducedMotion(v:Boolean)=persist(settings.copy(reducedMotion=v))
    fun setHighContrast(v:Boolean)=persist(settings.copy(highContrast=v))
    fun setKeepAwake(v:Boolean)=persist(settings.copy(keepAwake=v))
    fun previewFocusVolume(v:Int){ val n=v.coerceIn(0,100); settings=settings.copy(focusVolume=n); applyFocusVolume(n) }
    fun setFocusVolume(v:Int)=persist(settings.copy(focusVolume=v.coerceIn(0,100)))
    fun setFocusMinutes(v:Int){ if(focusTimerRunning)return; val n=v.coerceIn(10,90); persist(settings.copy(focusMinutes=n)); focusRemainingSeconds=n*60 }

    fun dueBreak(date:String, completed:Int, every:Int):Int? {
        val ackDate=prefs.getString("breakAckDate","")?:""
        val ackBoundary=if(ackDate==date) prefs.getInt("breakAckBoundary",0) else 0
        return AdaptiveEngine.breakBoundary(completed,every,if(ackBoundary>0)setOf(ackBoundary) else emptySet())
            ?.takeIf { it > ackBoundary }
    }

    fun acknowledgeBreak(date:String,boundary:Int){
        prefs.edit().putString("breakAckDate",date).putInt("breakAckBoundary",boundary).apply()
        breakRevision++
    }

    fun setFocusTrack(v:String, autoPreview:Boolean=true){
        if(v !in setOf("none","ambient","rain","brown","pulse"))return
        stopFocus(false)
        persist(settings.copy(focusTrack=v))
        focusError=null
        if(autoPreview && v!="none") startFocus(false)
    }

    fun playSfx(name:String){
        if(!settings.sfxEnabled)return
        val id=sounds[name]?:return
        val v=settings.sfxVolume/100f
        val stream=if(id in loadedSounds) soundPool.play(id,v,v,1,0,1f) else 0
        if(stream==0){
            val tone=when(name){"wrong"->ToneGenerator.TONE_PROP_NACK;"correct","complete"->ToneGenerator.TONE_PROP_ACK;else->ToneGenerator.TONE_PROP_BEEP}
            runCatching { ToneGenerator(AudioManager.STREAM_MUSIC,settings.sfxVolume.coerceIn(0,100)).also { tg -> tg.startTone(tone,110); android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({tg.release()},180) } }
        }
    }

    fun haptic(ms:Long=28){
        if(!settings.hapticsEnabled||vibrator==null||!vibrator.hasVibrator())return
        val factor=HapticStrength.from(settings.hapticStrength).factor
        val duration=(ms*factor).toLong().coerceIn(10,110)
        vibrator.vibrate(VibrationEffect.createOneShot(duration,VibrationEffect.DEFAULT_AMPLITUDE))
    }

    fun startPauseTimer(){
        if(focusTimerRunning){ focusTimerRunning=false; stopFocus(false); return }
        if(focusRemainingSeconds<=0) focusRemainingSeconds=settings.focusMinutes*60
        focusTimerRunning=true; playSfx("focus_start"); haptic(28); if(settings.focusTrack!="none") startFocus(false)
    }
    fun resetTimer(){ focusTimerRunning=false; focusRemainingSeconds=settings.focusMinutes*60; stopFocus(false); haptic(16) }
    fun tickTimer(){ if(!focusTimerRunning)return; focusRemainingSeconds=(focusRemainingSeconds-1).coerceAtLeast(0); if(focusRemainingSeconds==0){ focusTimerRunning=false; stopFocus(false); playSfx("focus_end"); haptic(45) } }
    fun toggleFocus(){ if(focusPlaying) stopFocus() else if(settings.focusTrack!="none") startFocus() }

    private fun focusResource():Int=when(settings.focusTrack){"ambient"->R.raw.focus_ambient;"rain"->R.raw.focus_rain;"pulse"->R.raw.focus_pulse;else->R.raw.focus_brown}
    private fun applyFocusVolume(value:Int){ val v=value.coerceIn(0,100)/100f; runCatching{focusPlayer?.setVolume(v,v)} }

    private fun startFocus(playStart:Boolean=true){
        if(settings.focusTrack=="none")return
        stopFocus(false)
        focusError=null
        runCatching {
            val afd=app.resources.openRawResourceFd(focusResource()) ?: error("فایل صدای تمرکز باز نشد")
            val mp=MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            mp.setDataSource(afd.fileDescriptor,afd.startOffset,afd.length)
            afd.close()
            mp.isLooping=true
            val v=settings.focusVolume/100f;mp.setVolume(v,v)
            mp.setOnErrorListener { _,what,extra -> focusError="خطای پخش $what/$extra";focusPlaying=false;true }
            mp.prepare();mp.start();focusPlayer=mp;focusPlaying=true
            if(playStart){playSfx("focus_start");haptic(24)}
        }.onFailure { e ->
            focusError=e.message?:"پخش صدای تمرکز ناموفق بود"
            runCatching{focusPlayer?.release()};focusPlayer=null;focusPlaying=false
        }
    }
    private fun stopFocus(playEnd:Boolean=true){ val had=focusPlayer!=null; runCatching{focusPlayer?.stop()};runCatching{focusPlayer?.release()};focusPlayer=null;focusPlaying=false;if(had&&playEnd){playSfx("focus_end");haptic(20)} }

    fun resetExperience(){
        stopFocus(false);focusTimerRunning=false;prefs.edit().clear().apply();settings=load();focusRemainingSeconds=settings.focusMinutes*60;focusError=null;breakRevision++
    }

    override fun close(){stopFocus(false);soundPool.release()}
}
