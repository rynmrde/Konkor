package com.radiology1405.prep.ui

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ExperienceSettingsPersistenceTest {
    private lateinit var context: Context

    @Before fun before() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("radiology1405_experience_v61", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test fun densityAndDailyBreakAckSurviveControllerRecreation() {
        var c = ExperienceController(context)
        c.setDensity(UiDensity.COMPACT.key)
        assertEquals(20, c.dueBreak("2026-08-13", 20, 20))
        c.acknowledgeBreak("2026-08-13", 20)
        assertNull(c.dueBreak("2026-08-13", 29, 20))
        c.close()

        c = ExperienceController(context)
        assertEquals(UiDensity.COMPACT.key, c.settings.density)
        assertNull(c.dueBreak("2026-08-13", 39, 20))
        assertEquals(40, c.dueBreak("2026-08-13", 40, 20))
        c.close()
    }
}
