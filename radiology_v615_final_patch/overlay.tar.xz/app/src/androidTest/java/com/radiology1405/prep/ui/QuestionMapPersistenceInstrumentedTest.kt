package com.radiology1405.prep.ui

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.Question
import com.radiology1405.prep.data.SessionSummary
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class QuestionMapPersistenceInstrumentedTest {
    @Test
    fun preSubmitMapUsesDurableCurrentAnswerAndFlagFields() {
        val summary = summary(
            phase = "test",
            position = 0,
            answers = JSONObject().put("q2", 1).toString(),
            flags = JSONObject().put("q3", true).toString(),
        )

        assertEquals(QuestionMapState.CURRENT, questionMapState(summary, 0))
        assertEquals(QuestionMapState.ANSWERED, questionMapState(summary, 1))
        assertEquals(QuestionMapState.FLAGGED, questionMapState(summary, 2))
    }

    @Test
    fun submittedReviewAndRecreatedSummaryRetainMapStateAndPosition() {
        val stored = summary(
            phase = "review",
            reviewPosition = 1,
            answers = JSONObject().put("q1", 1).put("q2", 0).toString(),
        )
        val recreated = summary(
            phase = stored.entity.phase,
            reviewPosition = stored.entity.reviewPosition,
            answers = stored.entity.answersJson,
            flags = stored.entity.flagsJson,
        )

        assertEquals(1, recreated.entity.reviewPosition)
        assertEquals(QuestionMapState.CORRECT, questionMapState(recreated, 0))
        assertEquals(QuestionMapState.WRONG, questionMapState(recreated, 1))
        assertEquals(QuestionMapState.BLANK, questionMapState(recreated, 2))
    }

    private fun summary(
        phase: String,
        position: Int = 0,
        reviewPosition: Int = 0,
        answers: String = "{}",
        flags: String = "{}",
    ): SessionSummary {
        val ids = listOf("q1", "q2", "q3")
        val entity = ActiveSessionEntity(
            name = "current", date = "2026-08-19", mode = "AGGRESSIVE_SAFETY", pool = "TRAIN", phase = phase,
            questionIdsJson = org.json.JSONArray(ids).toString(), position = position, reviewPosition = reviewPosition,
            answersJson = answers, confidenceJson = "{}", optionOrdersJson = "{}", flagsJson = flags, elapsedJson = "{}",
            analysesSeenJson = "{}", errorTypesJson = "{}", startedEpochMs = 1, updatedEpochMs = 2,
        )
        return SessionSummary(entity, questions[position.coerceIn(0, 2)], 0, ids.size, questions)
    }

    private val questions = listOf(question("q1"), question("q2"), question("q3"))

    private fun question(id: String) = Question(
        id = id, subject = "فیزیک", microtopic = "مدل آزمون", sourceType = "authored", sourceFile = null, sourcePage = null,
        difficulty = 2, estimatedSeconds = 60, questionForm = "conceptual", scenarioFamily = "test", stem = "صورت سؤال",
        options = listOf("گزینه ۱", "گزینه ۲", "گزینه ۳", "گزینه ۴"), correctIndex = 1,
        correctAnalysis = "تحلیل", optionAnalyses = (0..3).associateWith { "تحلیل گزینه" }, shortLesson = "نکته",
        fastMethod = "روش", mainTrap = "دام", teachingLevel = "L2_CONCEPT", accessPool = "TRAIN",
        needsHumanReview = false, eligibleForSafetyEvidence = true, strictOrVerifiedReal = false, sourceCrop = null,
    )
}
