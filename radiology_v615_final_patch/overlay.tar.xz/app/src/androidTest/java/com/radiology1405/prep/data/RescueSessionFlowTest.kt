package com.radiology1405.prep.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.ZoneId

@RunWith(AndroidJUnit4::class)
class RescueSessionFlowTest {
    private lateinit var context: Context
    private lateinit var repository: StudyRepository

    @Before fun before() {
        runBlocking {
            context = ApplicationProvider.getApplicationContext()
            repository = StudyRepository(context)
            repository.initialize()
            repository.wipeProgress()
        }
    }

    @After fun after() {
        runBlocking {
            repository.wipeProgress()
            repository.close()
        }
    }

    @Test fun answerReviewReopenResumeAndNoPrematureSim1RemainExact() = runBlocking {
        val now = LocalDate.parse("2026-08-18").atTime(12, 0)
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val first = repository.startOrResume(now)
        assertEquals("TRAIN", first.entity.pool)
        assertTrue(first.total in 1..15)
        val firstIds = JSONArray(first.entity.questionIdsJson)
        assertEquals(first.total, (0 until firstIds.length()).map { firstIds.getString(it) }.toSet().size)
        val firstQuestion = requireNotNull(first.currentQuestion)
        repository.selectOriginal(firstQuestion.id, firstQuestion.correctIndex)
        repository.setConfidence(firstQuestion.id, Confidence.CONFIDENT)
        val review = repository.submit(now + 1_000)
        assertEquals("review", review.entity.phase)
        assertEquals(1, repository.currentOutcome()?.correct)

        val exactAnswers = review.entity.answersJson
        repository.close()
        repository = StudyRepository(context)
        repository.initialize()
        val resumedReview = repository.activeSummary()
        assertNotNull(resumedReview)
        assertEquals("review", resumedReview?.entity?.phase)
        assertEquals(exactAnswers, resumedReview?.entity?.answersJson)
        repository.finishReview()

        val second = repository.startOrResume(now + 2_000)
        assertEquals("TRAIN", second.entity.pool)
        repository.submit(now + 3_000)
        repository.finishReview()

        // Two short adaptive TRAIN blocks are not evidence for the >=60% witnessed-coverage SIM1 gate.
        // Android 35 must prove the repository does not bypass that gate merely because a fixed block count elapsed.
        val third = repository.startOrResume(now + 4_000)
        assertEquals("TRAIN", third.entity.pool)
        assertTrue(third.total in 1..15)
        val thirdIds = JSONArray(third.entity.questionIdsJson)
        assertEquals(third.total, (0 until thirdIds.length()).map { thirdIds.getString(it) }.toSet().size)
        assertTrue(!third.entity.mode.contains("stage=SIM1"))

        val exactThirdSession = JSONObject()
            .put("ids", third.entity.questionIdsJson)
            .put("orders", third.entity.optionOrdersJson)
            .toString()
        repository.close()
        repository = StudyRepository(context)
        repository.initialize()
        val resumedThird = repository.startOrResume(now + 5_000)
        assertEquals(
            exactThirdSession,
            JSONObject().put("ids", resumedThird.entity.questionIdsJson)
                .put("orders", resumedThird.entity.optionOrdersJson).toString(),
        )
    }
}
