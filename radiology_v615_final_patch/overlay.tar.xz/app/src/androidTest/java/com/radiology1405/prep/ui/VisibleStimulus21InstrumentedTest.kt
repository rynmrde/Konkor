package com.radiology1405.prep.ui

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.BankStore
import com.radiology1405.prep.data.Question
import com.radiology1405.prep.data.SessionSummary
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class VisibleStimulus21InstrumentedTest {
    @Test
    fun everyActiveTrainStimulusIsVisibleInTestAndReviewFromCanonicalBankFields() {
        val bank = BankStore(appContext())
        try {
            val questions = bank.activeTrainingQuestionsWithStimulus()
            assertEquals("frozen V6.1.4 active TRAIN witness count", 152, questions.size)
            questions.forEach { question ->
                val normal = testPresentationStimulus(question)
                val review = reviewPresentationStimulus(question)
                assertEquals("Test and Review must use identical canonical stimulus content for ${question.id}", normal, review)
                if (question.sourceCrop != null) {
                    assertTrue("authoritative crop must remain available for ${question.id}", question.sourceCrop.dataUri.isNotBlank())
                } else {
                    assertTrue("meaningful canonical stimulus must render before options for ${question.id}", normal.isNotEmpty())
                    assertTrue("rendered stimulus may not be blank for ${question.id}", normal.all { it.body.isNotBlank() })
                }
                assertTrue("a stimulus-bearing question needs a visible Test or source-crop path for ${question.id}", hasVisibleStructuredStimulus(question))
            }
        } finally {
            bank.close()
        }
    }

    @Test
    fun allTwentyOneComparisonWitnessesRemainVisibleAcrossReviewResume() {
        val bank = BankStore(appContext())
        try {
            val questions = comparison21Ids.map { id -> bank.question(id) ?: error("missing $id") }
            assertEquals(21, questions.size)
            questions.forEach { question ->
                val canonical = question.statementStimulus
                assertNotNull("canonical comparison pair missing for ${question.id}", canonical)
                val normal = testPresentationStimulus(question)
                val review = reviewPresentationStimulus(question)
                assertEquals(normal, review)
                assertTrue("A statement must render for ${question.id}", normal.any { it.body.contains(canonical!!.left) })
                assertTrue("B statement must render for ${question.id}", normal.any { it.body.contains(canonical!!.right) })
            }
            val resumed = reviewSummary(questions)
            val recreated = reviewSummary(
                questions = questions,
                questionIdsJson = resumed.entity.questionIdsJson,
                answersJson = resumed.entity.answersJson,
                reviewPosition = resumed.entity.reviewPosition,
            )
            assertEquals(resumed.entity.questionIdsJson, recreated.entity.questionIdsJson)
            assertEquals(resumed.entity.answersJson, recreated.entity.answersJson)
            recreated.questions.forEachIndexed { index, question ->
                assertEquals(QuestionMapState.CORRECT, questionMapState(recreated, index))
                assertTrue("reopened Review must retain A/B content for ${question.id}", reviewPresentationStimulus(question).size >= 2)
            }
        } finally {
            bank.close()
        }
    }

    @Test
    fun chemistryTableAndComparisonWitnessesAllRenderFromCanonicalFields() {
        val bank = BankStore(appContext())
        try {
            val questions = chemistry16Ids.map { id -> bank.question(id) ?: error("missing $id") }
            assertEquals(16, questions.size)
            questions.forEach { question ->
                val stimulus = JSONObject(question.stimulusJson ?: error("stimulus missing for ${question.id}"))
                assertTrue("Chemistry witness must be a canonical table or comparison for ${question.id}", stimulus.optString("type") in setOf("data_table", "comparison"))
                val normal = testPresentationStimulus(question)
                val review = reviewPresentationStimulus(question)
                assertEquals(normal, review)
                assertTrue("Chemistry canonical premise must render before options for ${question.id}", normal.isNotEmpty() && normal.all { it.body.isNotBlank() })
                when (stimulus.optString("type")) {
                    "data_table" -> {
                        val firstHeader = stimulus.getJSONArray("headers").getString(0)
                        val firstCell = stimulus.getJSONArray("rows").getJSONArray(0).getString(0)
                        assertTrue(normal.any { it.body.contains(firstHeader) && it.body.contains(firstCell) })
                    }
                    "comparison" -> {
                        assertTrue(normal.any { it.body.contains(stimulus.getString("left")) })
                        assertTrue(normal.any { it.body.contains(stimulus.getString("right")) })
                    }
                }
            }
        } finally {
            bank.close()
        }
    }

    private fun reviewSummary(
        questions: List<Question>,
        questionIdsJson: String = JSONArray(questions.map(Question::id)).toString(),
        answersJson: String = JSONObject().also { json -> questions.forEach { json.put(it.id, it.correctIndex) } }.toString(),
        reviewPosition: Int = 11,
    ): SessionSummary {
        val entity = ActiveSessionEntity(
            name = "current", date = "2026-08-19", mode = "AGGRESSIVE_SAFETY", pool = "TRAIN", phase = "review",
            questionIdsJson = questionIdsJson, position = 0, reviewPosition = reviewPosition,
            answersJson = answersJson, confidenceJson = "{}", optionOrdersJson = "{}", flagsJson = "{}", elapsedJson = "{}",
            analysesSeenJson = "{}", errorTypesJson = "{}", startedEpochMs = 100, updatedEpochMs = 200,
        )
        return SessionSummary(entity, questions[reviewPosition], questions.size, questions.size, questions)
    }

    private fun appContext() = InstrumentationRegistry.getInstrumentation().targetContext.applicationContext

    private companion object {
        val comparison21Ids = listOf(
            "v3_bio_02_12", "v3_bio_05_12", "v3_bio_06_07", "v3_bio_07_15", "v3_bio_08_07",
            "v3_bio_10_11", "v3_bio_11_07", "v3_bio_12_07", "v3_bio_14_10", "v3_bio_15_15",
            "v3_bio_16_10", "v3_chem_20_03", "v3_chem_26_03", "v3_chem_54_07", "v3_geo_45_09",
            "v3_geo_46_08", "v3_geo_47_07", "v3_geo_49_08", "v3_phys_30_02", "v3_phys_33_02",
            "v3_phys_34_03",
        )
        val chemistry16Ids = listOf(
            "v3_chem_19_11", "v3_chem_19_12", "v3_chem_19_13", "v3_chem_20_18", "v3_chem_20_19",
            "v3_chem_20_20", "v3_chem_26_10", "v3_chem_26_11", "v3_chem_26_12", "v3_chem_26_13",
            "v3_chem_54_11", "v3_chem_54_12", "v3_chem_54_13", "v3_chem_20_03", "v3_chem_26_03",
            "v3_chem_54_07",
        )
    }
}
