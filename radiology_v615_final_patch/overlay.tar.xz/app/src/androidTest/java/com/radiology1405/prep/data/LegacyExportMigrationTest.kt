package com.radiology1405.prep.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LegacyExportMigrationTest {
    private lateinit var context: Context
    private lateinit var database: ProgressDatabase
    private lateinit var bank: BankStore

    @Before fun before() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, ProgressDatabase::class.java).build()
        bank = BankStore(context)
    }

    @After fun after() { bank.close(); database.close() }

    @Test fun v5ExportPreservesRawAndRebuildsAttemptsAndMastery() = runBlocking {
        val state = JSONObject()
            .put("settings", JSONObject().put("theme", "warm").put("studyProfile", "aggressive"))
            .put("attempts", JSONArray().put(JSONObject()
                .put("question_id", "v3_bio_01_01")
                .put("correct", true)
                .put("blank", false)
                .put("day", 1)
                .put("round", 1)
                .put("date", "2026-08-12")
                .put("answer_original", 0)
                .put("solve_seconds", 52)))
        val raw = JSONObject().put("kind", "radiology1405_progress").put("state", state).toString()
        val status = LegacyProgressImporter(context, database.progressDao(), bank).importExternal(raw)
        assertTrue(status.startsWith("converted"))
        assertEquals(1, database.progressDao().allAttempts().size)
        assertTrue(database.progressDao().allMastery().isNotEmpty())
        assertEquals(raw, database.progressDao().snapshot("legacy_v5_external_raw")?.rawJson)
    }
}
