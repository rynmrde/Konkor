package com.radiology1405.prep.ui

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FocusAudioPlaybackTest {
    private lateinit var context: Context
    private lateinit var controller: ExperienceController

    @Before fun before() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("radiology1405_experience_v61", Context.MODE_PRIVATE).edit().clear().commit()
        controller = ExperienceController(context)
    }

    @After fun after() { controller.close() }

    @Test fun everyBundledFocusTrackCanStartAndStop() {
        listOf("ambient", "rain", "brown", "pulse").forEach { track ->
            controller.setFocusTrack(track, autoPreview = true)
            assertNull("$track error: ${controller.focusError}", controller.focusError)
            assertTrue("$track did not enter playing state", controller.focusPlaying)
            controller.toggleFocus()
            assertTrue("$track did not stop", !controller.focusPlaying)
        }
    }
}
