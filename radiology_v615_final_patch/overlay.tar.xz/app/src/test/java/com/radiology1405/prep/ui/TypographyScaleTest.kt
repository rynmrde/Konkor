package com.radiology1405.prep.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class TypographyScaleTest {
    @Test
    fun reviewAndMapTypographyHonorsNinetyToOneFortyPercentBounds() {
        assertEquals(13.5f, scaledTypography(90).titleSmall.fontSize.value, 0.001f)
        assertEquals(15.3f, scaledTypography(90).bodyLarge.fontSize.value, 0.001f)
        assertEquals(9.9f, scaledTypography(90).labelSmall.fontSize.value, 0.001f)

        assertEquals(21f, scaledTypography(140).titleSmall.fontSize.value, 0.001f)
        assertEquals(23.8f, scaledTypography(140).bodyLarge.fontSize.value, 0.001f)
        assertEquals(15.4f, scaledTypography(140).labelSmall.fontSize.value, 0.001f)
    }

    @Test
    fun typographyScaleClampsOutsideThePersistedUserRange() {
        assertEquals(scaledTypography(90).bodyMedium.fontSize, scaledTypography(10).bodyMedium.fontSize)
        assertEquals(scaledTypography(140).bodyMedium.fontSize, scaledTypography(500).bodyMedium.fontSize)
    }
}
