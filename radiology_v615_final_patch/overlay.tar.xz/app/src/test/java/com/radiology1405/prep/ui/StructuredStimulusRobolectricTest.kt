package com.radiology1405.prep.ui

import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.BankStore
import com.radiology1405.prep.data.Question
import com.radiology1405.prep.data.SessionSummary
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class StructuredStimulusRobolectricTest {
    @Test
    fun exhaustiveActiveTrainingStimuliAreVisibleInCanonicalTestAndReviewAdapters() {
        installFrozenBankForUnitTest()
        val bank = BankStore(RuntimeEnvironment.getApplication())
        try {
            val questions = bank.activeTrainingQuestionsWithStimulus()
            assertEquals(152, questions.size)
            questions.forEach { question ->
                val testBlocks = testPresentationStimulus(question)
                val reviewBlocks = reviewPresentationStimulus(question)
                assertEquals("Test/Review canonical mismatch for ${question.id}", testBlocks, reviewBlocks)
                if (question.sourceCrop == null) {
                    assertTrue("textual structured stimulus missing for ${question.id}", testBlocks.isNotEmpty())
                    assertTrue("blank textual stimulus for ${question.id}", testBlocks.all { it.body.isNotBlank() })
                } else {
                    assertTrue("official source crop missing data for ${question.id}", question.sourceCrop.dataUri.isNotBlank())
                }
                assertTrue("no visible presentation path for ${question.id}", hasVisibleStructuredStimulus(question))
            }
        } finally {
            bank.close()
        }
    }

    @Test
    fun comparison21AndChemistry16WitnessesSurviveReviewSessionRecreation() {
        installFrozenBankForUnitTest()
        val bank = BankStore(RuntimeEnvironment.getApplication())
        try {
            val comparisons = comparison21Ids.map { bank.question(it) ?: error("missing $it") }
            assertEquals(21, comparisons.size)
            comparisons.forEach { question ->
                val canonical = question.statementStimulus ?: error("paired statement missing for ${question.id}")
                val blocks = testPresentationStimulus(question)
                assertTrue(blocks.any { it.body.contains(canonical.left) })
                assertTrue(blocks.any { it.body.contains(canonical.right) })
            }

            val chemistry = chemistry16Ids.map { bank.question(it) ?: error("missing $it") }
            assertEquals(16, chemistry.size)
            chemistry.forEach { question ->
                val source = JSONObject(question.stimulusJson ?: error("stimulus missing for ${question.id}"))
                assertTrue(source.optString("type") in setOf("data_table", "comparison"))
                assertTrue(testPresentationStimulus(question).isNotEmpty())
                assertEquals(testPresentationStimulus(question), reviewPresentationStimulus(question))
            }

            val resumed = reviewSummary(comparisons)
            val recreated = reviewSummary(comparisons, resumed.entity.questionIdsJson, resumed.entity.answersJson, resumed.entity.reviewPosition)
            assertEquals(resumed.entity.questionIdsJson, recreated.entity.questionIdsJson)
            assertEquals(resumed.entity.answersJson, recreated.entity.answersJson)
            recreated.questions.forEachIndexed { index, question ->
                assertEquals(QuestionMapState.CORRECT, questionMapState(recreated, index))
                assertTrue(reviewPresentationStimulus(question).size >= 2)
            }
        } finally {
            bank.close()
        }
    }

    private fun installFrozenBankForUnitTest() {
        val app = RuntimeEnvironment.getApplication()
        val target = app.getDatabasePath("radiology1405_bank_v6_1.db")
        if (target.exists()) return
        target.parentFile?.mkdirs()
        val working = File(System.getProperty("user.dir"))
        val candidates = buildList {
            var cursor: File? = working
            repeat(5) {
                cursor?.let { root ->
                    add(File(root, "app/src/main/assets/radiology1405_bank_v6_1.db.gz"))
                    add(File(root, "src/main/assets/radiology1405_bank_v6_1.db.gz"))
                }
                cursor = cursor?.parentFile
            }
        }
        val gzip = candidates.firstOrNull(File::isFile)
            ?: error("frozen bank asset not found from ${working.absolutePath}")
        GZIPInputStream(FileInputStream(gzip)).use { input ->
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
    }

    private fun reviewSummary(
        questions: List<Question>,
        questionIdsJson: String = JSONArray(questions.map(Question::id)).toString(),
        answersJson: String = JSONObject().also { answers -> questions.forEach { answers.put(it.id, it.correctIndex) } }.toString(),
        reviewPosition: Int = 11,
    ): SessionSummary {
        val entity = ActiveSessionEntity(
            name = "current", date = "2026-08-19", mode = "AGGRESSIVE_SAFETY", pool = "TRAIN", phase = "review",
            questionIdsJson = questionIdsJson, position = 0, reviewPosition = reviewPosition,
            answersJson = answersJson, confidenceJson = "{}", optionOrdersJson = "{}", flagsJson = "{}", elapsedJson = "{}",
            analysesSeenJson = "{}", errorTypesJson = "{}", startedEpochMs = 100, updatedEpochMs = 200,
        )
        return SessionSummary(entity, questions[reviewPosition], questions.size, questions.size, questions)
    }

    private companion object {
        val comparison21Ids = listOf(
            "v3_bio_02_12", "v3_bio_05_12", "v3_bio_06_07", "v3_bio_07_15", "v3_bio_08_07",
            "v3_bio_10_11", "v3_bio_11_07", "v3_bio_12_07", "v3_bio_14_10", "v3_bio_15_15",
            "v3_bio_16_10", "v3_chem_20_03", "v3_chem_26_03", "v3_chem_54_07", "v3_geo_45_09",
            "v3_geo_46_08", "v3_geo_47_07", "v3_geo_49_08", "v3_phys_30_02", "v3_phys_33_02",
            "v3_phys_34_03",
        )
        val chemistry16Ids = listOf(
            "v3_chem_19_11", "v3_chem_19_12", "v3_chem_19_13", "v3_chem_20_18", "v3_chem_20_19",
            "v3_chem_20_20", "v3_chem_26_10", "v3_chem_26_11", "v3_chem_26_12", "v3_chem_26_13",
            "v3_chem_54_11", "v3_chem_54_12", "v3_chem_54_13", "v3_chem_20_03", "v3_chem_26_03",
            "v3_chem_54_07",
        )
    }
}
