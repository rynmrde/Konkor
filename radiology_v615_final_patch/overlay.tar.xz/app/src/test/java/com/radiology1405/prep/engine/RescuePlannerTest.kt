package com.radiology1405.prep.engine

import com.radiology1405.prep.data.Confidence
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RescuePlannerTest {
    private fun profile(name: String, safe: Int, learningMinutes: Int = 30) = RescueProfile(
        subject = "زمین",
        microtopic = name,
        expectedQuestions = 2.0,
        recentFrequency = 0.8,
        historicalFrequency = 0.8,
        stability = 0.9,
        learningMinutes = learningMinutes,
        prerequisiteCost = 1,
        averageDifficulty = 2,
        errorRisk = 0.4,
        trapRisk = 2,
        calculationLoad = 1,
        masteryProbability11Days = 0.8,
        safeTrainQuestions = safe,
    )

    @Test fun unsafeTopicIsQuarantinedAndNeverPromotedByHistoricalTriage() {
        val result = RescuePlanner.triage(listOf(profile("unsafe", safe = 0))).single()
        assertEquals(RescueTier.Q, result.tier)
    }

    @Test fun twoConfidentSimpleAnswersSkipStraightToTrapAndTransfer() {
        val evidence = listOf(
            TeachingEvidence("L2_CONCEPT", "correct", Confidence.CONFIDENT.name),
            TeachingEvidence("L1_DIRECT", "correct", Confidence.CONFIDENT.name),
        )
        val levels = RescuePlanner.preferredTeachingLevels(evidence)
        assertEquals("L3_TRAP", levels.first())
        assertTrue("L4_TRANSFER" in levels)
        assertTrue("L5_STRICT_EXAM" in levels)
    }

    @Test fun wrongOrUnsureReturnsToMicroLessonBeforeAnotherHardTest() {
        val wrong = RescuePlanner.preferredTeachingLevels(
            listOf(TeachingEvidence("L3_TRAP", "wrong", Confidence.UNSURE.name))
        )
        assertEquals(listOf("L2_CONCEPT", "L1_DIRECT"), wrong)
    }
}
