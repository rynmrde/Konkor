package com.radiology1405.prep.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuestionMapSessionProjectionTest {
    private fun session(
        phase: String = "test",
        position: Int = 0,
        reviewPosition: Int = 0,
        answers: String = "{}",
        flags: String = "{}",
    ) = ActiveSessionEntity(
        name = "current",
        date = "2026-08-20",
        mode = "fixture",
        pool = "TRAIN",
        phase = phase,
        questionIdsJson = "[\"q1\",\"q2\",\"q3\"]",
        position = position,
        reviewPosition = reviewPosition,
        answersJson = answers,
        confidenceJson = "{}",
        optionOrdersJson = "{}",
        flagsJson = flags,
        elapsedJson = "{}",
        analysesSeenJson = "{}",
        errorTypesJson = "{}",
        startedEpochMs = 1000L,
        updatedEpochMs = 2000L,
    )

    private fun attempt(questionId: String, status: String, sessionName: String) = AttemptEntity(
        questionId = questionId,
        sessionName = sessionName,
        date = "2026-08-20",
        subject = "زیست",
        microtopic = "fixture",
        pool = "TRAIN",
        selectedOriginal = null,
        correctIndex = 0,
        status = status,
        confidence = Confidence.CONFIDENT.name,
        errorType = null,
        solveSeconds = 30,
        createdEpochMs = 3000L,
    )

    @Test fun testPhaseRestoresCurrentAnswerAndFlagFromPersistedSessionFields() {
        val snapshot = QuestionMapSessionProjection.snapshot(
            session(position = 1, answers = "{\"q1\":3}", flags = "{\"q2\":true,\"__cue__q3\":true}"),
            emptyList(),
        )
        assertFalse(snapshot.submitted)
        assertEquals("q2", snapshot.selectedQuestionId)
        assertEquals(3, snapshot.entries.first { it.questionId == "q1" }.selectedOriginalIndex)
        assertTrue(snapshot.entries.first { it.questionId == "q2" }.isFlagged)
        assertFalse(snapshot.entries.first { it.questionId == "q3" }.isFlagged)
        assertNull(snapshot.entries.first().result)
        assertEquals(2, snapshot.indexOf("q3"))
    }

    @Test fun reviewPhaseUsesOnlyThisSessionAttemptsAndPersistsReviewPosition() {
        val current = session(phase = "review", reviewPosition = 2, answers = "{\"q2\":1}")
        val key = QuestionMapSessionProjection.sessionKey(current)
        val snapshot = QuestionMapSessionProjection.snapshot(
            current,
            listOf(
                attempt("q1", "correct", key),
                attempt("q2", "wrong", key),
                attempt("q3", "blank", key),
                attempt("q1", "wrong", "other-session"),
            ),
        )
        assertTrue(snapshot.submitted)
        assertEquals("q3", snapshot.selectedQuestionId)
        assertEquals(QuestionMapResult.CORRECT, snapshot.entries.first { it.questionId == "q1" }.result)
        assertEquals(QuestionMapResult.WRONG, snapshot.entries.first { it.questionId == "q2" }.result)
        assertEquals(QuestionMapResult.BLANK, snapshot.entries.first { it.questionId == "q3" }.result)
    }

    @Test fun doneSessionRetainsReviewMapAfterReopen() {
        val current = session(phase = "done", reviewPosition = 1)
        val snapshot = QuestionMapSessionProjection.snapshot(
            current,
            listOf(attempt("q2", "correct", QuestionMapSessionProjection.sessionKey(current))),
        )
        assertTrue(snapshot.submitted)
        assertEquals("q2", snapshot.selectedQuestionId)
        assertEquals(QuestionMapResult.CORRECT, snapshot.entries[1].result)
    }
}
