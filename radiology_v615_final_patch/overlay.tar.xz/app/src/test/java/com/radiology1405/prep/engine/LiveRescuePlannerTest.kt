package com.radiology1405.prep.engine

import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SimulationResultEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDateTime

class LiveRescuePlannerTest {
    private fun profile(
        name: String,
        expected: Double = 2.0,
        recent: Double = 0.8,
        learning: Int = 30,
        prerequisite: Int = 1,
        safe: Int = 5,
    ) = RescueProfile(
        subject = "زیست",
        microtopic = name,
        expectedQuestions = expected,
        recentFrequency = recent,
        historicalFrequency = recent,
        stability = 0.9,
        learningMinutes = learning,
        prerequisiteCost = prerequisite,
        averageDifficulty = 2,
        errorRisk = 0.4,
        trapRisk = 2,
        calculationLoad = 1,
        masteryProbability11Days = 0.8,
        safeTrainQuestions = safe,
    )

    private fun iranTime(day: Int, hour: Int, minute: Int = 0): Long =
        LocalDateTime.of(2026, 8, day, hour, minute).atZone(LiveRescuePlanner.IRAN_ZONE).toInstant().toEpochMilli()

    private fun attempt(
        id: String,
        topic: String,
        at: Long,
        pool: String = "TRAIN",
        status: String = "correct",
        confidence: String = Confidence.CONFIDENT.name,
        seconds: Int = 75,
        spaced: Boolean = false,
    ) = AttemptEntity(
        questionId = id,
        sessionName = "fixture-$pool-$id",
        date = "2026-08-19",
        subject = "زیست",
        microtopic = topic,
        pool = pool,
        selectedOriginal = 0,
        correctIndex = 0,
        status = status,
        confidence = confidence,
        errorType = null,
        solveSeconds = seconds,
        spacedRetrieval = spaced,
        createdEpochMs = at,
    )

    private fun mastery(topic: String, at: Long, score: Double = 0.8) = MasteryEntity(
        microtopic = topic,
        subject = "زیست",
        mastery = score,
        memoryStrength = score,
        attempts = 3,
        distinctQuestions = 3,
        examAttempts = 0,
        confidentCorrectStreak = 3,
        recurringError = null,
        lastAttemptEpochMs = at,
        nextDueEpochMs = at + 86_400_000,
    )

    private fun input(
        profiles: List<RescueProfile> = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E")),
        attempts: List<AttemptEntity> = emptyList(),
        mastery: List<MasteryEntity> = emptyList(),
        simulations: List<SimulationResultEntity> = emptyList(),
        active: ActiveSessionEntity? = null,
        now: Long = iranTime(19, 12),
    ) = LiveRescuePlanner.LiveRescueInput(
        profiles = profiles,
        attempts = attempts,
        mastery = mastery,
        dueCredits = emptyList(),
        simulations = simulations,
        activeSession = active,
        sim1UnrepairedTopics = emptySet(),
        nowEpochMs = now,
    )

    @Test fun iranTimezoneAndMidnightUseActualExamCountdownWithoutForcedReserve() {
        val beforeMidnight = Instant.ofEpochMilli(iranTime(19, 23, 59))
        val afterMidnight = Instant.ofEpochMilli(iranTime(20, 0, 1))
        assertTrue(LiveRescuePlanner.availableStudyMinutes(beforeMidnight) > LiveRescuePlanner.availableStudyMinutes(afterMidnight))
        assertTrue(LiveRescuePlanner.availableStudyMinutes(afterMidnight) > 0)
        assertTrue(LiveRescuePlanner.availableStudyMinutes(Instant.ofEpochMilli(iranTime(20, 22, 31))) > 0)
        assertEquals(0, LiveRescuePlanner.availableStudyMinutes(Instant.ofEpochMilli(iranTime(21, 7, 0))))
        assertEquals("2026-08-21T03:30:00Z", LiveRescuePlanner.EXAM_INSTANT.toString())
    }

    @Test fun unseenTopicUsesThreeToFiveDistinctDiagnosticQuestionsRatherThanAQuota() {
        val decision = LiveRescuePlanner.decide(input())
        assertEquals(LiveRescuePlanner.LogicalPhase.RAPID_HIGH_ROI, decision.phase)
        assertEquals(LiveRescuePlanner.RecommendationKind.DIAGNOSTIC, decision.kind)
        assertTrue(decision.questionCount in 3..5)
        assertTrue(decision.questionCount != 468)
        assertEquals(0, decision.counters.totalAttempts)
    }

    @Test fun roiRanksRecentOfficialDemandAboveOtherwiseSimilarLowDemandTopic() {
        val profiles = listOf(profile("high", expected = 3.0, recent = 1.0), profile("low", expected = 0.3, recent = 0.2))
        val decision = LiveRescuePlanner.decide(input(profiles = profiles))
        assertEquals("high", decision.topicEvidence.first().profile.microtopic)
        assertEquals("high", decision.recommendedTopics.single())
    }

    @Test fun exhaustedTopicIsSkippedInsteadOfRequestingRepeatedQuestions() {
        val now = iranTime(19, 12)
        val profiles = listOf(profile("exhausted", expected = 10.0, recent = 2.0, safe = 3), profile("fresh", expected = 1.0, recent = 0.8, safe = 5))
        val attempts = (1..3).map { attempt("used-$it", "exhausted", now + it, status = "wrong", confidence = Confidence.UNSURE.name) }
        val decision = LiveRescuePlanner.decide(input(profiles = profiles, attempts = attempts, now = now))
        assertEquals("fresh", decision.recommendedTopics.single())
        assertEquals(LiveRescuePlanner.RecommendationKind.DIAGNOSTIC, decision.kind)
        assertTrue(decision.questionCount in 1..5)
    }

    @Test fun partiallyConsumedTopicNeverRequestsMoreThanRemainingDistinctQuestions() {
        val now = iranTime(19, 12)
        val profiles = listOf(profile("partial", expected = 10.0, recent = 2.0, safe = 5))
        val attempts = (1..3).map { attempt("used-$it", "partial", now + it, status = "wrong", confidence = Confidence.UNSURE.name) }
        val decision = LiveRescuePlanner.decide(input(profiles = profiles, attempts = attempts, now = now))
        assertEquals("partial", decision.recommendedTopics.single())
        assertTrue(decision.questionCount in 1..2)
    }

    @Test fun roomShapedAttemptsKeepUniqueTrainingSeparateFromReviewRepeatsAndSimulations() {
        val now = iranTime(19, 12)
        val attempts = listOf(
            attempt("q1", "A", now),
            attempt("q1", "A", now + 1),
            attempt("q2", "A", now + 2),
            attempt("s1", "B", now + 3, pool = "SIM1"),
        )
        val counters = LiveRescuePlanner.counters(attempts)
        assertEquals(2, counters.uniqueTrainingQuestions)
        assertEquals(1, counters.reviewRepeats)
        assertEquals(1, counters.simulationQuestions)
        assertEquals(4, counters.totalAttempts)
    }

    @Test fun enoughReliableCoverageMovesToSim1WithoutUsingCalendarDayOrAttemptThreshold() {
        val now = iranTime(19, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = listOf("A", "B", "C").flatMapIndexed { index, topic ->
            (1..3).map { question -> attempt("$topic-$question", topic, now + index * 10 + question) }
        }
        val mastery = listOf("A", "B", "C").map { mastery(it, now) }
        val decision = LiveRescuePlanner.decide(input(profiles, attempts, mastery, now = now))
        assertEquals(LiveRescuePlanner.RecommendationKind.SIM1, decision.kind)
        assertTrue(decision.sim1Eligible)
        assertEquals(117, decision.questionCount)
    }

    @Test fun sim2RequiresReviewedSim1RepairTimingEvidenceAndGreaterMarginalValue() {
        val now = iranTime(20, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = profiles.flatMapIndexed { topicIndex, profile ->
            (1..3).map { question -> attempt("${profile.microtopic}-$question", profile.microtopic, now + topicIndex * 10 + question, seconds = 70, spaced = true) }
        } + (1..10).map { attempt("pace-$it", "A", now + 100 + it, seconds = 72, spaced = true) }
        val mastery = profiles.map { mastery(it.microtopic, now) }
        val reviewedSim1 = SimulationResultEntity("SIM1", "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)
        val decision = LiveRescuePlanner.decide(input(profiles, attempts, mastery, listOf(reviewedSim1), now = now))
        assertEquals(LiveRescuePlanner.RecommendationKind.SIM2, decision.kind)
        assertTrue(decision.sim2Eligible)
        assertTrue(decision.sim2BeatsTargetedRepair)
        assertTrue(decision.fatigueAcceptable)
    }

    @Test fun noTimingEvidencePreservesSim2AndUsesNonHoldoutMixedFallbackWhenNoTargetedRepairExists() {
        val now = iranTime(20, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = profiles.flatMapIndexed { topicIndex, profile ->
            (1..3).map { question -> attempt("${profile.microtopic}-$question", profile.microtopic, now + topicIndex * 10 + question, seconds = 0, spaced = true) }
        }
        val mastery = profiles.map { mastery(it.microtopic, now) }
        val reviewedSim1 = SimulationResultEntity("SIM1", "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)
        val decision = LiveRescuePlanner.decide(input(profiles, attempts, mastery, listOf(reviewedSim1), now = now))
        assertEquals(LiveRescuePlanner.RecommendationKind.MIXED_DIAGNOSTIC, decision.kind)
        assertFalse(decision.sim2Eligible)
        assertTrue(decision.questionCount in 40..75)
    }

    @Test fun activeSessionAlwaysResumesBeforeCreatingAnotherBlock() {
        val now = iranTime(19, 12)
        val active = ActiveSessionEntity(
            name = "current", date = "2026-08-19", mode = "fixture", pool = "TRAIN", phase = "test",
            questionIdsJson = "[\"q1\"]", position = 0, reviewPosition = 0, answersJson = "{}", confidenceJson = "{}",
            optionOrdersJson = "{}", flagsJson = "{}", elapsedJson = "{}", analysesSeenJson = "{}", errorTypesJson = "{}",
            startedEpochMs = now - 1000, updatedEpochMs = now - 500,
        )
        val decision = LiveRescuePlanner.decide(input(active = active, now = now))
        assertEquals(LiveRescuePlanner.RecommendationKind.RESUME_ACTIVE, decision.kind)
        assertEquals(0, decision.questionCount)
    }

    @Test fun noForcedSleepOrLogisticsReserveBeforeActualExamCutoff() {
        val decision = LiveRescuePlanner.decide(input(now = iranTime(20, 22, 31)))
        assertTrue(decision.availableStudyMinutes > 0)
        assertEquals(LiveRescuePlanner.LogicalPhase.RAPID_HIGH_ROI, decision.phase)
        assertEquals(LiveRescuePlanner.RecommendationKind.DIAGNOSTIC, decision.kind)
        assertTrue(decision.questionCount in 3..5)
    }

    @Test fun historicalABCTierDoesNotGateTheLiveRoiRecommendation() {
        val profiles = listOf(
            profile("historical-C-high-roi", expected = 20.0, recent = 4.0, safe = 1),
            profile("historical-A-low-roi", expected = 0.1, recent = 0.1, safe = 5),
        )
        val historical = RescuePlanner.triage(profiles).associateBy { it.profile.microtopic }
        assertEquals(RescueTier.C, historical.getValue("historical-C-high-roi").tier)
        assertEquals(RescueTier.A, historical.getValue("historical-A-low-roi").tier)

        val decision = LiveRescuePlanner.decide(input(profiles = profiles))
        assertEquals("historical-C-high-roi", decision.recommendedTopics.single())
        assertEquals(LiveRescuePlanner.RecommendationKind.DIAGNOSTIC, decision.kind)
    }

    @Test fun reviewedButUnrepairedSim1ForcesTargetedRepairInsteadOfUnconditionalSim2() {
        val now = iranTime(20, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = profiles.flatMapIndexed { topicIndex, profile ->
            (1..3).map { question -> attempt("${profile.microtopic}-$question", profile.microtopic, now + topicIndex * 10 + question, seconds = 70, spaced = true) }
        } + (1..10).map { attempt("pace-$it", "A", now + 100 + it, seconds = 72, spaced = true) }
        val reviewedSim1 = SimulationResultEntity("SIM1", "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)
        val decision = LiveRescuePlanner.decide(
            input(profiles, attempts, profiles.map { mastery(it.microtopic, now) }, listOf(reviewedSim1), now = now)
                .copy(sim1UnrepairedTopics = setOf("A")),
        )
        assertEquals(LiveRescuePlanner.RecommendationKind.TARGETED_REPAIR, decision.kind)
        assertFalse(decision.sim2Eligible)
        assertEquals(listOf("A"), decision.recommendedTopics)
    }

    private fun cExtraProfiles() = listOf(
        profile("A-reliable", expected = 0.1, recent = 0.1, safe = 20),
        profile("C-extra", expected = 20.0, recent = 4.0, learning = 2200, safe = 5),
    )

    private fun pacedReliableAttempts(now: Long) = (1..10).map { index ->
        attempt("a-$index", "A-reliable", now + index, seconds = 70, spaced = true)
    }

    private fun reviewedSimulation(pool: String, now: Long) =
        SimulationResultEntity(pool, "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)

    @Test fun extraTimeCUnlocksOnlyWithLiveWitnessAndReturnsASeparateRecommendation() {
        val now = iranTime(20, 12)
        val profiles = cExtraProfiles()
        val decisionInput = input(
            profiles = profiles,
            attempts = pacedReliableAttempts(now),
            mastery = listOf(mastery("A-reliable", now)),
            simulations = listOf(reviewedSimulation("SIM1", now), reviewedSimulation("SIM2", now)),
            now = now,
        )
        val witness = LiveRescuePlanner.extraTimeCWitness(decisionInput)
        val decision = LiveRescuePlanner.decide(decisionInput)
        assertTrue(witness.eligible)
        assertEquals("C-extra", witness.candidateTopic)
        assertEquals(LiveRescuePlanner.RecommendationKind.EXTRA_TIME_C, decision.kind)
        assertEquals(listOf("C-extra"), decision.recommendedTopics)
        assertTrue(decision.questionCount in 3..5)
        assertTrue(decision.plannedStudyMinutes <= decision.availableStudyMinutes)
    }

    @Test fun extraTimeCLockedWhenUnresolvedAHigherMarginalRoiRemains() {
        val now = iranTime(20, 12)
        val profiles = listOf(
            profile("A-repair", expected = 30.0, recent = 2.0, safe = 5),
            profile("C-extra", expected = 20.0, recent = 4.0, learning = 2200, safe = 5),
        )
        val decisionInput = input(
            profiles = profiles,
            attempts = pacedReliableAttempts(now),
            simulations = listOf(reviewedSimulation("SIM1", now), reviewedSimulation("SIM2", now)),
            now = now,
        )
        val witness = LiveRescuePlanner.extraTimeCWitness(decisionInput)
        assertFalse(witness.eligible)
        assertEquals("A-repair", witness.higherPriorityBlocker)
        assertEquals(LiveRescuePlanner.RecommendationKind.DIAGNOSTIC, LiveRescuePlanner.decide(decisionInput).kind)
    }

    @Test fun extraTimeCRespectsSim1GateBeforeUsingRemainingTime() {
        val now = iranTime(20, 12)
        val profiles = cExtraProfiles() + profile("A-reliable-2", expected = 0.1, recent = 0.1, safe = 5)
        val decisionInput = input(
            profiles = profiles,
            attempts = pacedReliableAttempts(now) + (1..3).map { index ->
                attempt("a2-$index", "A-reliable-2", now + 100 + index, seconds = 70, spaced = true)
            },
            mastery = listOf(mastery("A-reliable", now), mastery("A-reliable-2", now)),
            now = now,
        )
        val witness = LiveRescuePlanner.extraTimeCWitness(decisionInput)
        assertFalse(witness.eligible)
        assertTrue(witness.detailFa.contains("SIM1"))
        assertEquals(LiveRescuePlanner.RecommendationKind.SIM1, LiveRescuePlanner.decide(decisionInput).kind)
    }

    @Test fun extraTimeCStaysLockedWhenActualCountdownCannotFitUsefulBlock() {
        val now = iranTime(21, 6, 30)
        val profiles = cExtraProfiles()
        val decisionInput = input(
            profiles = profiles,
            attempts = pacedReliableAttempts(now),
            mastery = listOf(mastery("A-reliable", now)),
            simulations = listOf(reviewedSimulation("SIM1", now), reviewedSimulation("SIM2", now)),
            now = now,
        )
        val witness = LiveRescuePlanner.extraTimeCWitness(decisionInput)
        assertFalse(witness.eligible)
        assertTrue(witness.detailFa.contains("زمانِ واقعی"))
        assertFalse(LiveRescuePlanner.decide(decisionInput).kind == LiveRescuePlanner.RecommendationKind.EXTRA_TIME_C)
    }
}
