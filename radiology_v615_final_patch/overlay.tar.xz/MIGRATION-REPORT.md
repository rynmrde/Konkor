# V6.1.5 Migration

Room schema 4 uses explicit non-destructive MIGRATION_3_4. Stable question IDs, attempts, mastery, settings, compatible active sessions and Review state are preserved. No destructive fallback is allowed. Removing calendar/Final-Hours UI does not delete study history.
