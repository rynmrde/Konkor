#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-app/src/main/res/raw}"
mkdir -p "$OUT"
# Short, non-startling UI cues. A ToneGenerator fallback exists if SoundPool is not ready yet.
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=620:duration=0.07' -af 'volume=0.15,afade=t=out:st=0.04:d=0.03' -c:a libvorbis -q:a 3 "$OUT/sfx_select.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=480:duration=0.10' -af 'volume=0.16,afade=t=out:st=0.06:d=0.04' -c:a libvorbis -q:a 3 "$OUT/sfx_submit.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=880:duration=0.12' -af 'volume=0.17,afade=t=out:st=0.08:d=0.04' -c:a libvorbis -q:a 3 "$OUT/sfx_correct.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=220:duration=0.14' -af 'volume=0.15,afade=t=out:st=0.09:d=0.05' -c:a libvorbis -q:a 3 "$OUT/sfx_wrong.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=660:duration=0.18' -af 'volume=0.14,afade=t=out:st=0.12:d=0.06' -c:a libvorbis -q:a 3 "$OUT/sfx_complete.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=520:duration=0.09' -af 'volume=0.13,afade=t=out:st=0.05:d=0.04' -c:a libvorbis -q:a 3 "$OUT/sfx_focus_start.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=390:duration=0.09' -af 'volume=0.13,afade=t=out:st=0.05:d=0.04' -c:a libvorbis -q:a 3 "$OUT/sfx_focus_end.ogg"
# 12-second offline focus loops. Ambient is now a quiet harmonic pad rather than plain noise.
ffmpeg -loglevel error -y \
  -f lavfi -i 'sine=frequency=110:duration=12:sample_rate=44100' \
  -f lavfi -i 'sine=frequency=164.81:duration=12:sample_rate=44100' \
  -f lavfi -i 'sine=frequency=220:duration=12:sample_rate=44100' \
  -f lavfi -i 'sine=frequency=261.63:duration=12:sample_rate=44100' \
  -filter_complex '[0:a]volume=.055[a0];[1:a]volume=.028[a1];[2:a]volume=.022[a2];[3:a]volume=.016[a3];[a0][a1][a2][a3]amix=inputs=4:normalize=0,lowpass=f=900,afade=t=in:d=0.5,afade=t=out:st=11.5:d=0.5[out]' \
  -map '[out]' -c:a libvorbis -q:a 3 "$OUT/focus_ambient.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'anoisesrc=color=white:amplitude=0.04:duration=12:sample_rate=44100' -af 'lowpass=f=4500,highpass=f=350,afade=t=in:d=0.4,afade=t=out:st=11.6:d=0.4' -c:a libvorbis -q:a 2 "$OUT/focus_rain.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'anoisesrc=color=brown:amplitude=0.06:duration=12:sample_rate=44100' -af 'lowpass=f=900,highpass=f=45,afade=t=in:d=0.4,afade=t=out:st=11.6:d=0.4' -c:a libvorbis -q:a 2 "$OUT/focus_brown.ogg"
ffmpeg -loglevel error -y -f lavfi -i 'sine=frequency=80:duration=12:sample_rate=44100' -af 'volume=0.025,tremolo=f=1.1:d=0.75,afade=t=in:d=0.4,afade=t=out:st=11.6:d=0.4' -c:a libvorbis -q:a 2 "$OUT/focus_pulse.ogg"
