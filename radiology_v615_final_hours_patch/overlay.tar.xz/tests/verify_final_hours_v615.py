#!/usr/bin/env python3
"""Deterministic source gate for the V6.1.5 Final-Hours overlay.

This gate is intentionally structural. Behaviour is covered by FinalHoursPlannerTest;
this script verifies that the delivery overlay still contains the required integration
surfaces without opening or mutating the frozen bank.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(path: str, *needles: str) -> None:
    target = ROOT / path
    if not target.is_file():
        raise SystemExit(f"missing required file: {path}")
    text = target.read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            raise SystemExit(f"{path}: missing required evidence: {needle}")


def forbid(path: str, *needles: str) -> None:
    text = (ROOT / path).read_text(encoding="utf-8")
    for needle in needles:
        if needle in text:
            raise SystemExit(f"{path}: forbidden stale rescue rule: {needle}")


def main() -> None:
    require(
        "app/src/main/java/com/radiology1405/prep/engine/FinalHoursPlanner.kt",
        'ZoneId.of("Asia/Tehran")',
        "EXAM_INSTANT",
        "PROTECTED_SLEEP_MINUTES",
        "PROTECTED_LOGISTICS_MINUTES",
        "uniqueTrainingQuestions",
        "reviewRepeats",
        "simulationQuestions",
        "activeSession",
        "sim1UnrepairedTopics",
        "SIM2",
        "MIXED_DIAGNOSTIC",
    )
    forbid(
        "app/src/main/java/com/radiology1405/prep/engine/FinalHoursPlanner.kt",
        "468",
        "ZoneId.systemDefault()",
    )
    require(
        "app/src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt",
        "version = 4",
        "MIGRATION_3_4",
        "reviewedEpochMs",
        "markSimulationReviewed",
        "addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)",
    )
    require(
        "app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt",
        "FinalHoursPlanner.decide",
        "finalHoursDecisionInternal",
        "unresolvedSim1Topics",
        "markSimulationReviewed",
        "finalHours=${decision.kind.name}",
    )
    require(
        "app/src/test/java/com/radiology1405/prep/engine/FinalHoursPlannerTest.kt",
        "iranTimezoneAndMidnight",
        "roomShapedAttempts",
        "sim2RequiresReviewedSim1",
        "noTimingEvidencePreservesSim2",
        "activeSessionAlwaysResumes",
    )
    print("PASS — V6.1.5 Final-Hours source gate")


if __name__ == "__main__":
    main()
