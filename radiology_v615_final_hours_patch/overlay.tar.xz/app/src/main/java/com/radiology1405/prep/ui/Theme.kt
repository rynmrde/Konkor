package com.radiology1405.prep.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.radiology1405.prep.data.ThemeFamily

data class ThemePreview(val background:Color,val surface:Color,val accent:Color)
private val midnight=darkColorScheme(primary=Color(0xFF8AB4F8),onPrimary=Color(0xFF061426),secondary=Color(0xFF81C995),background=Color(0xFF070A11),onBackground=Color(0xFFE8ECF5),surface=Color(0xFF111722),onSurface=Color(0xFFE8ECF5),surfaceVariant=Color(0xFF1A2331),onSurfaceVariant=Color(0xFFBBC5D6),error=Color(0xFFFFB4AB))
private val oled=darkColorScheme(primary=Color(0xFF9FC3FF),onPrimary=Color.Black,secondary=Color(0xFF8FE0A7),background=Color.Black,onBackground=Color(0xFFF7F7F7),surface=Color(0xFF080808),onSurface=Color(0xFFF7F7F7),surfaceVariant=Color(0xFF151515),onSurfaceVariant=Color(0xFFD5D5D5),error=Color(0xFFFFB4AB))
private val graphite=darkColorScheme(primary=Color(0xFFD1D5DB),onPrimary=Color(0xFF1A1D21),secondary=Color(0xFFAEB8C4),background=Color(0xFF15171A),onBackground=Color(0xFFF0F1F3),surface=Color(0xFF202328),onSurface=Color(0xFFF0F1F3),surfaceVariant=Color(0xFF2B2F35),onSurfaceVariant=Color(0xFFD2D6DC),error=Color(0xFFFFB4AB))
private val emerald=darkColorScheme(primary=Color(0xFF6ED5A3),onPrimary=Color(0xFF062519),secondary=Color(0xFF8BB9A1),background=Color(0xFF07120E),onBackground=Color(0xFFE2F2EA),surface=Color(0xFF102019),onSurface=Color(0xFFE2F2EA),surfaceVariant=Color(0xFF173126),onSurfaceVariant=Color(0xFFBDD7CA),error=Color(0xFFFFB4AB))
private val violet=darkColorScheme(primary=Color(0xFFBBA2FF),onPrimary=Color(0xFF100B19),secondary=Color(0xFF8FC89A),background=Color(0xFF100B19),onBackground=Color(0xFFF4EDFF),surface=Color(0xFF21162F),onSurface=Color(0xFFF4EDFF),surfaceVariant=Color(0xFF322141),onSurfaceVariant=Color(0xFFCAB9DF),error=Color(0xFFFFB4AB))
private val ice=darkColorScheme(primary=Color(0xFF86BFD0),onPrimary=Color(0xFF0D1316),secondary=Color(0xFF7FC6AA),background=Color(0xFF0D1316),onBackground=Color(0xFFEDF7FA),surface=Color(0xFF182328),onSurface=Color(0xFFEDF7FA),surfaceVariant=Color(0xFF26373D),onSurfaceVariant=Color(0xFFBCD0D6),error=Color(0xFFFFB4AB))
private val sunset=darkColorScheme(primary=Color(0xFFF0B75F),onPrimary=Color(0xFF18100F),secondary=Color(0xFF97B878),background=Color(0xFF18100F),onBackground=Color(0xFFFFF0E8),surface=Color(0xFF2B1B1A),onSurface=Color(0xFFFFF0E8),surfaceVariant=Color(0xFF422B27),onSurfaceVariant=Color(0xFFD8BBB0),error=Color(0xFFEF7B75))
private val warm=darkColorScheme(primary=Color(0xFFD8B66B),onPrimary=Color(0xFF332614),secondary=Color(0xFF9BAC7D),background=Color(0xFF1E1914),onBackground=Color(0xFFE8DCC8),surface=Color(0xFF282019),onSurface=Color(0xFFE8DCC8),surfaceVariant=Color(0xFF342A20),onSurfaceVariant=Color(0xFFD0C1AC),error=Color(0xFFF0AAA1))
private val light=lightColorScheme(primary=Color(0xFF365A8C),onPrimary=Color.White,secondary=Color(0xFF48664E),background=Color(0xFFF6F7FA),onBackground=Color(0xFF1D222A),surface=Color.White,onSurface=Color(0xFF1D222A),surfaceVariant=Color(0xFFE9EDF3),onSurfaceVariant=Color(0xFF4F5967),error=Color(0xFF9B3D38))
private val contrast=darkColorScheme(primary=Color(0xFFFFE16B),onPrimary=Color.Black,secondary=Color(0xFFB9F6CA),background=Color.Black,onBackground=Color.White,surface=Color(0xFF090909),onSurface=Color.White,surfaceVariant=Color(0xFF151515),onSurfaceVariant=Color.White,error=Color(0xFFFF9E96))

fun schemeFor(theme:ThemeFamily,highContrast:Boolean=false):ColorScheme=if(highContrast)contrast else when(theme){
    ThemeFamily.MIDNIGHT->midnight;ThemeFamily.OLED->oled;ThemeFamily.GRAPHITE->graphite;ThemeFamily.EMERALD->emerald;ThemeFamily.VIOLET->violet;ThemeFamily.ICE->ice;ThemeFamily.SUNSET->sunset;ThemeFamily.WARM->warm;ThemeFamily.LIGHT->light;ThemeFamily.CONTRAST->contrast
}
fun previewFor(theme:ThemeFamily):ThemePreview{val c=schemeFor(theme);return ThemePreview(c.background,c.surfaceVariant,c.primary)}

@Composable
fun RadiologyTheme(
    theme: ThemeFamily,
    textScale: Int,
    highContrast: Boolean = false,
    readerFont: String = ReaderFont.SYSTEM.key,
    content: @Composable () -> Unit,
) {
    val scale=textScale.coerceIn(90,140)/100f
    val font=when(ReaderFont.from(readerFont)){ReaderFont.SYSTEM->FontFamily.Default;ReaderFont.READABLE->FontFamily.SansSerif;ReaderFont.BOOK->FontFamily.Serif}
    fun t(size:Float,line:Float)=TextStyle(fontFamily=font,fontSize=(size*scale).sp,lineHeight=(line*scale).sp)
    val typography=Typography(displayLarge=t(57f,64f),displayMedium=t(45f,52f),displaySmall=t(36f,44f),headlineLarge=t(32f,40f),headlineMedium=t(28f,36f),headlineSmall=t(24f,32f),titleLarge=t(23f,32f),titleMedium=t(18f,27f),titleSmall=t(15f,22f),bodyLarge=t(17f,29f),bodyMedium=t(15f,25f),bodySmall=t(13f,21f),labelLarge=t(15f,22f),labelMedium=t(12f,18f),labelSmall=t(11f,16f))
    MaterialTheme(colorScheme=schemeFor(theme,highContrast),typography=typography,content=content)
}
