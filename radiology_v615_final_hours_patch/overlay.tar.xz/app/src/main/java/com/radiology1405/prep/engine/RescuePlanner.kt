package com.radiology1405.prep.engine

import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.DayPlan
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SimulationResultEntity
import kotlin.math.abs
import kotlin.math.roundToInt

enum class RescueTier(val fa: String) {
    A("A — تسلط اجباری"),
    B("B — مشروط"),
    C("C — فقط وقت اضافه"),
    Q("Q — قرنطینه"),
}

data class RescueProfile(
    val subject: String,
    val microtopic: String,
    val expectedQuestions: Double,
    val recentFrequency: Double,
    val historicalFrequency: Double,
    val stability: Double,
    val learningMinutes: Int,
    val prerequisiteCost: Int,
    val averageDifficulty: Int,
    val errorRisk: Double,
    val trapRisk: Int,
    val calculationLoad: Int,
    val masteryProbability11Days: Double,
    val safeTrainQuestions: Int,
)

data class RescueTopic(
    val profile: RescueProfile,
    val tier: RescueTier,
    val adjustedLearningMinutes: Int,
    val masteryProbability3Days: Double,
    val retentionProbability: Double,
    val expectedReliableCorrectGain: Double,
    val reliableGainPerMinute: Double,
)

data class RescueMetrics(
    val baselineMicrotopics: Int,
    val mandatoryMicrotopics: Int,
    val secondaryMicrotopics: Int,
    val lowPriorityMicrotopics: Int,
    val quarantinedMicrotopics: Int,
    val baselineQuestionBudget: Int,
    val mandatoryQuestionBudget: Int,
    val baselineStudyMinutes: Int,
    val mandatoryStudyMinutes: Int,
    val baselineRawCoverage: Double,
    val mandatoryRawCoverage: Double,
    val baselineReliableGain: Double,
    val mandatoryReliableGain: Double,
) {
    val mandatoryScopeReductionPercent = percent(baselineMicrotopics - mandatoryMicrotopics, baselineMicrotopics)
    val lowPriorityPercent = percent(lowPriorityMicrotopics, baselineMicrotopics)
    val questionBudgetReductionPercent = percent(baselineQuestionBudget - mandatoryQuestionBudget, baselineQuestionBudget)
    val studyTimeReductionPercent = percent(baselineStudyMinutes - mandatoryStudyMinutes, baselineStudyMinutes)
    val rawCoverageReductionPercent = percent(baselineRawCoverage - mandatoryRawCoverage, baselineRawCoverage)
    val reliableGainReductionPercent = percent(baselineReliableGain - mandatoryReliableGain, baselineReliableGain)

    companion object {
        private fun percent(part: Int, total: Int): Double = if (total == 0) 0.0 else 100.0 * part / total
        private fun percent(part: Double, total: Double): Double = if (total == 0.0) 0.0 else 100.0 * part / total
    }
}

data class RescueUnlockState(
    val secondaryUnlocked: Boolean,
    val extraUnlocked: Boolean,
    val confidentCorrectRate: Double,
    val attemptedMandatoryTopics: Int,
    val readyMandatoryTopics: Int,
    val dueMandatoryTopics: Int,
    val detail: String,
)

data class TeachingEvidence(
    val level: String,
    val status: String,
    val confidence: String,
)

enum class RescueStage { TRAIN_CORE, SIM1, SIM2, TRAIN_REPAIR, EXTRA_C, COMPLETE }

object RescuePlanner {
    const val RESCUE_START = "2026-08-17"
    const val RESCUE_END = "2026-08-19"
    const val MANDATORY_LEARNING_MINUTE_CEILING = 900
    const val SECONDARY_GAIN_PER_MINUTE_FLOOR = 0.0087

    // Exact budgets from the frozen V6.1 eight-day plan and the executable three-day plan.
    const val BASELINE_STUDY_MINUTES = 5_955
    const val RESCUE_STUDY_MINUTES = 1_950
    const val BASELINE_QUESTION_BUDGET = 544
    const val RESCUE_QUESTION_BUDGET = 354

    private val initialKnowledge = mapOf(
        "زیست" to 0.58,
        "شیمی" to 0.45,
        "فیزیک" to 0.26,
        "ریاضی" to 0.14,
        "زمین" to 0.18,
    )
    private val learningTimeFactor = mapOf(
        "زیست" to 0.78,
        "شیمی" to 0.88,
        "فیزیک" to 1.12,
        "ریاضی" to 1.25,
        "زمین" to 0.68,
    )

    fun triage(profiles: List<RescueProfile>): List<RescueTopic> {
        val scored = profiles.map(::score).sortedWith(
            compareByDescending<RescueTopic> { it.reliableGainPerMinute }
                .thenBy { it.profile.microtopic }
        )
        var mandatoryMinutes = 0
        return scored.map { topic ->
            val tier = when {
                topic.profile.safeTrainQuestions == 0 -> RescueTier.Q
                topic.profile.safeTrainQuestions >= 3 &&
                    mandatoryMinutes + topic.adjustedLearningMinutes <= MANDATORY_LEARNING_MINUTE_CEILING -> {
                    mandatoryMinutes += topic.adjustedLearningMinutes
                    RescueTier.A
                }
                topic.profile.safeTrainQuestions >= 2 &&
                    topic.reliableGainPerMinute >= SECONDARY_GAIN_PER_MINUTE_FLOOR -> RescueTier.B
                else -> RescueTier.C
            }
            topic.copy(tier = tier)
        }
    }

    private fun score(profile: RescueProfile): RescueTopic {
        val prior = initialKnowledge.getValue(profile.subject)
        val timeFactor = learningTimeFactor.getValue(profile.subject)
        val knowledgeFactor = 0.72 + 0.45 * prior
        val complexityFactor = 1.0 -
            0.035 * (profile.prerequisiteCost - 1).coerceAtLeast(0) -
            0.022 * (profile.calculationLoad - 1).coerceAtLeast(0) -
            0.018 * (profile.averageDifficulty - 2).coerceAtLeast(0) -
            0.025 * (profile.errorRisk - 0.5).coerceAtLeast(0.0) -
            0.010 * (profile.trapRisk - 3).coerceAtLeast(0)
        val mastery3 = (profile.masteryProbability11Days * knowledgeFactor * complexityFactor * 0.96)
            .coerceIn(0.12, 0.90)
        val retention = (0.82 + 0.14 * profile.stability + 0.025 * prior).coerceIn(0.72, 0.96)
        // expectedQuestions already carries the official frequency forecast. Recent and
        // historical observations therefore calibrate confidence slightly, rather than
        // being counted a second time as another full frequency multiplier.
        val frequencyEvidence = 0.70 * profile.recentFrequency + 0.30 * profile.historicalFrequency
        val frequencyCalibration = 0.995 + 0.010 * frequencyEvidence / (frequencyEvidence + 2.0)
        val adjustedMinutes = (
            profile.learningMinutes * timeFactor *
                (1.0 + 0.035 * (profile.prerequisiteCost - 1).coerceAtLeast(0) +
                    0.025 * (profile.calculationLoad - 1).coerceAtLeast(0))
            ).roundToInt().coerceAtLeast(1)
        val gain = profile.expectedQuestions * frequencyCalibration * mastery3 * retention
        return RescueTopic(
            profile = profile,
            tier = RescueTier.C,
            adjustedLearningMinutes = adjustedMinutes,
            masteryProbability3Days = mastery3,
            retentionProbability = retention,
            expectedReliableCorrectGain = gain,
            reliableGainPerMinute = gain / adjustedMinutes,
        )
    }

    fun metrics(topics: List<RescueTopic>): RescueMetrics {
        fun List<RescueTopic>.sumCoverage() = sumOf { it.profile.expectedQuestions }
        fun List<RescueTopic>.sumGain() = sumOf { it.expectedReliableCorrectGain }
        val mandatory = topics.filter { it.tier == RescueTier.A }
        return RescueMetrics(
            baselineMicrotopics = topics.size,
            mandatoryMicrotopics = mandatory.size,
            secondaryMicrotopics = topics.count { it.tier == RescueTier.B },
            lowPriorityMicrotopics = topics.count { it.tier == RescueTier.C },
            quarantinedMicrotopics = topics.count { it.tier == RescueTier.Q },
            baselineQuestionBudget = BASELINE_QUESTION_BUDGET,
            mandatoryQuestionBudget = RESCUE_QUESTION_BUDGET,
            baselineStudyMinutes = BASELINE_STUDY_MINUTES,
            mandatoryStudyMinutes = RESCUE_STUDY_MINUTES,
            baselineRawCoverage = topics.sumCoverage(),
            mandatoryRawCoverage = mandatory.sumCoverage(),
            baselineReliableGain = topics.sumGain(),
            mandatoryReliableGain = mandatory.sumGain(),
        )
    }

    fun dayPlans(topics: List<RescueTopic>): List<DayPlan> {
        val mandatory = topics.filter { it.tier == RescueTier.A }
        val half = mandatory.sumOf { it.adjustedLearningMinutes } / 2.0
        var minutes = 0
        var split = 0
        mandatory.forEachIndexed { index, topic ->
            val before = abs(minutes - half)
            val after = abs(minutes + topic.adjustedLearningMinutes - half)
            if (after <= before || split == 0) {
                minutes += topic.adjustedLearningMinutes
                split = index + 1
            }
        }
        val first = mandatory.take(split).map { it.profile.microtopic }
        val second = mandatory.drop(split).map { it.profile.microtopic }
        return listOf(
            DayPlan(RESCUE_START, 1, "Three-day rescue: mandatory mastery wave 1", 690, 60, first),
            DayPlan("2026-08-18", 2, "Three-day rescue: mandatory wave 2 + SIM1", 660, 162, second),
            DayPlan(RESCUE_END, 3, "Three-day rescue: SIM2 + final spaced repair", 600, 132, emptyList()),
        )
    }

    fun nextStage(day: Int, trainingAttempts: Int, completedSimulations: Set<String>, extraUnlocked: Boolean): RescueStage = when (day) {
        1 -> when {
            trainingAttempts < 60 -> RescueStage.TRAIN_CORE
            extraUnlocked && trainingAttempts < 75 -> RescueStage.EXTRA_C
            else -> RescueStage.COMPLETE
        }
        2 -> when {
            trainingAttempts < 30 -> RescueStage.TRAIN_CORE
            "SIM1" !in completedSimulations -> RescueStage.SIM1
            trainingAttempts < 45 -> RescueStage.TRAIN_REPAIR
            extraUnlocked && trainingAttempts < 60 -> RescueStage.EXTRA_C
            else -> RescueStage.COMPLETE
        }
        3 -> when {
            "SIM2" !in completedSimulations -> RescueStage.SIM2
            trainingAttempts < 15 -> RescueStage.TRAIN_REPAIR
            extraUnlocked && trainingAttempts < 30 -> RescueStage.EXTRA_C
            else -> RescueStage.COMPLETE
        }
        else -> RescueStage.COMPLETE
    }

    fun unlockState(
        topics: List<RescueTopic>,
        attempts: List<AttemptEntity>,
        mastery: List<MasteryEntity>,
        dueNowTopics: Set<String>,
        simulations: List<SimulationResultEntity>,
    ): RescueUnlockState {
        val mandatory = topics.filter { it.tier == RescueTier.A }.map { it.profile.microtopic }.toSet()
        val secondary = topics.filter { it.tier == RescueTier.B }.map { it.profile.microtopic }.toSet()
        val evidence = attempts.filter { it.microtopic in mandatory }
        val attemptedTopics = evidence.map { it.microtopic }.toSet().size
        val confidentCorrect = evidence.count { it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }
        val rate = if (evidence.isEmpty()) 0.0 else confidentCorrect.toDouble() / evidence.size
        val ready = mastery.count { it.microtopic in mandatory && it.mastery >= 0.45 && it.recurringError == null }
        val dueMandatory = dueNowTopics.count { it in mandatory }
        val recurringMandatory = mastery.any { it.microtopic in mandatory && it.recurringError != null && it.mastery < 0.65 }
        val secondaryUnlocked = attemptedTopics >= 10 && rate >= 0.72 && dueMandatory == 0 && !recurringMandatory
        val independent = simulations.filter { it.pool in setOf("SIM1", "SIM2") }.associateBy { it.pool }
        val dueAB = dueNowTopics.any { it in mandatory || it in secondary }
        val extraUnlocked = secondaryUnlocked && attemptedTopics == mandatory.size && ready >= 12 && rate >= 0.85 &&
            independent.keys == setOf("SIM1", "SIM2") && independent.values.all { it.passed && it.leakCount == 0 } && !dueAB
        val detail = when {
            extraUnlocked -> "A تثبیت شده، هر دو SIM پاس و مرورهای A/B بسته‌اند؛ یک بلوک C مجاز است."
            secondaryUnlocked -> "A بدون عقب‌ماندگی جدی است؛ B برای ترمیم/وقت باقی‌مانده باز شد."
            dueMandatory > 0 -> "ابتدا مرورهای سررسید A را کامل کن."
            attemptedTopics < 10 -> "ابتدا پوشش A را کامل کن؛ B و C هنوز قفل‌اند."
            rate < 0.72 -> "دقت مطمئن A هنوز برای بازشدن B کافی نیست."
            else -> "خطای تکراری A را ببند؛ سپس B بررسی می‌شود."
        }
        return RescueUnlockState(secondaryUnlocked, extraUnlocked, rate, attemptedTopics, ready, dueMandatory, detail)
    }

    fun preferredTeachingLevels(evidence: List<TeachingEvidence>): List<String> {
        if (evidence.isEmpty()) return listOf("L1_DIRECT")
        val recent = evidence.first()
        if (recent.status != "correct" || recent.confidence != Confidence.CONFIDENT.name) {
            return listOf("L2_CONCEPT", "L1_DIRECT")
        }
        val confidentSimple = evidence.count {
            it.level in setOf("L1_DIRECT", "L2_CONCEPT") &&
                it.status == "correct" && it.confidence == Confidence.CONFIDENT.name
        }
        if (confidentSimple >= 2) {
            return listOf("L3_TRAP", "L4_TRANSFER", "L5_STRICT_EXAM", "L6_VERIFIED_REAL")
        }
        val completed = evidence.filter { it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }.map { it.level }.toSet()
        return when {
            "L1_DIRECT" !in completed -> listOf("L1_DIRECT")
            "L2_CONCEPT" !in completed -> listOf("L2_CONCEPT", "L3_TRAP")
            "L3_TRAP" !in completed -> listOf("L3_TRAP", "L4_TRANSFER")
            "L4_TRANSFER" !in completed -> listOf("L4_TRANSFER", "L5_STRICT_EXAM")
            "L5_STRICT_EXAM" !in completed -> listOf("L5_STRICT_EXAM", "L6_VERIFIED_REAL")
            else -> listOf("L6_VERIFIED_REAL", "L4_TRANSFER", "L5_STRICT_EXAM")
        }
    }
}
