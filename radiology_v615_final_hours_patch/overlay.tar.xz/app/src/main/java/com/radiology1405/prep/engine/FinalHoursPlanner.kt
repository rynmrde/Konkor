package com.radiology1405.prep.engine

import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.DueCreditEntity
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SimulationResultEntity
import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.max

/**
 * The Final-Hours planner is deliberately an evidence reader, not a mastery generator.
 * Its inputs are Room records and immutable bank profiles.  Missing evidence is treated as
 * unknown/unseen, never as mastery or an assumed subject baseline.
 */
object FinalHoursPlanner {
    val IRAN_ZONE: ZoneId = ZoneId.of("Asia/Tehran")
    val EXAM_INSTANT: Instant = LocalDateTime.of(2026, 8, 21, 7, 0).atZone(IRAN_ZONE).toInstant()

    const val PROTECTED_SLEEP_MINUTES = 7 * 60
    const val PROTECTED_LOGISTICS_MINUTES = 90
    const val NEW_PREREQUISITE_CUTOFF_MINUTES = 4 * 60
    const val SIMULATION_MINUTES = 135
    const val SIMULATION_BUFFER_MINUTES = 30

    enum class LogicalPhase(val fa: String) {
        RAPID_HIGH_ROI("فاز ۱: پوشش سریعِ پُربازده"),
        SIM1_AND_REPAIR("فاز ۲: شبیه‌ساز اول و ترمیم"),
        FINAL_CONSOLIDATION("فاز ۳: تثبیت نهایی"),
        SLEEP_AND_LOGISTICS("خواب و آمادگی آزمون"),
        EXAM_STARTED("زمان آزمون رسیده است"),
    }

    enum class RecommendationKind(val fa: String) {
        RESUME_ACTIVE("ادامهٔ جلسهٔ باز"),
        DUE_REVIEW("بازیابی فاصله‌دارِ سررسید"),
        DIAGNOSTIC("تشخیص کوتاه"),
        TEACH_AND_RETEST("درس کوتاه و بازآزمون متفاوت"),
        PREREQUISITE_REPAIR("ترمیم پیش‌نیاز"),
        TARGETED_REPAIR("ترمیم هدفمند"),
        SIM1("شبیه‌ساز اول"),
        SIM2("شبیه‌ساز دوم"),
        MIXED_DIAGNOSTIC("تشخیص ترکیبی بدون Holdout"),
        FINAL_RETRIEVAL("بازیابی و تثبیت نهایی"),
        REST("خواب، غذا و تدارکات"),
        COMPLETE("پیشنهاد آموزشی دیگری باقی نمانده است"),
    }

    enum class EvidenceState(val fa: String) {
        UNSEEN("ندیده‌شده"),
        DIAGNOSED_WEAK("نیازمند تشخیص/ترمیم"),
        LEARNING("در حال یادگیری"),
        NEAR_MASTERY("نزدیک تسلط"),
        RELIABLE("شاهد قابل اتکا"),
        SPACED_DUE("مرور فاصله‌دار سررسید"),
        LOW_ROI_FOR_NOW("بازده پایین در زمان باقی‌مانده"),
    }

    data class ProgressCounters(
        val uniqueTrainingQuestions: Int,
        val reviewRepeats: Int,
        val simulationQuestions: Int,
        val totalAttempts: Int,
    )

    data class TopicEvidence(
        val profile: RescueProfile,
        val state: EvidenceState,
        val storedMastery: Double?,
        val distinctQuestions: Int,
        val correct: Int,
        val wrong: Int,
        val blank: Int,
        val lowConfidence: Int,
        val dueCount: Int,
        val recurringError: String?,
        val medianSolveSeconds: Int?,
        val reliableGainPerMinute: Double,
        val minimumUsefulMinutes: Int,
    )

    data class FinalHoursInput(
        val profiles: List<RescueProfile>,
        val attempts: List<AttemptEntity>,
        val mastery: List<MasteryEntity>,
        val dueCredits: List<DueCreditEntity>,
        val simulations: List<SimulationResultEntity>,
        val activeSession: ActiveSessionEntity?,
        val sim1UnrepairedTopics: Set<String>,
        val nowEpochMs: Long,
    )

    data class FinalHoursDecision(
        val phase: LogicalPhase,
        val kind: RecommendationKind,
        val topicEvidence: List<TopicEvidence>,
        val recommendedTopics: List<String>,
        val questionCount: Int,
        val plannedStudyMinutes: Int,
        val availableStudyMinutes: Int,
        val protectedSleepMinutes: Int,
        val protectedLogisticsMinutes: Int,
        val counters: ProgressCounters,
        val sim1Eligible: Boolean,
        val sim2Eligible: Boolean,
        val sim2BeatsTargetedRepair: Boolean,
        val fatigueAcceptable: Boolean,
        val detailFa: String,
    )

    fun decide(input: FinalHoursInput): FinalHoursDecision {
        val now = Instant.ofEpochMilli(input.nowEpochMs)
        val counters = counters(input.attempts)
        val available = availableStudyMinutes(now)
        val evidence = scoreTopics(input, available)
        val ranked = evidence.sortedWith(
            compareByDescending<TopicEvidence> { it.reliableGainPerMinute }
                .thenBy { it.profile.microtopic },
        )
        val active = input.activeSession?.takeUnless { it.phase == "done" }
        val sim1 = input.simulations.firstOrNull { it.pool == "SIM1" }
        val sim2 = input.simulations.firstOrNull { it.pool == "SIM2" }
        val coverage = coverageRatio(evidence)
        val fatigue = fatigueAcceptable(input.attempts)
        val sim1Eligible = sim1 == null && coverage >= 0.60 && available >= SIMULATION_MINUTES + SIMULATION_BUFFER_MINUTES
        val targeted = ranked.firstOrNull { it.state !in setOf(EvidenceState.RELIABLE, EvidenceState.LOW_ROI_FOR_NOW) }
        val sim2InformationPerMinute = simulationInformationPerMinute(evidence, coverage)
        val sim2BeatsTargeted = targeted == null || sim2InformationPerMinute > targeted.reliableGainPerMinute
        val sim1Reviewed = sim1?.reviewedEpochMs != null
        val sim2Eligible = sim2 == null && sim1 != null && sim1Reviewed && input.sim1UnrepairedTopics.isEmpty() &&
            fatigue && available >= SIMULATION_MINUTES + SIMULATION_BUFFER_MINUTES && sim2BeatsTargeted

        if (now >= EXAM_INSTANT) {
            return decision(
                phase = LogicalPhase.EXAM_STARTED,
                kind = RecommendationKind.COMPLETE,
                evidence = ranked,
                topics = emptyList(),
                questions = 0,
                minutes = 0,
                available = 0,
                counters = counters,
                sim1Eligible = false,
                sim2Eligible = false,
                sim2BeatsTargeted = false,
                fatigue = fatigue,
                detail = "زمان آزمون فرا رسیده است؛ برنامه‌ریز جلسهٔ آموزشی تازه‌ای نمی‌سازد.",
            )
        }
        if (available <= 0) {
            return decision(
                phase = LogicalPhase.SLEEP_AND_LOGISTICS,
                kind = RecommendationKind.REST,
                evidence = ranked,
                topics = emptyList(),
                questions = 0,
                minutes = 0,
                available = 0,
                counters = counters,
                sim1Eligible = false,
                sim2Eligible = false,
                sim2BeatsTargeted = false,
                fatigue = fatigue,
                detail = "۷ ساعت خواب و ۹۰ دقیقهٔ غذا، بهداشت و تدارکات پیش از آزمون محافظت شده است؛ جلسهٔ تازه آغاز نکن.",
            )
        }
        if (active != null) {
            return decision(
                phase = phaseFor(sim1, coverage, available),
                kind = RecommendationKind.RESUME_ACTIVE,
                evidence = ranked,
                topics = emptyList(),
                questions = 0,
                minutes = 0,
                available = available,
                counters = counters,
                sim1Eligible = sim1Eligible,
                sim2Eligible = sim2Eligible,
                sim2BeatsTargeted = sim2BeatsTargeted,
                fatigue = fatigue,
                detail = "یک جلسهٔ باز ثبت شده است؛ ابتدا همان جلسه را ادامه یا با مسیر ایمنِ موجود پایان بده تا پاسخ، زمان، نشان‌گذاری و مرور آن حفظ شود.",
            )
        }

        val phase = phaseFor(sim1, coverage, available)
        val due = ranked.filter { it.state == EvidenceState.SPACED_DUE }
        if (due.isNotEmpty()) {
            val topics = due.take(3).map { it.profile.microtopic }
            return decision(
                phase, RecommendationKind.DUE_REVIEW, ranked, topics,
                questions = reviewQuestionCount(due), minutes = blockMinutes(due, input.attempts, 0.75), available = available,
                counters = counters, sim1Eligible = sim1Eligible, sim2Eligible = sim2Eligible,
                sim2BeatsTargeted = sim2BeatsTargeted, fatigue = fatigue,
                detail = "مرورهای سررسید پیش از مبحث تازه انجام می‌شوند. هر پرسش باید با پرسش قبلی متفاوت باشد و تکرار، شمارش تسلطِ یکتا را افزایش نمی‌دهد.",
            )
        }
        if (sim1Eligible) {
            return decision(
                LogicalPhase.SIM1_AND_REPAIR, RecommendationKind.SIM1, ranked, emptyList(),
                questions = 117, minutes = SIMULATION_MINUTES, available = available,
                counters = counters, sim1Eligible = true, sim2Eligible = false,
                sim2BeatsTargeted = sim2BeatsTargeted, fatigue = fatigue,
                detail = "پوششِ شاهددارِ مباحث پُربازده به آستانه رسیده است. SIM1 را بدون نشت اجرا کن و پیش از هر تصمیم بعدی، مرور مستقل آن را ثبت کن.",
            )
        }
        if (sim1 != null && !sim1Reviewed) {
            return decision(
                LogicalPhase.SIM1_AND_REPAIR, RecommendationKind.TARGETED_REPAIR, ranked,
                emptyList(), 0, 0, available, counters, sim1Eligible, false, sim2BeatsTargeted, fatigue,
                "SIM1 ثبت شده اما مرور آن هنوز کامل نشده است؛ SIM2 و تشخیص ترکیبی تا ثبت مرور SIM1 پیشنهاد نمی‌شوند.",
            )
        }
        if (sim1 != null && input.sim1UnrepairedTopics.isNotEmpty()) {
            val topics = input.sim1UnrepairedTopics.take(3).toList()
            return decision(
                LogicalPhase.SIM1_AND_REPAIR, RecommendationKind.TARGETED_REPAIR, ranked,
                topics, targetedQuestionCount(ranked, topics), blockMinutesForTopics(ranked, topics, input.attempts),
                available, counters, sim1Eligible, false, sim2BeatsTargeted, fatigue,
                "ضعف‌های SIM1 هنوز شاهدِ ترمیمِ درست و مطمئن ندارند؛ ترمیم هدفمند بر هر شبیه‌ساز یا پوشش گسترده مقدم است.",
            )
        }
        if (sim2Eligible) {
            return decision(
                LogicalPhase.FINAL_CONSOLIDATION, RecommendationKind.SIM2, ranked, emptyList(),
                117, SIMULATION_MINUTES, available, counters, sim1Eligible, true, true, fatigue,
                "SIM2 فقط چون SIM1 مرور شده، ضعف‌های آن ترمیم شده‌اند، شواهد زمان‌سنجی خستگی نامطلوب نشان نمی‌دهند و ارزش اطلاعاتی آن از ترمیم بعدی بیشتر است، پیشنهاد می‌شود.",
            )
        }
        if (sim1 != null && !sim2Eligible && targeted == null && available >= 50) {
            val count = mixedDiagnosticQuestionCount(available, input.attempts)
            return decision(
                LogicalPhase.FINAL_CONSOLIDATION, RecommendationKind.MIXED_DIAGNOSTIC, ranked,
                ranked.take(8).map { it.profile.microtopic }, count, blockMinutes(ranked.take(8), input.attempts, 1.0),
                available, counters, sim1Eligible, false, sim2BeatsTargeted, fatigue,
                "SIM2 ارزش بیشتری از ترمیم هدفمند نشان نمی‌دهد یا پیش‌شرط‌های آن کامل نیست. در صورت نبودِ ترمیمِ پُربازده، تشخیص ترکیبیِ $count سؤالی فقط از TRAIN و بدون Holdout مجاز است.",
            )
        }

        val next = targeted
        if (next == null) {
            return decision(
                phase, RecommendationKind.FINAL_RETRIEVAL, ranked, emptyList(), 0, 0,
                available, counters, sim1Eligible, sim2Eligible, sim2BeatsTargeted, fatigue,
                "شاهدی برای یک مبحثِ پُربازدهِ حل‌نشده باقی نمانده است؛ فقط بازیابی فاصله‌دار، فرمول‌ها و نکته‌های کتاب‌حساس را مرور کن.",
            )
        }
        val noNewPrerequisites = available < NEW_PREREQUISITE_CUTOFF_MINUTES
        val kind = when {
            next.state == EvidenceState.UNSEEN -> RecommendationKind.DIAGNOSTIC
            next.state == EvidenceState.DIAGNOSED_WEAK && next.recurringError != null && !noNewPrerequisites -> RecommendationKind.PREREQUISITE_REPAIR
            next.state in setOf(EvidenceState.DIAGNOSED_WEAK, EvidenceState.LEARNING) -> RecommendationKind.TEACH_AND_RETEST
            else -> RecommendationKind.TARGETED_REPAIR
        }
        val questionCount = when (kind) {
            RecommendationKind.DIAGNOSTIC -> diagnosticQuestionCount(next)
            RecommendationKind.TEACH_AND_RETEST -> retestQuestionCount(next)
            RecommendationKind.PREREQUISITE_REPAIR -> retestQuestionCount(next)
            else -> targetedQuestionCount(ranked, listOf(next.profile.microtopic))
        }
        val detail = when (kind) {
            RecommendationKind.DIAGNOSTIC -> "برای «${next.profile.microtopic}» ابتدا $questionCount پرسشِ متفاوتِ تشخیصی اجرا کن. پاسخ‌های درست و مطمئن به مرحلهٔ بعد می‌روند؛ نتیجهٔ مختلط فقط درس کوتاه و بازآزمون متفاوت می‌گیرد."
            RecommendationKind.TEACH_AND_RETEST -> "برای «${next.profile.microtopic}» یک درس کوتاهِ مشخص اجرا کن و سپس $questionCount پرسشِ متفاوت بازآزمون بگیر. پاسخِ غلط/سفید/کم‌اطمینان، شاهدِ تسلط نیست."
            RecommendationKind.PREREQUISITE_REPAIR -> "خطای تکرارشوندهٔ «${next.profile.microtopic}» به ترمیم پیش‌نیاز نیاز دارد؛ این ترمیم فقط چون بازده آن از گزینهٔ بعدی پایین‌تر نیست انتخاب شده است."
            else -> "«${next.profile.microtopic}» بیشترین افزایشِ پاسخ درستِ قابل‌اتکا به ازای دقیقه را بر پایهٔ فرکانس رسمی، تازگی، پایداری، خطاها، فاصله‌گذاری، زمان و کیفیتِ پرسشِ امن دارد."
        }
        return decision(
            phase, kind, ranked, listOf(next.profile.microtopic), questionCount,
            blockMinutes(listOf(next), input.attempts, if (kind == RecommendationKind.DIAGNOSTIC) 1.0 else 0.85),
            available, counters, sim1Eligible, sim2Eligible, sim2BeatsTargeted, fatigue, detail,
        )
    }

    fun availableStudyMinutes(now: Instant): Int {
        val protectedStart = EXAM_INSTANT.minusSeconds(((PROTECTED_SLEEP_MINUTES + PROTECTED_LOGISTICS_MINUTES) * 60).toLong())
        return max(0, Duration.between(now, protectedStart).toMinutes().toInt())
    }

    fun counters(attempts: List<AttemptEntity>): ProgressCounters {
        val training = attempts.filter { it.pool == "TRAIN" }
        val uniqueTraining = training.map { it.questionId }.toSet().size
        return ProgressCounters(
            uniqueTrainingQuestions = uniqueTraining,
            reviewRepeats = (training.size - uniqueTraining).coerceAtLeast(0),
            simulationQuestions = attempts.filter { it.pool in setOf("SIM1", "SIM2", "FINAL") }.map { it.questionId }.toSet().size,
            totalAttempts = attempts.size,
        )
    }

    private fun scoreTopics(input: FinalHoursInput, available: Int): List<TopicEvidence> {
        val byTopic = input.attempts.groupBy { it.microtopic }
        val mastery = input.mastery.associateBy { it.microtopic }
        val due = input.dueCredits.filter { !it.consumed && it.dueEpochMs <= input.nowEpochMs }
            .groupingBy { it.microtopic }.eachCount()
        return input.profiles.map { profile ->
            val attempts = byTopic[profile.microtopic].orEmpty().sortedByDescending { it.createdEpochMs }
            val stored = mastery[profile.microtopic]
            val distinct = attempts.map { it.questionId }.toSet().size
            val correct = attempts.count { it.status == "correct" }
            val wrong = attempts.count { it.status == "wrong" }
            val blank = attempts.count { it.status == "blank" }
            val lowConfidence = attempts.count { it.confidence != Confidence.CONFIDENT.name }
            val dueCount = due[profile.microtopic] ?: 0
            val spacedSuccess = attempts.any { it.spacedRetrieval && it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }
            val state = stateFor(profile, stored, attempts, distinct, wrong, blank, lowConfidence, dueCount, spacedSuccess, available)
            val usefulMinutes = minimumUsefulMinutes(profile, state)
            val errorFraction = (wrong + blank + lowConfidence).toDouble() / attempts.size.coerceAtLeast(1)
            val recencyCalibrated = 0.85 + 0.15 * (profile.recentFrequency / (profile.historicalFrequency + 0.0001)).coerceIn(0.0, 1.0)
            val reliabilityNeed = when (state) {
                EvidenceState.RELIABLE -> 0.12
                EvidenceState.NEAR_MASTERY -> 0.42
                EvidenceState.LEARNING -> 0.70
                EvidenceState.DIAGNOSED_WEAK -> 0.92
                EvidenceState.UNSEEN -> 1.0
                EvidenceState.SPACED_DUE -> 0.72
                EvidenceState.LOW_ROI_FOR_NOW -> 0.18
            }
            val safeQuestionQuality = (profile.safeTrainQuestions.toDouble() / 3.0).coerceIn(0.0, 1.0)
            val transferEvidence = (0.65 + 0.35 * (attempts.map { it.scenarioFamily }.filter { it.isNotBlank() }.distinct().size / 2.0).coerceIn(0.0, 1.0))
            val burden = 1.0 + 0.10 * (profile.prerequisiteCost - 1).coerceAtLeast(0) +
                0.08 * (profile.calculationLoad - 1).coerceAtLeast(0) + 0.06 * (profile.averageDifficulty - 2).coerceAtLeast(0)
            val gain = profile.expectedQuestions * recencyCalibrated * (0.60 + 0.40 * profile.stability.coerceIn(0.0, 1.0)) *
                reliabilityNeed * (1.0 + 0.50 * errorFraction) * if (dueCount > 0) 1.25 else 1.0 *
                safeQuestionQuality * transferEvidence
            TopicEvidence(
                profile = profile,
                state = state,
                storedMastery = stored?.mastery,
                distinctQuestions = distinct,
                correct = correct,
                wrong = wrong,
                blank = blank,
                lowConfidence = lowConfidence,
                dueCount = dueCount,
                recurringError = stored?.recurringError,
                medianSolveSeconds = median(attempts.map { it.solveSeconds }.filter { it > 0 }),
                reliableGainPerMinute = gain / (usefulMinutes * burden).coerceAtLeast(1.0),
                minimumUsefulMinutes = usefulMinutes,
            )
        }
    }

    private fun stateFor(
        profile: RescueProfile,
        stored: MasteryEntity?,
        attempts: List<AttemptEntity>,
        distinct: Int,
        wrong: Int,
        blank: Int,
        lowConfidence: Int,
        dueCount: Int,
        spacedSuccess: Boolean,
        available: Int,
    ): EvidenceState = when {
        profile.safeTrainQuestions == 0 -> EvidenceState.LOW_ROI_FOR_NOW
        dueCount > 0 -> EvidenceState.SPACED_DUE
        attempts.isEmpty() -> EvidenceState.UNSEEN
        available < NEW_PREREQUISITE_CUTOFF_MINUTES && profile.prerequisiteCost >= 3 && distinct < 3 -> EvidenceState.LOW_ROI_FOR_NOW
        wrong + blank + lowConfidence >= 2 || stored?.recurringError != null -> EvidenceState.DIAGNOSED_WEAK
        stored != null && stored.mastery >= 0.78 && distinct >= 3 && spacedSuccess -> EvidenceState.RELIABLE
        stored != null && stored.mastery >= 0.60 && distinct >= 3 -> EvidenceState.NEAR_MASTERY
        else -> EvidenceState.LEARNING
    }

    private fun minimumUsefulMinutes(profile: RescueProfile, state: EvidenceState): Int {
        val diagnostic = minOf(5, profile.safeTrainQuestions).coerceAtLeast(3) * 3
        return when (state) {
            EvidenceState.UNSEEN -> diagnostic
            EvidenceState.DIAGNOSED_WEAK -> max(12, profile.learningMinutes / 3)
            EvidenceState.LEARNING -> max(10, profile.learningMinutes / 4)
            EvidenceState.NEAR_MASTERY, EvidenceState.SPACED_DUE -> max(8, profile.learningMinutes / 6)
            EvidenceState.RELIABLE, EvidenceState.LOW_ROI_FOR_NOW -> max(6, profile.learningMinutes / 8)
        }
    }

    private fun phaseFor(sim1: SimulationResultEntity?, coverage: Double, available: Int): LogicalPhase = when {
        available <= 0 -> LogicalPhase.SLEEP_AND_LOGISTICS
        sim1 == null && coverage < 0.60 -> LogicalPhase.RAPID_HIGH_ROI
        sim1 == null -> LogicalPhase.SIM1_AND_REPAIR
        else -> LogicalPhase.FINAL_CONSOLIDATION
    }

    private fun coverageRatio(evidence: List<TopicEvidence>): Double {
        val viable = evidence.filter { it.profile.safeTrainQuestions >= 3 }
        if (viable.isEmpty()) return 0.0
        return viable.count { it.state in setOf(EvidenceState.NEAR_MASTERY, EvidenceState.RELIABLE, EvidenceState.SPACED_DUE) }
            .toDouble() / viable.size
    }

    private fun fatigueAcceptable(attempts: List<AttemptEntity>): Boolean {
        val timed = attempts.filter { it.solveSeconds > 0 }.sortedBy { it.createdEpochMs }
        if (timed.size < 10) return false
        val baseline = median(timed.map { it.solveSeconds }) ?: return false
        val recent = median(timed.takeLast(10).map { it.solveSeconds }) ?: return false
        return recent <= ceil(baseline * 1.35).toInt()
    }

    private fun simulationInformationPerMinute(evidence: List<TopicEvidence>, coverage: Double): Double {
        val expected = evidence.filter { it.profile.safeTrainQuestions >= 3 }.sumOf { it.profile.expectedQuestions }
        return expected * coverage.coerceIn(0.0, 1.0) * 0.12 / SIMULATION_MINUTES
    }

    private fun diagnosticQuestionCount(topic: TopicEvidence): Int = minOf(5, topic.profile.safeTrainQuestions).coerceAtLeast(3)
    private fun retestQuestionCount(topic: TopicEvidence): Int = minOf(4, topic.profile.safeTrainQuestions).coerceAtLeast(2)
    private fun reviewQuestionCount(topics: List<TopicEvidence>): Int = topics.sumOf { minOf(2, it.profile.safeTrainQuestions) }.coerceIn(2, 8)
    private fun targetedQuestionCount(ranked: List<TopicEvidence>, topics: List<String>): Int = ranked.filter { it.profile.microtopic in topics }
        .sumOf { minOf(5, it.profile.safeTrainQuestions) }.coerceIn(3, 15)
    private fun mixedDiagnosticQuestionCount(available: Int, attempts: List<AttemptEntity>): Int {
        val pace = median(attempts.map { it.solveSeconds }.filter { it > 0 }) ?: 75
        return (available * 60 / pace).coerceIn(40, 75)
    }
    private fun blockMinutes(topics: List<TopicEvidence>, attempts: List<AttemptEntity>, pacing: Double): Int {
        val pace = median(attempts.map { it.solveSeconds }.filter { it > 0 }) ?: 75
        val questions = topics.sumOf { when (it.state) {
            EvidenceState.UNSEEN -> diagnosticQuestionCount(it)
            EvidenceState.DIAGNOSED_WEAK, EvidenceState.LEARNING -> retestQuestionCount(it)
            else -> minOf(5, it.profile.safeTrainQuestions)
        } }
        return ceil(questions * pace * pacing / 60.0).toInt().coerceAtLeast(5)
    }
    private fun blockMinutesForTopics(ranked: List<TopicEvidence>, topics: List<String>, attempts: List<AttemptEntity>): Int =
        blockMinutes(ranked.filter { it.profile.microtopic in topics }, attempts, 0.85)

    private fun median(values: List<Int>): Int? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        return sorted[sorted.size / 2]
    }

    private fun decision(
        phase: LogicalPhase,
        kind: RecommendationKind,
        evidence: List<TopicEvidence>,
        topics: List<String>,
        questions: Int,
        minutes: Int,
        available: Int,
        counters: ProgressCounters,
        sim1Eligible: Boolean,
        sim2Eligible: Boolean,
        sim2BeatsTargeted: Boolean,
        fatigue: Boolean,
        detail: String,
    ) = FinalHoursDecision(
        phase = phase,
        kind = kind,
        topicEvidence = evidence,
        recommendedTopics = topics,
        questionCount = questions,
        plannedStudyMinutes = minutes.coerceAtMost(available),
        availableStudyMinutes = available,
        protectedSleepMinutes = PROTECTED_SLEEP_MINUTES,
        protectedLogisticsMinutes = PROTECTED_LOGISTICS_MINUTES,
        counters = counters,
        sim1Eligible = sim1Eligible,
        sim2Eligible = sim2Eligible,
        sim2BeatsTargetedRepair = sim2BeatsTargeted,
        fatigueAcceptable = fatigue,
        detailFa = detail,
    )
}
