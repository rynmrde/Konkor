package com.radiology1405.prep

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.radiology1405.prep.data.AppSettingsEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.DayPlan
import com.radiology1405.prep.data.ErrorType
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SafetyState
import com.radiology1405.prep.data.SessionSummary
import com.radiology1405.prep.data.SessionOutcome
import com.radiology1405.prep.data.SimulationResultEntity
import com.radiology1405.prep.data.StudyRepository
import com.radiology1405.prep.engine.RescueMetrics
import com.radiology1405.prep.engine.RescueTopic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class AppScreen { HOME, STUDY, MEMORY, PLAN, SETTINGS }

data class StudyUiState(
    val loading: Boolean = true,
    val message: String? = null,
    val screen: AppScreen = AppScreen.HOME,
    val plan: DayPlan? = null,
    val allPlans: List<DayPlan> = emptyList(),
    val selectedPlanDate: String? = null,
    val todayPlanDate: String? = null,
    val selectedDaySubmitted: Int = 0,
    val session: SessionSummary? = null,
    val outcome: SessionOutcome? = null,
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val mastery: List<MasteryEntity> = emptyList(),
    val simulations: List<SimulationResultEntity> = emptyList(),
    val rescueTopics: List<RescueTopic> = emptyList(),
    val rescueMetrics: RescueMetrics? = null,
    val submittedToday: Int = 0,
    val safety: SafetyState = SafetyState(false, "Learning Safety هنوز فعال نیست", "دو شبیه‌ساز مستقل و شاهد retention لازم است."),
)

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StudyRepository(application)
    private val _state = MutableStateFlow(StudyUiState())
    val state: StateFlow<StudyUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { repository.initialize() }
                .onFailure { fail(it) }
            refreshAll()
            repository.settings.catch { fail(it) }.collect { value ->
                if (value != null) _state.update { it.copy(settings = value) }
            }
        }
        viewModelScope.launch {
            repository.mastery.catch { fail(it) }.collect { value -> _state.update { it.copy(mastery = value) } }
        }
        viewModelScope.launch {
            repository.simulations.catch { fail(it) }.collect { value ->
                _state.update { it.copy(simulations = value) }
                refreshSafety()
            }
        }
    }

    fun navigate(screen: AppScreen) {
        _state.update { it.copy(screen = screen, message = null) }
        if (screen == AppScreen.STUDY) viewModelScope.launch { refreshSession() }
    }

    fun selectDay(date: String) = launchAction {
        val plan = repository.planForDate(date) ?: return@launchAction
        val submitted = repository.attemptCountForDate(date)
        _state.update { it.copy(plan = plan, selectedPlanDate = date, selectedDaySubmitted = submitted, message = null) }
    }

    fun selectToday() = launchAction {
        val plan = repository.planFor()
        val submitted = plan?.date?.let { repository.attemptCountForDate(it) } ?: 0
        _state.update { it.copy(plan = plan, selectedPlanDate = plan?.date, selectedDaySubmitted = submitted, message = null) }
    }

    fun startOrResume() = launchAction {
        val session = repository.startOrResume(_state.value.selectedPlanDate)
        val submitted = repository.attemptCountForDate(session.entity.date)
        _state.update { it.copy(session = session, submittedToday = submitted, screen = AppScreen.STUDY) }
    }

    fun selectDisplay(displayIndex: Int) = launchAction {
        val summary = _state.value.session ?: return@launchAction
        val question = summary.currentQuestion ?: return@launchAction
        val order = optionOrder(summary, question.id)
        repository.selectOriginal(question.id, order.getOrNull(displayIndex))
        refreshSession()
    }

    fun clearAnswer() = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.selectOriginal(question.id, null)
        refreshSession()
    }

    fun setConfidence(value: Confidence) = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.setConfidence(question.id, value)
        refreshSession()
    }

    fun setErrorType(value: ErrorType?) = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.setErrorType(question.id, value)
        refreshSession()
    }

    fun toggleFlag() = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.toggleFlag(question.id)
        refreshSession()
    }

    fun dismissCue() = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.dismissCue(question.id)
        refreshSession()
    }

    fun move(delta: Int) = launchAction { repository.move(delta); refreshSession() }
    fun goTo(index: Int) = launchAction { repository.goTo(index); refreshSession() }
    fun addElapsed(questionId: String, seconds: Int) = launchAction { repository.addElapsed(questionId, seconds) }

    fun submit() = launchAction {
        val session = repository.submit()
        _state.update { it.copy(session = session, outcome = repository.currentOutcome()) }
        refreshSafety()
    }

    fun finishReview() = launchAction {
        repository.finishReview()
        _state.update { it.copy(screen = AppScreen.HOME, session = null, outcome = null) }
        refreshAll()
    }

    fun restartUnsubmittedSession() = launchAction {
        val ok = repository.restartUnsubmittedSession()
        _state.update { it.copy(session = null, outcome = null, screen = AppScreen.HOME, message = if (ok) "بلوک ثبت‌نشده بازسازی شد" else "فقط پیش از ثبت آزمون می‌توان بلوک را بازسازی کرد") }
        refreshAll()
    }

    fun wipeProgress() = launchAction {
        repository.wipeProgress()
        _state.update { it.copy(session = null, outcome = null, screen = AppScreen.HOME, message = "پیشرفت پاک شد؛ نسخهٔ بازیابی داخلی پیش از پاک‌سازی نگه داشته شد") }
        refreshAll()
    }

    fun markAnalysesSeen() = launchAction {
        val question = _state.value.session?.currentQuestion ?: return@launchAction
        repository.markAnalysesSeen(question.id)
    }

    fun saveSettings(value: AppSettingsEntity) {
        val normalized = value.copy(textScale = value.textScale.coerceIn(90, 140))
        _state.update { it.copy(settings = normalized) }
        launchAction { repository.saveSettings(normalized) }
    }

    fun previewTextScale(value: Int) {
        _state.update { it.copy(settings = it.settings.copy(textScale = value.coerceIn(90, 140))) }
    }

    fun commitTextScale() = launchAction {
        repository.saveSettings(_state.value.settings.copy(textScale = _state.value.settings.textScale.coerceIn(90, 140)))
    }

    fun resetUiSettings() = launchAction {
        val current = _state.value.settings
        val reset = current.copy(
            theme = com.radiology1405.prep.data.ThemeFamily.GRAPHITE.name,
            motion = com.radiology1405.prep.data.MotionMode.CALM.name,
            textScale = 100,
            focusMode = true,
            longStudyMode = false,
            breaksEnabled = true,
            breakEvery = 40,
        )
        _state.update { it.copy(settings = reset, message = "تنظیمات رابط به حالت پیشنهادی برگشت") }
        repository.saveSettings(reset)
    }

    fun exportBackup(onReady: (String) -> Unit) = launchAction { onReady(repository.exportBackup()) }

    fun restoreBackup(raw: String) = launchAction {
        val ok = repository.restoreBackup(raw)
        _state.update { it.copy(message = if (ok) "پشتیبان با موفقیت بازیابی شد" else "پشتیبان معتبر V5/V6/V6.1 نبود") }
        if (ok) refreshAll()
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun optionOrder(summary: SessionSummary, questionId: String): List<Int> {
        val array = runCatching { JSONObject(summary.entity.optionOrdersJson).getJSONArray(questionId) }.getOrNull()
            ?: JSONArray(listOf(0, 1, 2, 3))
        return (0 until array.length()).map { array.getInt(it) }
    }

    fun selectedOriginal(summary: SessionSummary, questionId: String): Int? {
        val values = runCatching { JSONObject(summary.entity.answersJson) }.getOrDefault(JSONObject())
        return if (values.has(questionId)) values.optInt(questionId) else null
    }

    fun confidence(summary: SessionSummary, questionId: String): Confidence = runCatching {
        Confidence.valueOf(JSONObject(summary.entity.confidenceJson).optString(questionId, Confidence.CONFIDENT.name))
    }.getOrDefault(Confidence.CONFIDENT)

    fun isFlagged(summary: SessionSummary, questionId: String): Boolean =
        runCatching { JSONObject(summary.entity.flagsJson).optBoolean(questionId) }.getOrDefault(false)

    fun cueKind(summary: SessionSummary, questionId: String): String? {
        val flags = runCatching { JSONObject(summary.entity.flagsJson) }.getOrDefault(JSONObject())
        return when {
            flags.optBoolean("__guided__$questionId") -> "guided"
            flags.optBoolean("__cue__$questionId") -> "spaced"
            flags.optBoolean("__orientation__$questionId") -> "orientation"
            flags.optBoolean("__primer__$questionId") -> "primer"
            else -> null
        }
    }

    fun errorType(summary: SessionSummary, questionId: String): ErrorType? {
        val key = runCatching { JSONObject(summary.entity.errorTypesJson).optString(questionId) }.getOrDefault("")
        return ErrorType.entries.firstOrNull { it.key == key }
    }

    private suspend fun refreshAll() {
        runCatching {
            val plans = repository.plans()
            val todayPlan = repository.planFor()
            val requestedDate = _state.value.selectedPlanDate
            val plan = requestedDate?.let { repository.planForDate(it) } ?: todayPlan
            val active = repository.activeSummary()
            val safety = repository.safetyState()
            val rescueTopics = repository.rescueTopics()
            val rescueMetrics = repository.rescueMetrics()
            val outcome = repository.currentOutcome()
            val sessionSubmitted = active?.entity?.date?.let { repository.attemptCountForDate(it) } ?: 0
            val selectedSubmitted = plan?.date?.let { repository.attemptCountForDate(it) } ?: 0
            _state.update { it.copy(
                loading = false,
                allPlans = plans,
                plan = plan,
                selectedPlanDate = plan?.date,
                todayPlanDate = todayPlan?.date,
                selectedDaySubmitted = selectedSubmitted,
                session = active,
                outcome = outcome,
                submittedToday = sessionSubmitted,
                safety = safety,
                rescueTopics = rescueTopics,
                rescueMetrics = rescueMetrics,
            ) }
        }.onFailure(::fail)
    }

    private suspend fun refreshSession() {
        runCatching { repository.activeSummary() }
            .onSuccess { value ->
                val submittedToday = value?.entity?.date?.let { repository.attemptCountForDate(it) } ?: 0
                _state.update { it.copy(session = value, outcome = repository.currentOutcome(), submittedToday = submittedToday, loading = false) }
            }
            .onFailure(::fail)
    }

    private suspend fun refreshSafety() {
        runCatching { repository.safetyState() }
            .onSuccess { value -> _state.update { it.copy(safety = value) } }
            .onFailure(::fail)
    }

    private fun launchAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            runCatching { block() }.onFailure(::fail)
        }
    }

    private fun fail(error: Throwable) {
        _state.update { it.copy(loading = false, message = error.message ?: "خطای ناشناخته") }
    }

    override fun onCleared() {
        repository.close()
        super.onCleared()
    }

    companion object {
        fun factory(application: Application): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = StudyViewModel(application) as T
        }
    }
}
