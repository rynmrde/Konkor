package com.radiology1405.prep.engine

import com.radiology1405.prep.data.ActiveSessionEntity
import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SimulationResultEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDateTime

class FinalHoursPlannerTest {
    private fun profile(
        name: String,
        expected: Double = 2.0,
        recent: Double = 0.8,
        learning: Int = 30,
        prerequisite: Int = 1,
        safe: Int = 5,
    ) = RescueProfile(
        subject = "زیست",
        microtopic = name,
        expectedQuestions = expected,
        recentFrequency = recent,
        historicalFrequency = recent,
        stability = 0.9,
        learningMinutes = learning,
        prerequisiteCost = prerequisite,
        averageDifficulty = 2,
        errorRisk = 0.4,
        trapRisk = 2,
        calculationLoad = 1,
        masteryProbability11Days = 0.8,
        safeTrainQuestions = safe,
    )

    private fun iranTime(day: Int, hour: Int, minute: Int = 0): Long =
        LocalDateTime.of(2026, 8, day, hour, minute).atZone(FinalHoursPlanner.IRAN_ZONE).toInstant().toEpochMilli()

    private fun attempt(
        id: String,
        topic: String,
        at: Long,
        pool: String = "TRAIN",
        status: String = "correct",
        confidence: String = Confidence.CONFIDENT.name,
        seconds: Int = 75,
        spaced: Boolean = false,
    ) = AttemptEntity(
        questionId = id,
        sessionName = "fixture-$pool-$id",
        date = "2026-08-19",
        subject = "زیست",
        microtopic = topic,
        pool = pool,
        selectedOriginal = 0,
        correctIndex = 0,
        status = status,
        confidence = confidence,
        errorType = null,
        solveSeconds = seconds,
        spacedRetrieval = spaced,
        createdEpochMs = at,
    )

    private fun mastery(topic: String, at: Long, score: Double = 0.8) = MasteryEntity(
        microtopic = topic,
        subject = "زیست",
        mastery = score,
        memoryStrength = score,
        attempts = 3,
        distinctQuestions = 3,
        examAttempts = 0,
        confidentCorrectStreak = 3,
        recurringError = null,
        lastAttemptEpochMs = at,
        nextDueEpochMs = at + 86_400_000,
    )

    private fun input(
        profiles: List<RescueProfile> = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E")),
        attempts: List<AttemptEntity> = emptyList(),
        mastery: List<MasteryEntity> = emptyList(),
        simulations: List<SimulationResultEntity> = emptyList(),
        active: ActiveSessionEntity? = null,
        now: Long = iranTime(19, 12),
    ) = FinalHoursPlanner.FinalHoursInput(
        profiles = profiles,
        attempts = attempts,
        mastery = mastery,
        dueCredits = emptyList(),
        simulations = simulations,
        activeSession = active,
        sim1UnrepairedTopics = emptySet(),
        nowEpochMs = now,
    )

    @Test fun iranTimezoneAndMidnightNeverResetTheProtectedExamBudget() {
        val beforeMidnight = Instant.ofEpochMilli(iranTime(19, 23, 59))
        val afterMidnight = Instant.ofEpochMilli(iranTime(20, 0, 1))
        assertTrue(FinalHoursPlanner.availableStudyMinutes(beforeMidnight) > FinalHoursPlanner.availableStudyMinutes(afterMidnight))
        assertTrue(FinalHoursPlanner.availableStudyMinutes(afterMidnight) > 0)
        assertEquals(0, FinalHoursPlanner.availableStudyMinutes(Instant.ofEpochMilli(iranTime(20, 22, 31))))
        assertEquals("2026-08-21T03:30:00Z", FinalHoursPlanner.EXAM_INSTANT.toString())
    }

    @Test fun unseenTopicUsesThreeToFiveDistinctDiagnosticQuestionsRatherThanAQuota() {
        val decision = FinalHoursPlanner.decide(input())
        assertEquals(FinalHoursPlanner.LogicalPhase.RAPID_HIGH_ROI, decision.phase)
        assertEquals(FinalHoursPlanner.RecommendationKind.DIAGNOSTIC, decision.kind)
        assertTrue(decision.questionCount in 3..5)
        assertTrue(decision.questionCount != 468)
        assertEquals(0, decision.counters.totalAttempts)
    }

    @Test fun roiRanksRecentOfficialDemandAboveOtherwiseSimilarLowDemandTopic() {
        val profiles = listOf(profile("high", expected = 3.0, recent = 1.0), profile("low", expected = 0.3, recent = 0.2))
        val decision = FinalHoursPlanner.decide(input(profiles = profiles))
        assertEquals("high", decision.topicEvidence.first().profile.microtopic)
        assertEquals("high", decision.recommendedTopics.single())
    }

    @Test fun roomShapedAttemptsKeepUniqueTrainingSeparateFromReviewRepeatsAndSimulations() {
        val now = iranTime(19, 12)
        val attempts = listOf(
            attempt("q1", "A", now),
            attempt("q1", "A", now + 1),
            attempt("q2", "A", now + 2),
            attempt("s1", "B", now + 3, pool = "SIM1"),
        )
        val counters = FinalHoursPlanner.counters(attempts)
        assertEquals(2, counters.uniqueTrainingQuestions)
        assertEquals(1, counters.reviewRepeats)
        assertEquals(1, counters.simulationQuestions)
        assertEquals(4, counters.totalAttempts)
    }

    @Test fun enoughReliableCoverageMovesToSim1WithoutUsingCalendarDayOrAttemptThreshold() {
        val now = iranTime(19, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = listOf("A", "B", "C").flatMapIndexed { index, topic ->
            (1..3).map { question -> attempt("$topic-$question", topic, now + index * 10 + question) }
        }
        val mastery = listOf("A", "B", "C").map { mastery(it, now) }
        val decision = FinalHoursPlanner.decide(input(profiles, attempts, mastery, now = now))
        assertEquals(FinalHoursPlanner.RecommendationKind.SIM1, decision.kind)
        assertTrue(decision.sim1Eligible)
        assertEquals(117, decision.questionCount)
    }

    @Test fun sim2RequiresReviewedSim1RepairTimingEvidenceAndGreaterMarginalValue() {
        val now = iranTime(20, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = profiles.flatMapIndexed { topicIndex, profile ->
            (1..3).map { question -> attempt("${profile.microtopic}-$question", profile.microtopic, now + topicIndex * 10 + question, seconds = 70, spaced = true) }
        } + (1..10).map { attempt("pace-$it", "A", now + 100 + it, seconds = 72, spaced = true) }
        val mastery = profiles.map { mastery(it.microtopic, now) }
        val reviewedSim1 = SimulationResultEntity("SIM1", "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)
        val decision = FinalHoursPlanner.decide(input(profiles, attempts, mastery, listOf(reviewedSim1), now = now))
        assertEquals(FinalHoursPlanner.RecommendationKind.SIM2, decision.kind)
        assertTrue(decision.sim2Eligible)
        assertTrue(decision.sim2BeatsTargetedRepair)
        assertTrue(decision.fatigueAcceptable)
    }

    @Test fun noTimingEvidencePreservesSim2AndUsesNonHoldoutMixedFallbackWhenNoTargetedRepairExists() {
        val now = iranTime(20, 12)
        val profiles = listOf(profile("A"), profile("B"), profile("C"), profile("D"), profile("E"))
        val attempts = profiles.flatMapIndexed { topicIndex, profile ->
            (1..3).map { question -> attempt("${profile.microtopic}-$question", profile.microtopic, now + topicIndex * 10 + question, seconds = 0, spaced = true) }
        }
        val mastery = profiles.map { mastery(it.microtopic, now) }
        val reviewedSim1 = SimulationResultEntity("SIM1", "2026-08-20", "[]", "{}", 5000, 0, true, "{}", now - 1)
        val decision = FinalHoursPlanner.decide(input(profiles, attempts, mastery, listOf(reviewedSim1), now = now))
        assertEquals(FinalHoursPlanner.RecommendationKind.MIXED_DIAGNOSTIC, decision.kind)
        assertFalse(decision.sim2Eligible)
        assertTrue(decision.questionCount in 40..75)
    }

    @Test fun activeSessionAlwaysResumesBeforeCreatingAnotherBlock() {
        val now = iranTime(19, 12)
        val active = ActiveSessionEntity(
            name = "current", date = "2026-08-19", mode = "fixture", pool = "TRAIN", phase = "test",
            questionIdsJson = "[\"q1\"]", position = 0, reviewPosition = 0, answersJson = "{}", confidenceJson = "{}",
            optionOrdersJson = "{}", flagsJson = "{}", elapsedJson = "{}", analysesSeenJson = "{}", errorTypesJson = "{}",
            startedEpochMs = now - 1000, updatedEpochMs = now - 500,
        )
        val decision = FinalHoursPlanner.decide(input(active = active, now = now))
        assertEquals(FinalHoursPlanner.RecommendationKind.RESUME_ACTIVE, decision.kind)
        assertEquals(0, decision.questionCount)
    }

    @Test fun finalSleepAndLogisticsPreventNewPrerequisiteHeavyWork() {
        val decision = FinalHoursPlanner.decide(input(now = iranTime(20, 22, 31)))
        assertEquals(FinalHoursPlanner.LogicalPhase.SLEEP_AND_LOGISTICS, decision.phase)
        assertEquals(FinalHoursPlanner.RecommendationKind.REST, decision.kind)
        assertEquals(FinalHoursPlanner.PROTECTED_SLEEP_MINUTES, decision.protectedSleepMinutes)
        assertEquals(FinalHoursPlanner.PROTECTED_LOGISTICS_MINUTES, decision.protectedLogisticsMinutes)
    }
}
