package com.radiology1405.prep.engine

import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.DueCreditEntity
import com.radiology1405.prep.data.ErrorType
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.SafetyState
import com.radiology1405.prep.data.SimulationResultEntity
import com.radiology1405.prep.data.StudyMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min


data class StudyModePolicy(
    val dueLimit: Int,
    val weakSlots: Int,
    val focusTopicLimit: Int,
    val preferredLevels: List<String>,
    val hardFirst: Boolean,
)

data class GradedAnswer(
    val status: String,
    val correct: Boolean,
    val blank: Boolean,
    val confident: Boolean,
    val creditCount: Int,
    val reason: String,
)

object AdaptiveEngine {
    fun studyModePolicy(mode: StudyMode): StudyModePolicy = when (mode) {
        StudyMode.BALANCED_SMART -> StudyModePolicy(6, 4, 0, listOf("L3_TRAP", "L4_TRANSFER", "L5_STRICT_EXAM"), false)
        StudyMode.AGGRESSIVE_SAFETY -> StudyModePolicy(15, 8, 0, listOf("L2_CONCEPT", "L3_TRAP", "L4_TRANSFER", "L5_STRICT_EXAM"), false)
        StudyMode.DEEP_FOCUS -> StudyModePolicy(8, 6, 2, listOf("L2_CONCEPT", "L3_TRAP", "L4_TRANSFER"), false)
        StudyMode.HARD_EXAM -> StudyModePolicy(4, 3, 0, listOf("L5_STRICT_EXAM", "L6_VERIFIED_REAL", "L4_TRANSFER"), true)
    }

    fun breakBoundary(answered: Int, every: Int, acknowledged: Set<Int>): Int? {
        if (every <= 0 || answered < every) return null
        val boundary = (answered / every) * every
        return boundary.takeIf { it >= every && it !in acknowledged }
    }
    val safetyThresholds: Map<String, Double> = mapOf(
        "زیست" to 35.0,
        "شیمی" to 26.0,
        "فیزیک" to 19.0,
        "ریاضی" to 12.0,
        "زمین" to 13.0,
    )

    /** Stable FNV-1a: unlike String.hashCode, its contract is explicit in tests/backups. */
    private fun hash(seed: String): Long {
        var value = 0x811c9dc5L
        seed.toByteArray(Charsets.UTF_8).forEach { byte ->
            value = value xor (byte.toLong() and 0xff)
            value = (value * 0x01000193L) and 0xffffffffL
        }
        return value
    }

    fun optionOrder(questionId: String, sessionName: String, fixed: Boolean): List<Int> {
        if (fixed) return listOf(0, 1, 2, 3)
        val result = mutableListOf(0, 1, 2, 3)
        for (i in 3 downTo 1) {
            val j = (hash("$sessionName|$questionId|$i") % (i + 1)).toInt()
            val old = result[i]
            result[i] = result[j]
            result[j] = old
        }
        return result
    }

    fun originalIndex(displayIndex: Int?, order: List<Int>): Int? =
        displayIndex?.takeIf { it in 0..3 }?.let(order::get)

    fun grade(selectedOriginal: Int?, correctIndex: Int, confidence: Confidence): GradedAnswer {
        val blank = selectedOriginal == null
        val correct = selectedOriginal == correctIndex
        val confidentCorrect = correct && confidence == Confidence.CONFIDENT
        return GradedAnswer(
            status = when { blank -> "blank"; correct -> "correct"; else -> "wrong" },
            correct = correct,
            blank = blank,
            confident = confidence == Confidence.CONFIDENT,
            creditCount = if (confidentCorrect) 2 else 4,
            reason = when {
                blank -> "blank"
                !correct -> "wrong"
                confidence == Confidence.UNSURE -> "correct_unsure"
                else -> "correct_confident"
            },
        )
    }

    fun creditPriority(grade: GradedAnswer, errorType: ErrorType?, repeated: Boolean): Int {
        val base = when {
            grade.status == "wrong" -> 100
            grade.blank -> 95
            !grade.confident -> 90
            errorType != null -> 80
            else -> 60
        }
        return base + if (repeated) 15 else 0
    }

    /** Compressed real spacing: later today, +1, +3, +6; anything beyond Aug 19 consolidates there. */
    fun dueTimes(now: Long, count: Int, zone: ZoneId = ZoneId.systemDefault()): List<Long> {
        require(count in 1..4)
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val offsets = listOf(0L, 1L, 3L, 6L).take(count)
        val finalDay = LocalDate.of(2026, 8, 19)
        val finalCutoff = finalDay.atTime(22, 0).atZone(zone).toInstant().toEpochMilli()
        val upperBound = maxOf(now, finalCutoff)
        var previous = now
        return offsets.mapIndexed { index, offset ->
            val candidate = if (index == 0) now + 3 * 60 * 60 * 1000L
            else minOf(today.plusDays(offset), finalDay).atTime(8, 0).atZone(zone).toInstant().toEpochMilli()
            val scheduled = minOf(maxOf(candidate, previous + 3 * 60 * 60 * 1000L), upperBound)
            previous = scheduled
            scheduled
        }
    }

    fun buildCredits(
        microtopic: String,
        sourceQuestionId: String,
        grade: GradedAnswer,
        errorType: ErrorType?,
        repeated: Boolean,
        now: Long,
    ): List<DueCreditEntity> {
        val priority = creditPriority(grade, errorType, repeated)
        return dueTimes(now, grade.creditCount).map { due ->
            DueCreditEntity(
                microtopic = microtopic,
                reason = grade.reason,
                priority = priority,
                remaining = 1,
                dueEpochMs = due,
                sourceQuestionId = sourceQuestionId,
                createdEpochMs = now,
            )
        }
    }

    fun updateMastery(
        previous: MasteryEntity?,
        attempt: AttemptEntity,
        priorAttempts: List<AttemptEntity>,
    ): MasteryEntity {
        val correct = attempt.status == "correct"
        val confident = attempt.confidence == Confidence.CONFIDENT.name
        val difficultyWeight = if (attempt.pool == "SIM1" || attempt.pool == "SIM2") 1.15 else 1.0
        val allAttempts = priorAttempts + attempt
        val recentErrors = (listOf(attempt) + priorAttempts.take(4)).mapNotNull { it.errorType }
        val recurring = recentErrors.groupingBy { it }.eachCount().maxByOrNull { it.value }
            ?.takeIf { it.value >= 2 }?.key
        val repeatedError = recurring != null
        val delta = when {
            correct && confident -> 0.10 * difficultyWeight
            correct -> 0.045 * difficultyWeight
            attempt.status == "blank" -> -0.07
            repeatedError -> -0.12
            else -> -0.09
        }
        // A repeated correct answer is useful for memory/spacing but cannot be fresh mastery evidence.
        // Wrong or blank repeats still lower mastery because they are diagnostic evidence of unreliability.
        val exactRepeat = priorAttempts.any { it.questionId == attempt.questionId }
        val masteryDelta = if (exactRepeat && correct) 0.0 else delta
        val daysSinceEvidence = previous?.let { nowDaysBetween(it.lastAttemptEpochMs, attempt.createdEpochMs) } ?: 0
        val masteryDecay = min(0.12, daysSinceEvidence * 0.015)
        val memoryDecay = min(0.24, daysSinceEvidence * 0.04)
        val oldMastery = (previous?.mastery ?: 0.0) * (1.0 - masteryDecay)
        val oldMemory = (previous?.memoryStrength ?: 0.0) * (1.0 - memoryDecay)
        val unique = allAttempts.map { it.questionId }.distinct().size
        val scenarios = allAttempts.map { it.scenarioFamily }.filter { it.isNotBlank() }.distinct().size
        val examAttempts = allAttempts.count { it.pool == "SIM1" || it.pool == "SIM2" || it.pool == "FINAL" }
        val easyOnly = allAttempts.all { it.difficulty <= 2 } && allAttempts.none { it.strictOrVerifiedReal }
        val unsureCorrectRatio = allAttempts.count { it.status == "correct" && it.confidence == Confidence.UNSURE.name }
            .toDouble() / allAttempts.size.coerceAtLeast(1)
        val strictAttempted = allAttempts.any { it.strictOrVerifiedReal }
        val spacedStrictSuccess = allAttempts.any {
            it.strictOrVerifiedReal && it.spacedRetrieval && it.status == "correct" && it.confidence == Confidence.CONFIDENT.name
        }
        val memoryDelta = when {
            correct && confident && priorAttempts.any { nowDaysBetween(it.createdEpochMs, attempt.createdEpochMs) >= 1 } -> 0.12
            correct && confident -> 0.055
            correct -> 0.02
            else -> -0.08
        }
        val hasSpacing = priorAttempts.any { nowDaysBetween(it.createdEpochMs, attempt.createdEpochMs) >= 1 }
        val transferCap = minOf(
            if (easyOnly) 0.62 else 1.0,
            if (unique >= 3) 1.0 else 0.55,
            if (scenarios >= 2) 1.0 else 0.68,
            if (hasSpacing) 1.0 else 0.68,
            if (examAttempts >= 1) 1.0 else 0.78,
            if (unsureCorrectRatio >= 0.40) 0.70 else 1.0,
            if (strictAttempted && !spacedStrictSuccess) 0.78 else 1.0,
            if (correct && confident || (previous?.confidentCorrectStreak ?: 0) >= 1) 1.0 else 0.72,
        )
        val nextDue = dueTimes(attempt.createdEpochMs, if (correct && confident) 2 else 4).last()
        return MasteryEntity(
            microtopic = attempt.microtopic,
            subject = attempt.subject,
            mastery = min((oldMastery + masteryDelta).coerceIn(0.0, 1.0), transferCap),
            memoryStrength = (oldMemory + memoryDelta).coerceIn(0.0, 1.0),
            attempts = (previous?.attempts ?: 0) + 1,
            distinctQuestions = max(previous?.distinctQuestions ?: 0, unique),
            examAttempts = max(previous?.examAttempts ?: 0, examAttempts),
            confidentCorrectStreak = if (correct && confident) (previous?.confidentCorrectStreak ?: 0) + 1 else 0,
            recurringError = recurring,
            lastAttemptEpochMs = attempt.createdEpochMs,
            nextDueEpochMs = nextDue,
        )
    }

    private fun nowDaysBetween(earlier: Long, later: Long): Long =
        max(0L, (later - earlier) / (24L * 60 * 60 * 1000))

    /** Net percent with one-third negative marking; unsure-correct receives half credit. */
    fun reliableScore(attempts: List<AttemptEntity>): Map<String, Double> = attempts
        .groupBy { it.subject }
        .mapValues { (_, values) ->
            100.0 * values.sumOf { a ->
                when {
                    a.status == "wrong" -> -1.0 / 3.0
                    a.status != "correct" -> 0.0
                    a.confidence == Confidence.CONFIDENT.name -> 1.0
                    else -> 0.5
                }
            } / values.size.coerceAtLeast(1)
        }

    fun safetyState(
        simulations: List<SimulationResultEntity>,
        recurringHighRoiError: Boolean,
        spacedConfidentMicrotopics: Int,
    ): SafetyState {
        val independent = simulations.filter { it.pool in setOf("SIM1", "SIM2") }.associateBy { it.pool }
        if (independent.keys != setOf("SIM1", "SIM2")) {
            return SafetyState(false, "Learning Safety هنوز فعال نیست", "هر دو شبیه‌ساز مستقل باید کامل شوند.")
        }
        if (independent.values.any { !it.passed || it.leakCount != 0 }) {
            return SafetyState(false, "Learning Safety هنوز فعال نیست", "هر دو شبیه‌ساز باید بدون نشت، در زمان مجاز و بالای آستانه باشند.")
        }
        if (recurringHighRoiError) {
            return SafetyState(false, "نیازمند تثبیت", "یک خطای تکرارشوندهٔ پُربازده هنوز بسته نشده است.")
        }
        if (spacedConfidentMicrotopics < 5) {
            return SafetyState(false, "نیازمند شاهد retention", "حداقل ۵ ریزمبحث باید در بازیابی فاصله‌دار، درست و مطمئن پاسخ داده شوند.")
        }
        return SafetyState(
            true,
            "Learning/Performance Safety پاس شد",
            "این وضعیت فقط تثبیت آموزشی را نشان می‌دهد؛ Admission Safety یا تضمین قبولی نیست.",
        )
    }

    fun simulationPassed(scores: Map<String, Double>, leakCount: Int, durationSeconds: Int): Boolean =
        leakCount == 0 && durationSeconds in 1..(135 * 60) &&
            safetyThresholds.all { (subject, threshold) -> (scores[subject] ?: 0.0) >= threshold }
}
