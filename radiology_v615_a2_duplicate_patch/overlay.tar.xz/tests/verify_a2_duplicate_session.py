#!/usr/bin/env python3
"""A2 deterministic QA: normal-block uniqueness, cosmetic variant suppression and SIM isolation."""
from __future__ import annotations

import gzip
import hashlib
import json
import random
import re
import sqlite3
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# The Git overlay intentionally excludes the immutable bank; use the reconstructed base project
# during local QA and the colocated asset when the gate runs after overlay extraction in CI.
BANK_GZ = ROOT / 'app/src/main/assets/radiology1405_bank_v6_1.db.gz'
if not BANK_GZ.exists():
    BANK_GZ = ROOT.parent / 'active-project/app/src/main/assets/radiology1405_bank_v6_1.db.gz'
EXPECTED_GZ = 'b5f47e9803638a37798be398ff4a087f336aafa78470e6f5ad94ac3aa5d7fe14'
SOURCE_REPOSITORY = ROOT / 'app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt'
SOURCE_STORE = ROOT / 'app/src/main/java/com/radiology1405/prep/data/BankStore.kt'
SOURCE_ENGINE = ROOT / 'app/src/main/java/com/radiology1405/prep/engine/AdaptiveEngine.kt'
TMP_DB = ROOT / '.a2_duplicate_session_bank.db'

assert hashlib.sha256(BANK_GZ.read_bytes()).hexdigest() == EXPECTED_GZ, 'frozen bank gzip hash mismatch'
with gzip.open(BANK_GZ, 'rb') as src, TMP_DB.open('wb') as dst:
    dst.write(src.read())

translate = str.maketrans({'ي':'ی','ك':'ک','ى':'ی','ة':'ه','ؤ':'و','إ':'ا','أ':'ا'})
def normal(value: object) -> str:
    text = unicodedata.normalize('NFKC', str(value or '')).translate(translate).lower()
    text = text.replace('\u200c', ' ')
    text = re.sub(r'[۰-۹0-9]+', '#', text)
    text = re.sub(r'[\s\W_]+', ' ', text, flags=re.UNICODE).strip()
    return text

def family(row: dict) -> str:
    body = str(row['stem']).split('\n')[-1]
    body = re.sub(r'^داده.?های زیر را با مدل مناسب پیوند دهید.*?به.?دست می.?آید[؟?]\\s*', '', body)
    body = re.sub(r'^برای حل مسئله.? زیر.*?جفت شده است[؟?]\\s*', '', body)
    options = '|'.join(sorted(normal(str(x).split('؛')[0].split(';')[0]) for x in row['options']))
    source = '|'.join([row['subject'], row['microtopic'], normal(body), options])
    return hashlib.sha256(source.encode()).hexdigest()

conn = sqlite3.connect(f'file:{TMP_DB}?mode=ro', uri=True)
conn.row_factory = sqlite3.Row
questions = []
for dbrow in conn.execute('SELECT id, subject, microtopic, priority, difficulty, access_pool, selected_scope, obsolete, full_json FROM question'):
    raw = json.loads(dbrow['full_json'])
    question = {
        'id': dbrow['id'], 'subject': dbrow['subject'], 'microtopic': dbrow['microtopic'],
        'priority': dbrow['priority'], 'difficulty': dbrow['difficulty'], 'access_pool': dbrow['access_pool'],
        'selected_scope': bool(dbrow['selected_scope']), 'obsolete': bool(dbrow['obsolete']), **raw,
    }
    question['evidence_family'] = family(question)
    questions.append(question)

ids = [q['id'] for q in questions]
assert len(ids) == len(set(ids)), 'duplicate question ID in frozen bank'
by_id = {q['id']: q for q in questions}
train = [q for q in questions if q['access_pool'] == 'TRAIN' and q['selected_scope'] and not q['obsolete'] and q.get('eligible_for_safety_evidence', True) and not q.get('needs_human_review', False)]
by_topic = defaultdict(list)
for q in train:
    by_topic[q['microtopic']].append(q)
for values in by_topic.values():
    values.sort(key=lambda q: (-q['priority'], q['difficulty'], q['id']))

blueprints = json.loads(conn.execute("SELECT json FROM bank_root WHERE key='simulation_blueprints'").fetchone()[0])
sim_sets = {}
for pool in ('SIM1','SIM2'):
    pool_ids = list(blueprints[pool]['question_ids'])
    assert len(pool_ids) == 117 and len(pool_ids) == len(set(pool_ids)), f'{pool} must contain 117 distinct IDs'
    assert all(qid in by_id and by_id[qid]['access_pool'] == pool for qid in pool_ids), f'{pool} pool mismatch'
    assert all(by_id[qid].get('eligible_for_safety_evidence', True) and not by_id[qid].get('needs_human_review', False) for qid in pool_ids), f'{pool} unsafe holdout'
    sim_sets[pool] = set(pool_ids)
assert sim_sets['SIM1'].isdisjoint(sim_sets['SIM2']), 'SIM holdouts overlap'
assert not (set(q['id'] for q in train) & (sim_sets['SIM1'] | sim_sets['SIM2'])), 'SIM holdout leaks into safe TRAIN candidates'

rng = random.Random(1405)
topics = sorted(by_topic)
short_blocks = 0
for iteration in range(2000):
    scope = rng.sample(topics, rng.randint(1, len(topics)))
    historical = {q['id'] for q in train if rng.random() < 0.30}
    selected = []
    selected_families = set()
    # Mirrors patched normal selection: round-robin per topic then global fill, never falling back to historical IDs.
    while len(selected) < 15:
        changed = False
        for topic in scope:
            for q in by_topic[topic]:
                if q['id'] not in historical and q['id'] not in selected and q['evidence_family'] not in selected_families:
                    selected.append(q['id']); selected_families.add(q['evidence_family']); changed = True
                    break
            if len(selected) == 15:
                break
        if not changed:
            break
    if len(selected) < 15:
        short_blocks += 1
    assert len(selected) == len(set(selected)), f'iteration {iteration}: duplicate question ID'
    assert not (set(selected) & historical), f'iteration {iteration}: historical repeat in normal block'
    observed_families = [by_id[qid]['evidence_family'] for qid in selected]
    assert len(observed_families) == len(set(observed_families)), f'iteration {iteration}: cosmetic evidence repeat'
    assert not (set(selected) & (sim_sets['SIM1'] | sim_sets['SIM2'])), f'iteration {iteration}: SIM holdout leak'

repo = SOURCE_REPOSITORY.read_text(encoding='utf-8')
store = SOURCE_STORE.read_text(encoding='utf-8')
engine = SOURCE_ENGINE.read_text(encoding='utf-8')
assert 'Historical question repeat in normal TRAIN block' in repo
assert 'Cosmetic evidence repeat in normal TRAIN block' in repo
assert 'selected += bank.poolIds("TRAIN", allowedTopics' not in repo, 'historical repeat fallback remains'
assert 'excludedEvidenceFamilies' in repo and 'fun evidenceFamily' in store
assert 'val masteryDelta = if (exactRepeat && correct) 0.0 else delta' in engine
print(json.dumps({
    'status': 'PASS', 'frozen_question_ids': len(ids), 'safe_train_candidates': len(train),
    'simulation_sizes': {pool: len(values) for pool, values in sim_sets.items()},
    'mass_normal_blocks': 2000, 'adaptive_short_blocks_without_repeat': short_blocks,
}, ensure_ascii=False))
TMP_DB.unlink(missing_ok=True)
