package com.radiology1405.prep.data

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

enum class ThemeFamily(val fa: String) {
    MIDNIGHT("نیمه‌شب آبی"), OLED("OLED مشکی"), GRAPHITE("تاریک نرم"), EMERALD("جنگلی"),
    VIOLET("بنفش"), ICE("یخی"), SUNSET("غروب"), WARM("شب گرم"), LIGHT("کاغذ روشن"), CONTRAST("کنتراست بالا");

    companion object {
        fun fromStored(value: String): ThemeFamily = when (value) {
            "SOFT_DARK", "soft", "graphite", "GRAPHITE" -> GRAPHITE
            "WARM_NIGHT", "warm", "WARM" -> WARM
            "PAPER_WARM", "paper", "light", "LIGHT" -> LIGHT
            "HIGH_CONTRAST", "contrast", "CONTRAST" -> CONTRAST
            "oled", "OLED" -> OLED
            "midnight", "MIDNIGHT" -> MIDNIGHT
            "forest", "emerald", "EMERALD" -> EMERALD
            "violet", "VIOLET" -> VIOLET
            "ice", "ICE" -> ICE
            "sunset", "SUNSET" -> SUNSET
            else -> entries.firstOrNull { it.name == value } ?: MIDNIGHT
        }
    }
}

enum class StudyMode(val fa: String) {
    BALANCED_SMART("هوشمند متعادل"), AGGRESSIVE_SAFETY("ایمنی تهاجمی"), DEEP_FOCUS("تمرکز عمیق"), HARD_EXAM("آزمون سخت")
}

enum class MotionMode(val fa: String) {
    MINIMAL("حداقلی"), CALM("آرام"), DYNAMIC("پویا"), LIVELY("سرزنده بدون چشمک")
}

enum class Confidence(val fa: String) { CONFIDENT("مطمئن"), UNSURE("نامطمئن") }

data class SubjectOutcome(val correct: Int, val wrong: Int, val blank: Int)
data class SessionOutcome(
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val total: Int,
    val bySubject: Map<String, SubjectOutcome>,
)

enum class ErrorType(val key: String, val fa: String) {
    KNOWLEDGE_GAP("knowledge_gap", "کمبود دانش"),
    FORGOTTEN_RULE("forgotten_rule", "فراموشی قاعده"),
    CALCULATION_ERROR("calculation_error", "خطای محاسبات"),
    MISREAD("misread", "بدخوانی سؤال"),
    TRAP("trap", "افتادن در دام"),
    TIME_MANAGEMENT("time_management", "مدیریت زمان"),
    CARELESS_ERROR("careless_error", "بی‌دقتی")
}

data class SourceCrop(
    val dataUri: String,
    val altText: String,
    val sha256: String,
)

data class TableStimulus(
    val caption: String,
    val headers: List<String>,
    val rows: List<List<String>>,
)

data class ComparisonStimulus(
    val leftLabel: String,
    val left: String,
    val rightLabel: String,
    val right: String,
)

private val userFacingTrapLabels = linkedMapOf(
    "condition_wrong" to "نادیده‌گرفتن قید تعیین‌کننده",
    "wrong_condition" to "نادیده‌گرفتن قید تعیین‌کننده",
    "truth_partial" to "درست‌بودنِ ناقصِ گزاره",
    "partial_truth" to "درست‌بودنِ ناقصِ گزاره",
    "overgeneralization" to "تعمیمِ بیش از حد",
    "correct_reasoning" to "استدلال درست",
    "unit_error" to "خطای واحد",
    "misread_condition" to "بدخوانیِ قید سؤال",
    "wrong_direction" to "اشتباه در جهت یا روند",
    "sign_error" to "خطای علامت",
    "formula_misuse" to "به‌کارگیری نادرست رابطه",
    "calculation_error" to "خطای محاسباتی",
    "calculation_trap" to "دام محاسباتی",
)

private fun localizeInternalTrapTokens(value: String): String =
    userFacingTrapLabels.entries.fold(value) { localized, (raw, fa) -> localized.replace(raw, fa) }

private val genericTrainingFillers = listOf(
    "این گزینه با همهٔ شرط‌ها سازگار است. مدل و محاسبه هر دو درست‌اند؛",
    "تیپ را تشخیص بده، واحدها را یکسان کن و بعد از راه",
    "این مسئله یک زنجیرهٔ پیوسته دارد؛ خروجی هر مرحله ورودی مرحلهٔ بعد است.",
)

private fun learnerFacingText(value: String): String =
    genericTrainingFillers.fold(localizeInternalTrapTokens(value)) { compact, filler -> compact.replace(filler, "") }
        .replace("پیش برو.", "")
        .replace("کنترل: ", "")
        .replace(Regex("\\s+"), " ")
        .trim()

private val correctedChemistryAnalyses = mapOf(
    "v3_chem_17_03" to "درصد بازده=(جرم واقعی÷جرم نظری)×100=(30 g÷40 g)×100=75٪. نسبت g/g بی‌واحد است و نتیجه به‌صورت درصد گزارش می‌شود.",
    "v3_chem_17_05" to "برای 2H₂+O₂→2H₂O، نسبت‌های n/ضریب: H₂ برابر 3÷2=1.5 و O₂ برابر 2÷1=2 است؛ پس H₂ واکنش‌دهندهٔ محدودکننده است. از نسبت 2H₂:2H₂O، 3 mol H₂، 3 mol H₂O می‌سازد.",
    "v3_chem_17_07" to "درصد بازده=(جرم واقعی÷جرم نظری)×100=(30 g÷40 g)×100=75٪. نسبت g/g بی‌واحد است و نتیجه به‌صورت درصد گزارش می‌شود.",
    "v3_chem_17_09" to "برای 2H₂+O₂→2H₂O، نسبت‌های n/ضریب: H₂ برابر 3÷2=1.5 و O₂ برابر 2÷1=2 است؛ پس H₂ واکنش‌دهندهٔ محدودکننده است. از نسبت 2H₂:2H₂O، 3 mol H₂، 3 mol H₂O می‌سازد.",
    "v3_chem_17_16" to "جرم خالص Mg=0.60×10 g=6 g؛ بنابراین n(Mg)=6 g÷(24 g·mol⁻¹)=0.25 mol. در Mg+2H⁺→Mg²⁺+H₂ نسبت Mg:H₂ یک‌به‌یک است، پس n(H₂)=0.25 mol و در شرایط استاندارد V=0.25 mol×22.4 L·mol⁻¹=5.6 L.",
    "v3_chem_17_17" to "در 2H₂+O₂→2H₂O، 3 mol H₂ به (1÷2)×3=1.5 mol O₂ نیاز دارد؛ چون 2 mol O₂ داریم، H₂ محدودکننده است. آب تولیدی 3 mol و اکسیژن باقی‌مانده=2−1.5=0.5 mol است.",
    "v3_chem_21_15" to "انحلال‌پذیری 30 g در 100 g آب یعنی 130 g محلول از 100 g آب و 30 g حل‌شونده تشکیل می‌شود. ضریب مقیاس=260 g÷130 g=2؛ پس آب=2×100=200 g و حل‌شونده=2×30=60 g.",
    "v3_chem_21_19" to "کاهش انحلال‌پذیری=(40−20) g در 100 g آب=20 g در 100 g آب است. برای 250 g آب: جرم بلور=(20 g÷100 g)×250 g=50 g.",
    "real_1404_n1in_chem_079" to "نسبت فراوانی سبک به سنگین 1:4 است، پس xسنگین=0.80 و جرم سبک=mسنگین−2 amu. میانگین: 28.2=0.20(m−2)+0.80m=m−0.4؛ بنابراین mسنگین=28.6 amu.",
    "v3_chem_18_14" to "جرم میانگین=(24×0.79)+(25×0.10)+(26×0.11)=24.32 amu. سهم ایزوتوپ 26 در 200 اتم=0.11×200=22 اتم است.",
    "v3_chem_18_17" to "اگر x کسر ایزوتوپ سبک باشد، 35x+37(1−x)=35.5؛ پس 37−2x=35.5 و x=0.75=75٪. شمار ایزوتوپ سبک در 400 اتم=0.75×400=300 اتم است.",
    "v3_chem_18_20" to "جرم میانگین 10.2 یعنی کسر ایزوتوپ X-11 برابر 10.2−10=0.2 است. شمار X-11=0.2×500=100 اتم و مجموع عددهای جرمی آن‌ها=100×11=1100.",
    "v3_chem_22_17" to "از pH=2، [H⁺]=10⁻² M است. رقیق‌سازی صدبرابری: [H⁺]نهایی=(10⁻² M)÷100=10⁻⁴ M؛ پس pHنهایی=−log(10⁻⁴)=4.",
    "v3_chem_22_18" to "pOHآغازین=14−12=2، پس [OH⁻]آغازین=10⁻² M. پس از رقیق‌سازی ده‌برابری، [OH⁻]=10⁻³ M و pOH=3؛ در 25°C، pH=14−3=11.",
    "v3_chem_23_02" to "سرعت متوسط=|ΔC|÷Δt=(0.60 M)÷(20 s)=0.030 M·s⁻¹.",
    "v3_chem_23_06" to "سرعت متوسط=|ΔC|÷Δt=(0.60 M)÷(20 s)=0.030 M·s⁻¹.",
    "v3_chem_23_10" to "سرعت متوسط=|ΔC|÷Δt=(0.60 M)÷(20 s)=0.030 M·s⁻¹.",
    "v3_chem_23_13" to "در 2N₂O₅→4NO₂+O₂، نسبت ضرایب N₂O₅:NO₂:O₂ برابر 2:4:1 است. پس r(NO₂)=(4÷2)×0.030=0.060 M·s⁻¹ و r(O₂)=(1÷2)×0.030=0.015 M·s⁻¹.",
    "real_1404_n1in_chem_105" to "نیم‌واکنش‌ها: MnO₂+4H⁺+2e⁻→Mn²⁺+2H₂O و NO+2H₂O→NO₃⁻+4H⁺+3e⁻. معادلهٔ نهایی: 3MnO₂+4H⁺+2NO→3Mn²⁺+2H₂O+2NO₃⁻. مجموع ضرایب 16 است؛ اما جمع عددهای اکسایش Mn برابر +4+(+2)=+6 و برای N برابر +2+(+5)=+7 است، پس گزینهٔ ۳ نادرست است.",
)

private fun correctedCorrectAnalysis(id: String, fallback: String): String =
    correctedChemistryAnalyses[id] ?: learnerFacingText(fallback)

private fun normalizedPracticeText(value: String): String =
    Normalizer.normalize(value, Normalizer.Form.NFKC)
        .replace('ي', 'ی')
        .replace('ك', 'ک')
        .lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}+−-]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

private val nonSemanticStemFrames = listOf(
    "داده‌های زیر را با مدل مناسب پیوند دهید. کدام مقدار پس از کنترل واحد و شرط به‌دست می‌آید؟",
    "برای حل مسئلهٔ زیر، کدام پاسخ نهایی با مسیر کنترل درست جفت شده است؟",
).map(::normalizedPracticeText)

private fun practiceCoreStem(value: String): String =
    nonSemanticStemFrames.fold(normalizedPracticeText(value)) { core, frame -> core.replace(frame, "").trim() }

data class Question(
    val id: String,
    val subject: String,
    val microtopic: String,
    val sourceType: String,
    val sourceFile: String?,
    val sourcePage: Int?,
    val difficulty: Int,
    val estimatedSeconds: Int,
    val questionForm: String,
    val scenarioFamily: String,
    val stem: String,
    val options: List<String>,
    val correctIndex: Int,
    val correctAnalysis: String,
    val optionAnalyses: Map<Int, String>,
    val shortLesson: String,
    val fastMethod: String,
    val mainTrap: String,
    val teachingLevel: String,
    val accessPool: String,
    val needsHumanReview: Boolean,
    val eligibleForSafetyEvidence: Boolean,
    val strictOrVerifiedReal: Boolean,
    val sourceCrop: SourceCrop?,
    val tableStimulus: TableStimulus?,
    val comparisonStimulus: ComparisonStimulus?,
) {
    private val stimulusSignature: String
        get() = tableStimulus?.let { table ->
            listOf(table.caption, *table.headers.toTypedArray(), *table.rows.flatten().toTypedArray())
                .joinToString("||", transform = ::normalizedPracticeText)
        } ?: comparisonStimulus?.let { comparison ->
            listOf(comparison.leftLabel, comparison.left, comparison.rightLabel, comparison.right)
                .joinToString("||", transform = ::normalizedPracticeText)
        }.orEmpty()

    val practiceSignature: String
        get() = listOf(practiceCoreStem(stem), stimulusSignature).filter { it.isNotBlank() }.joinToString("||").let { content ->
            if (content.length >= 24) content
            else "$content||${options.map(::normalizedPracticeText).sorted().joinToString("||")}" 
        }
    companion object {
        fun fromJson(raw: String): Question {
            val o = JSONObject(raw)
            val optionsArray = o.getJSONArray("options")
            val options = buildList { for (i in 0 until optionsArray.length()) add(optionsArray.getString(i)) }
            require(options.size == 4) { "Question ${o.optString("id")} does not have four options" }
            val id = o.getString("id")
            val analysesObject = o.getJSONObject("distractor_analyses")
            val analyses = (0..3).associateWith { learnerFacingText(analysesObject.optString(it.toString())) }
            val stimulus = o.optJSONObject("stimulus")
            val crop = if (stimulus?.optString("type") == "official_source_crop") {
                SourceCrop(
                    dataUri = stimulus.optString("source_crop_data_uri"),
                    altText = stimulus.optString("alt_text"),
                    sha256 = stimulus.optString("source_crop_sha256"),
                )
            } else null
            val table = if (stimulus?.optString("type") == "data_table") {
                val headers = stimulus.optJSONArray("headers") ?: JSONArray()
                val rows = stimulus.optJSONArray("rows") ?: JSONArray()
                TableStimulus(
                    caption = stimulus.optString("caption"),
                    headers = buildList { for (index in 0 until headers.length()) add(headers.getString(index)) },
                    rows = buildList {
                        for (rowIndex in 0 until rows.length()) {
                            val row = rows.getJSONArray(rowIndex)
                            add(buildList { for (cellIndex in 0 until row.length()) add(row.getString(cellIndex)) })
                        }
                    },
                )
            } else null
            val comparison = if (stimulus?.optString("type") == "comparison") {
                ComparisonStimulus(
                    leftLabel = stimulus.optString("left_label", "مورد A"),
                    left = stimulus.optString("left"),
                    rightLabel = stimulus.optString("right_label", "مورد B"),
                    right = stimulus.optString("right"),
                )
            } else null
            return Question(
                id = id,
                subject = o.getString("subject"),
                microtopic = o.getString("microtopic"),
                sourceType = o.getString("source_type"),
                sourceFile = o.optString("source_file").takeIf { it.isNotBlank() && it != "null" },
                sourcePage = o.optInt("source_page", -1).takeIf { it >= 0 },
                difficulty = o.optInt("difficulty", 2),
                estimatedSeconds = o.optInt("estimated_solve_time_seconds", 90),
                questionForm = o.optString("question_form"),
                scenarioFamily = o.optString("scenario_family", o.optString("scenario_model")),
                stem = o.getString("stem"),
                options = options,
                correctIndex = o.getInt("correct_index"),
                correctAnalysis = correctedCorrectAnalysis(id, o.getString("correct_analysis")),
                optionAnalyses = analyses,
                shortLesson = learnerFacingText(o.getString("short_lesson")),
                fastMethod = learnerFacingText(o.optString("fast_method", o.optString("start_method"))),
                mainTrap = learnerFacingText(o.optString("main_trap")),
                teachingLevel = o.optString("teaching_ladder_level"),
                accessPool = o.optString("access_pool", "TRAIN"),
                needsHumanReview = o.optBoolean("needs_human_review", false),
                eligibleForSafetyEvidence = o.optBoolean("eligible_for_safety_evidence", true),
                strictOrVerifiedReal = o.optString("teaching_ladder_level") in setOf("L5_STRICT_EXAM", "L6_VERIFIED_REAL") ||
                    (o.optString("source_type") == "real_exam" && o.optBoolean("official_key_verified", true)),
                sourceCrop = crop,
                tableStimulus = table,
                comparisonStimulus = comparison,
            ).also { require(it.correctIndex in 0..3) }
        }
    }
}

data class DayPlan(
    val date: String,
    val day: Int,
    val phase: String,
    val totalStudyMinutes: Int,
    val attemptBudget: Int,
    val microtopics: List<String>,
) {
    companion object {
        fun fromRootJson(raw: String): List<DayPlan> {
            val root = JSONObject(raw)
            return root.keys().asSequence().map { key ->
                val o = root.getJSONObject(key)
                val topics = o.optJSONArray("new_microtopics") ?: JSONArray()
                DayPlan(
                    date = key,
                    day = o.getInt("day"),
                    phase = o.getString("phase"),
                    totalStudyMinutes = o.optInt("total_study_minutes"),
                    attemptBudget = o.optInt("attempt_budget"),
                    microtopics = buildList { for (i in 0 until topics.length()) add(topics.getString(i)) },
                )
            }.sortedBy { it.date }.toList()
        }
    }
}

data class SafetyState(
    val eligible: Boolean,
    val label: String,
    val detail: String,
)
