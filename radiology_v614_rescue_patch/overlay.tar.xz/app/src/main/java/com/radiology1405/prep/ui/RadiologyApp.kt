package com.radiology1405.prep.ui

import android.graphics.BitmapFactory
import android.os.SystemClock
import android.util.Base64
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.radiology1405.prep.AppScreen
import com.radiology1405.prep.R
import com.radiology1405.prep.StudyUiState
import com.radiology1405.prep.StudyViewModel
import com.radiology1405.prep.data.AppSettingsEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.ComparisonStimulus
import com.radiology1405.prep.data.DayPlan
import com.radiology1405.prep.data.ErrorType
import com.radiology1405.prep.data.MasteryEntity
import com.radiology1405.prep.data.MotionMode
import com.radiology1405.prep.data.Question
import com.radiology1405.prep.data.SessionSummary
import com.radiology1405.prep.data.SessionOutcome
import com.radiology1405.prep.data.SimulationResultEntity
import com.radiology1405.prep.data.StudyMode
import com.radiology1405.prep.data.ThemeFamily
import com.radiology1405.prep.engine.RescueMetrics
import com.radiology1405.prep.engine.RescueTier
import com.radiology1405.prep.engine.RescueTopic
import com.radiology1405.prep.engine.RescueUnlockState
import com.radiology1405.prep.ui.UiDensity
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.math.roundToInt

@Composable
fun RadiologyApp(
    viewModel: StudyViewModel,
    onExport: (String) -> Unit,
    onImport: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val experience = remember { ExperienceController(context.applicationContext) }
    DisposableEffect(experience) { onDispose { experience.close() } }
    val view = LocalView.current
    DisposableEffect(experience.settings.keepAwake, experience.focusTimerRunning, state.screen) {
        view.keepScreenOn = experience.settings.keepAwake && (state.screen == AppScreen.STUDY || experience.focusTimerRunning)
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(experience.focusTimerRunning) {
        while (experience.focusTimerRunning) { delay(1000); experience.tickTimer() }
    }
    val theme = ThemeFamily.fromStored(state.settings.theme)
    RadiologyTheme(theme, state.settings.textScale, experience.settings.highContrast, experience.settings.readerFont) {
        androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                if (state.loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                } else {
                    AppScaffold(state, viewModel, onExport, onImport, experience)
                }
                state.message?.let { message ->
                    AlertDialog(
                        onDismissRequest = viewModel::dismissMessage,
                        confirmButton = { TextButton(onClick = viewModel::dismissMessage) { Text("باشه") } },
                        title = { Text("پیام") },
                        text = { ScienceText(message) },
                    )
                }
            }
        }
    }
}

@Composable
private fun AppScaffold(
    state: StudyUiState,
    viewModel: StudyViewModel,
    onExport: (String) -> Unit,
    onImport: () -> Unit,
    experience: ExperienceController,
) {
    val hideChrome = state.screen == AppScreen.STUDY && (state.settings.focusMode || state.settings.longStudyMode || experience.settings.adhdMode)
    Scaffold(
        bottomBar = {
            if (!hideChrome) {
                NavigationBar(Modifier.navigationBarsPadding()) {
                    navItems.forEach { item ->
                        NavigationBarItem(
                            selected = state.screen == item.screen,
                            onClick = { experience.playSfx("select"); experience.haptic(16); viewModel.navigate(item.screen) },
                            icon = { Icon(painterResource(item.icon), contentDescription = item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        val duration = motionDuration(state.settings, experience, screenChange = true)
        Crossfade(targetState = state.screen, animationSpec = androidx.compose.animation.core.tween(duration), label = "screen") { screen ->
            when (screen) {
                AppScreen.HOME -> HomeScreen(state, viewModel, experience, Modifier.padding(padding))
                AppScreen.STUDY -> StudyScreen(state, viewModel, experience, Modifier.padding(padding))
                AppScreen.MEMORY -> MemoryScreen(state.mastery, Modifier.padding(padding))
                AppScreen.PLAN -> PlanScreen(state, viewModel, Modifier.padding(padding))
                AppScreen.SETTINGS -> SettingsScreen(state.settings, viewModel, onExport, onImport, experience, Modifier.padding(padding))
            }
        }
    }
}

private data class NavItem(val screen: AppScreen, val icon: Int, val label: String)
private val navItems = listOf(
    NavItem(AppScreen.HOME, R.drawable.ic_nav_home, "امروز"),
    NavItem(AppScreen.MEMORY, R.drawable.ic_nav_memory, "حافظه"),
    NavItem(AppScreen.PLAN, R.drawable.ic_nav_plan, "برنامه"),
    NavItem(AppScreen.SETTINGS, R.drawable.ic_nav_settings, "تنظیمات"),
)

private fun motionDuration(settings: AppSettingsEntity, experience: ExperienceController, screenChange: Boolean): Int {
    if (settings.longStudyMode || experience.settings.reducedMotion || experience.settings.adhdMode) return 0
    return when (runCatching { MotionMode.valueOf(settings.motion) }.getOrDefault(MotionMode.CALM)) {
        MotionMode.MINIMAL -> 0
        MotionMode.CALM -> if (screenChange) 130 else 110
        MotionMode.DYNAMIC -> if (screenChange) 230 else 190
        MotionMode.LIVELY -> if (screenChange) 320 else 250
    }
}

@Composable
private fun ActionLabel(iconRes: Int, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(painterResource(iconRes), contentDescription = null, modifier = Modifier.width(20.dp).height(20.dp))
        Text(text)
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        subtitle?.let { ScienceText(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun HomeScreen(state: StudyUiState, viewModel: StudyViewModel, experience: ExperienceController, modifier: Modifier = Modifier) {
    val plan = state.plan
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { PageTitle("رادیولوژی ۱۴۰۵", "برنامهٔ نجات واقعی تا آزمون تجربی ۲۹ مرداد؛ بدون ادعای قبولی قطعی") }
        if (state.allPlans.isNotEmpty()) item { DaySelector(state.allPlans, state.selectedPlanDate, state.todayPlanDate, viewModel::selectDay) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("روز انتخاب‌شده: ${fa(plan?.day ?: 0)} از ${fa(state.allPlans.size)}", Modifier.testTag("selected_day_label"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(plan?.date?.let(::persianDate) ?: "—")
                    Text(phaseFa(plan?.phase.orEmpty()), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (plan != null) {
                        Text("بار مطالعه: ${fa(plan.totalStudyMinutes)} دقیقه • حداقل خواب: ۶٫۵ ساعت")
                        if (plan.attemptBudget > 0) Text("بودجهٔ اجباری: ${fa(plan.attemptBudget)} سؤال؛ تمرین در بلوک ۱۵تایی و SIM مستقل")
                    } else {
                        Text("امروز خارج از بازهٔ واقعی برنامه است؛ ریزمبحث یا جلسهٔ تازه ساخته نمی‌شود.")
                    }
                }
            }
        }
        state.rescueMetrics?.let { metrics ->
            item { RescueScopeCard(metrics, state.rescueUnlock) }
        }
        if (state.todayPlanDate != null && state.selectedPlanDate != state.todayPlanDate) item {
            OutlinedButton(onClick = viewModel::selectToday, modifier = Modifier.fillMaxWidth()) { Text("بازگشت به امروز") }
        }
        if (state.session != null && state.session.entity.phase != "done" && state.plan?.date != state.session.entity.date) item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Text("یک جلسهٔ فعال از ${persianDate(state.session.entity.date)} حفظ شده است؛ دکمهٔ شروع ابتدا همان جلسه را ادامه می‌دهد تا پیشرفت دو روز قاطی نشود.", Modifier.padding(14.dp))
            }
        }
        item { FocusTimerCard(experience) }
        if (state.mastery.isNotEmpty()) item { WeaknessPreview(state.mastery, viewModel) }
        item {
            Card {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Learning / Performance Safety", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(state.safety.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ScienceText(state.safety.detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("SIM1", "SIM2").forEach { pool ->
                            val result = state.simulations.firstOrNull { it.pool == pool }
                            AssistChip(
                                onClick = {},
                                label = { Text(if (result == null) "$pool قفل/انجام‌نشده" else "$pool ${if (result.passed) "پاس" else "نیازمند ترمیم"}") },
                            )
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Admission Safety Estimate", fontWeight = FontWeight.Bold)
                    ScienceText(
                        "فعلاً غیرفعال است: سوابق رسمی درس‌به‌درس، سهمیه/منطقه، ظرفیت و دفترچهٔ انتخاب‌رشتهٔ ۱۴۰۵ و نتیجهٔ هر دو شبیه‌ساز لازم است. این بخش هرگز «قبولی تضمینی» نشان نمی‌دهد.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        state.simulations.forEach { result -> item { RemediationCard(result) } }
        item {
            Button(
                onClick = viewModel::startOrResume,
                enabled = plan != null || (state.session != null && state.session.entity.phase != "done"),
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                Text(if (state.session != null && state.session.entity.phase != "done") "ادامهٔ دقیق جلسه" else "شروع بلوک روز ${fa(plan?.day ?: 0)}")
            }
        }
        if (state.session?.entity?.phase == "test") item {
            OutlinedButton(onClick = viewModel::restartUnsubmittedSession, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("بازسازی بلوک ثبت‌نشده")
            }
        }
        if (plan?.microtopics?.isNotEmpty() == true) {
            item { Text("ریزموضوع‌های روز انتخاب‌شده", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(plan.microtopics) { topic ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("•", color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    ScienceText("A • $topic")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                ScienceText(
                    "اولویت نجات: غلط ← سفید ← نامطمئن ← خطای تکراری ← تسلط کمِ پُربازده ← مرور سررسید ← مبحث جدید.",
                    Modifier.padding(16.dp),
                )
            }
        }
    }
}

@Composable
private fun RescueScopeCard(metrics: RescueMetrics, unlock: RescueUnlockState?) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("دامنهٔ نجات سه‌روزه", fontWeight = FontWeight.Bold)
            Text(
                "A ${fa(metrics.mandatoryMicrotopics)} اجباری • B ${fa(metrics.secondaryMicrotopics)} مشروط • " +
                    "C ${fa(metrics.lowPriorityMicrotopics)} فقط وقت اضافه • Q ${fa(metrics.quarantinedMicrotopics)} ریزمبحث کامل",
            )
            Text(
                "کاهش مسیر اجباری ${fa(metrics.mandatoryScopeReductionPercent.roundToInt())}٪ • " +
                    "زمان ${fa(metrics.studyTimeReductionPercent.roundToInt())}٪ • سؤال ${fa(metrics.questionBudgetReductionPercent.roundToInt())}٪",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            Text("۱۶ سؤال تعارض‌کلید در Q بانک می‌مانند و هرگز وارد Safety یا SIM نمی‌شوند.")
            unlock?.let { ScienceText(it.detail, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun FocusTimerCard(experience: ExperienceController) {
    val minutes = experience.focusRemainingSeconds / 60
    val seconds = experience.focusRemainingSeconds % 60
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("تمرکز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${fa(minutes)}:${fa(seconds).padStart(2, '۰')}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(if (experience.focusTimerRunning) "در حال تمرکز" else if (experience.focusRemainingSeconds == 0) "تمام شد" else "آماده", color = MaterialTheme.colorScheme.onSurfaceVariant)
            SettingChoices("زمان", listOf(15,25,40), experience.settings.focusMinutes.toString(), { it.toString() }, { "${fa(it)} دقیقه" }) { experience.setFocusMinutes(it) }
            SettingChoices("صدای تمرکز", focusTracks, experience.settings.focusTrack, { it.first }, { it.second }) { (key,_) -> experience.setFocusTrack(key, autoPreview = true) }
            if (experience.settings.focusTrack != "none") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = experience::toggleFocus, modifier = Modifier.weight(1f).height(48.dp)) { Text(if (experience.focusPlaying) "مکث صدا" else "پخش صدا") }
                    TextButton(onClick = { experience.setFocusTrack("none", autoPreview = false) }, modifier = Modifier.weight(1f).height(48.dp)) { Text("بدون صدا") }
                }
                Text(if (experience.focusPlaying) "● در حال پخش • آفلاین" else "آمادهٔ پخش", color = if (experience.focusPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            experience.focusError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = experience::startPauseTimer, modifier = Modifier.weight(1f).height(52.dp)) { Text(if (experience.focusTimerRunning) "مکث" else "شروع") }
                OutlinedButton(onClick = experience::resetTimer, modifier = Modifier.weight(1f).height(52.dp)) { Text("ریست") }
            }
        }
    }
}

@Composable
private fun WeaknessPreview(values: List<MasteryEntity>, viewModel: StudyViewModel) {
    val weak = values.sortedWith(compareByDescending<MasteryEntity> { it.recurringError != null }.thenBy { it.mastery }).take(3)
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("ضعف‌های فعلی", fontWeight = FontWeight.Bold)
            weak.forEach { Text("• ${it.microtopic} • تسلط ${fa((it.mastery*100).roundToInt())}٪") }
            TextButton(onClick = { viewModel.navigate(AppScreen.MEMORY) }) { Text("باز کردن نقشهٔ ضعف و حافظه") }
        }
    }
}

@Composable
private fun RemediationCard(result: SimulationResultEntity) {
    val labels = linkedMapOf(
        "high_ROI_wrong" to "غلط پُربازده",
        "blank" to "سفید",
        "unsure" to "نامطمئن",
        "recurring_trap" to "دام تکراری",
        "time_loss" to "اتلاف زمان",
        "prerequisite_failure" to "شکاف پیش‌نیاز",
        "low_confidence_correct" to "درست کم‌اطمینان",
    )
    val map = runCatching { JSONObject(result.remediationJson) }.getOrDefault(JSONObject())
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("نقشهٔ ترمیم ${result.pool}", fontWeight = FontWeight.Bold)
            labels.forEach { (key, label) ->
                val count = map.optJSONArray(key)?.length() ?: 0
                Text("$label: ${fa(count)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun StudyScreen(state: StudyUiState, viewModel: StudyViewModel, experience: ExperienceController, modifier: Modifier = Modifier) {
    val summary = state.session
    if (summary == null || summary.entity.phase == "done") {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("جلسهٔ فعالی نیست")
                Button(onClick = { experience.playSfx("focus_start"); experience.haptic(); viewModel.startOrResume() }) { ActionLabel(R.drawable.ic_action_start, "شروع") }
                TextButton(onClick = { viewModel.navigate(AppScreen.HOME) }) { Text("بازگشت") }
            }
        }
        return
    }
    val position = if (summary.entity.phase == "review") summary.entity.reviewPosition else summary.entity.position
    val question = summary.currentQuestion
    if (question == null) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("سؤال بانک پیدا نشد") }
        return
    }
    Column(modifier.fillMaxSize()) {
        StudyHeader(summary, position, state.settings, viewModel)
        if (experience.settings.focusTrack != "none") FocusAudioStrip(experience)
        val breakBoundary = if (summary.entity.phase == "test" && state.settings.breaksEnabled) {
            experience.breakRevision
            experience.dueBreak(summary.entity.date, state.submittedToday + summary.answered, state.settings.breakEvery)
        } else null
        if (breakBoundary != null) BreakReminderBanner(summary.entity.date, breakBoundary, experience)
        val duration = motionDuration(state.settings, experience, screenChange = false)
        val cueKind = if (summary.entity.phase == "test") viewModel.cueKind(summary, question.id) else null
        AnimatedContent(
            targetState = "${summary.entity.phase}-${question.id}-${cueKind.orEmpty()}",
            transitionSpec = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(duration)) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(duration)) },
            label = "question",
            modifier = Modifier.weight(1f),
        ) { target ->
            when {
                target.startsWith("review-") ->
                    ReviewQuestion(summary, question, state.outcome, viewModel, experience, Modifier.fillMaxSize())
                cueKind != null && target.endsWith("-${cueKind}") ->
                    PrimerCue(question, cueKind, viewModel, Modifier.fillMaxSize())
                else ->
                    TestQuestion(summary, question, viewModel, experience, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun BreakReminderBanner(date: String, boundary: Int, experience: ExperienceController) {
    LaunchedEffect(boundary) {
        experience.playSfx("focus_end")
        experience.haptic(24)
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("استراحت کوتاه", fontWeight = FontWeight.Bold)
                Text("${fa(boundary)} پاسخ ثبت شده؛ حدود ۲ دقیقه چشم و گردن را از صفحه آزاد کن. این یادآور آزمون را قفل نمی‌کند.", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { experience.acknowledgeBreak(date, boundary) }) { Text("ادامه") }
        }
    }
}

@Composable
private fun PrimerCue(question: Question, kind: String, viewModel: StudyViewModel, modifier: Modifier = Modifier) {
    val seconds = when (kind) {
        "spaced" -> 30
        "orientation" -> 60
        else -> 90
    }
    val title = when (kind) {
        "spaced" -> "بازیابی ۳۰ ثانیه‌ای"
        "orientation" -> "جهت‌گیری ۶۰ ثانیه‌ای"
        "guided" -> "ترمیم هدایت‌شدهٔ ۹۰ ثانیه‌ای"
        else -> "پیش‌نیاز کوتاه ۹۰ ثانیه‌ای"
    }
    val detail = when (kind) {
        "spaced" -> "اول نکته را از حافظه بازسازی کن؛ سپس سؤال بدون راهنما آزموده می‌شود."
        "orientation" -> "${question.microtopic} چیست و سؤال کنکور معمولاً چه می‌خواهد؟ فقط نقشهٔ ورود را ببین، نه درس کامل."
        "guided" -> "پس از غلط، سفید یا نامطمئن، تست پشت تست ممنوع است: سوءبرداشت را ببند، گام حل را ببین، سپس دوباره پاسخ بده."
        else -> "فقط پیش‌نیاز لازم برای ورود به این سؤال؛ نه آموزش طولانی."
    }
    LaunchedEffect(question.id, kind) {
        delay(seconds * 1000L)
        viewModel.dismissCue()
    }
    Box(modifier.padding(18.dp), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    detail,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                ScienceText(question.shortLesson)
                if (question.fastMethod.isNotBlank()) ScienceText(if (kind == "guided") "گام هدایت‌شده: ${question.fastMethod}" else "راه شروع: ${question.fastMethod}")
                if (question.mainTrap.isNotBlank()) ScienceText("دام: ${question.mainTrap}")
                Button(onClick = viewModel::dismissCue, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("راهنما را ببند و سؤال را شروع کن") }
            }
        }
    }
}

@Composable
private fun StudyHeader(summary: SessionSummary, position: Int, settings: AppSettingsEntity, viewModel: StudyViewModel) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { viewModel.navigate(AppScreen.HOME) }) { Text("خانه") }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${fa(position + 1)} از ${fa(summary.total)}", fontWeight = FontWeight.Bold)
                if (!settings.longStudyMode) Text("بخش ${fa(position / 10 + 1)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (summary.entity.phase == "review") "تحلیل" else summary.entity.pool)
        }
        LinearProgressIndicator(
            progress = { (position + 1f) / summary.total.coerceAtLeast(1) },
            modifier = Modifier.fillMaxWidth().height(4.dp),
        )
        if (!settings.longStudyMode) QuestionNavigator(summary, viewModel, summary.entity.phase == "review")
    }
}

@Composable
private fun TestQuestion(summary: SessionSummary, question: Question, viewModel: StudyViewModel, experience: ExperienceController, modifier: Modifier = Modifier) {
    DisposableEffect(question.id) {
        val started = SystemClock.elapsedRealtime()
        onDispose {
            val seconds = ((SystemClock.elapsedRealtime() - started) / 1000L).toInt()
            if (seconds > 0) viewModel.addElapsed(question.id, seconds)
        }
    }
    val order = viewModel.optionOrder(summary, question.id)
    val selectedOriginal = viewModel.selectedOriginal(summary, question.id)
    val confidence = viewModel.confidence(summary, question.id)
    val flagged = viewModel.isFlagged(summary, question.id)
    val selectedDisplay = order.indexOf(selectedOriginal).takeIf { it >= 0 }
    val compact = UiDensity.from(experience.settings.density) == UiDensity.COMPACT
    val contentPad = if (compact) 11.dp else 16.dp
    val itemGap = if (compact) 8.dp else 12.dp
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(contentPad),
        verticalArrangement = Arrangement.spacedBy(itemGap),
    ) {
        item { MetaLine(question) }
        question.sourceCrop?.let { crop -> item { SourceCropImage(crop.dataUri, crop.altText) } }
        question.comparisonStimulus?.let { stimulus -> item { ComparisonStimulusCard(stimulus) } }
        item {
            Card {
                ScienceText(
                    question.stem,
                    Modifier.fillMaxWidth().padding(if (compact) 14.dp else 18.dp),
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
        items(order.indices.toList()) { displayIndex ->
            val original = order[displayIndex]
            val chosen = selectedDisplay == displayIndex
            Surface(
                color = if (chosen) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .sizeIn(minHeight = 56.dp)
                    .clickable { experience.playSfx("select"); experience.haptic(14); viewModel.selectDisplay(displayIndex) }
                    .border(if (chosen) 2.dp else 0.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(14.dp)),
            ) {
                Row(Modifier.padding(if (compact) 11.dp else 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(fa(displayIndex + 1), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    ScienceText(question.options[original], Modifier.weight(1f))
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = confidence == Confidence.CONFIDENT, onClick = { viewModel.setConfidence(Confidence.CONFIDENT) }, label = { Text("مطمئن") }) }
                item { FilterChip(selected = confidence == Confidence.UNSURE, onClick = { viewModel.setConfidence(Confidence.UNSURE) }, label = { Text("نامطمئن (+۴)") }) }
                item { FilterChip(selected = flagged, onClick = viewModel::toggleFlag, label = { Text(if (flagged) "نشان‌دار" else "نشان") }) }
                if (selectedOriginal != null) item { AssistChip(onClick = viewModel::clearAnswer, label = { Text("پاک کردن پاسخ") }) }
            }
        }
        item { NavigationControls(summary, viewModel, review = false, experience = experience) }
        item {
            OutlinedButton(onClick = { experience.playSfx("submit"); experience.haptic(34); viewModel.submit() }, Modifier.fillMaxWidth().height(52.dp)) { ActionLabel(R.drawable.ic_action_submit, "ثبت آزمون و دیدن تحلیل") }
        }
    }
}

@Composable
internal fun ComparisonStimulusCard(stimulus: ComparisonStimulus) {
    Card(Modifier.fillMaxWidth().testTag("comparison_stimulus")) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("عبارت‌های سؤال", fontWeight = FontWeight.Bold)
            Text(stimulus.leftLabel, fontWeight = FontWeight.SemiBold)
            ScienceText(stimulus.left)
            HorizontalDivider()
            Text(stimulus.rightLabel, fontWeight = FontWeight.SemiBold)
            ScienceText(stimulus.right)
        }
    }
}

@Composable
private fun ReviewQuestion(summary: SessionSummary, question: Question, outcome: SessionOutcome?, viewModel: StudyViewModel, experience: ExperienceController, modifier: Modifier = Modifier) {
    val selected = viewModel.selectedOriginal(summary, question.id)
    val confidence = viewModel.confidence(summary, question.id)
    val status = when { selected == null -> "سفید"; selected == question.correctIndex -> "درست"; else -> "غلط" }
    val quickReview = status == "درست" && confidence == Confidence.CONFIDENT
    val expanded = remember(question.id, quickReview) {
        mutableStateMapOf<Int, Boolean>().apply { if (!quickReview) (0..3).forEach { put(it, true) } }
    }
    var correctOpen by remember(question.id, quickReview) { mutableStateOf(!quickReview) }
    var lessonOpen by remember(question.id, quickReview) { mutableStateOf(!quickReview) }
    LaunchedEffect(question.id) {
        if (!quickReview) viewModel.markAnalysesSeen()
        experience.playSfx(if (status == "درست") "correct" else "wrong")
        experience.haptic(if (status == "درست") 18 else 42)
    }
    val compact = UiDensity.from(experience.settings.density) == UiDensity.COMPACT
    val contentPad = if (compact) 11.dp else 16.dp
    val itemGap = if (compact) 8.dp else 12.dp
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(contentPad),
        verticalArrangement = Arrangement.spacedBy(itemGap),
    ) {
        item { MetaLine(question) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = if (status == "درست") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("نتیجه: $status • ${confidence.fa}", fontWeight = FontWeight.Bold)
                    Text("انتخاب شما: ${selected?.let { fa(it + 1) } ?: "بدون پاسخ"}")
                    Text("پاسخ درست: ${fa(question.correctIndex + 1)}")
                }
            }
        }
        question.sourceCrop?.let { crop -> item { SourceCropImage(crop.dataUri, crop.altText) } }
        question.comparisonStimulus?.let { stimulus -> item { ComparisonStimulusCard(stimulus) } }
        item { Card { ScienceText(question.stem, Modifier.padding(18.dp), style = MaterialTheme.typography.bodyLarge) } }
        if (quickReview) item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("مرور سریع؛ وقت را روی سؤال بلدشده مصرف نکن", fontWeight = FontWeight.Bold)
                    ScienceText("نکتهٔ کلیدی: ${question.shortLesson}")
                    ScienceText("دام: ${question.mainTrap.ifBlank { "دام ثبت‌شده‌ای ندارد." }}")
                    ScienceText("راه سریع: ${question.fastMethod.ifBlank { "روش سریع جداگانه‌ای ثبت نشده است." }}")
                }
            }
        }
        item {
            DisclosureCard(
                if (quickReview) "تحلیل کامل پاسخ درست (اختیاری)" else "تحلیل پاسخ درست",
                correctOpen,
                {
                    if (!correctOpen) viewModel.markAnalysesSeen()
                    correctOpen = !correctOpen
                },
            ) {
                ScienceText(question.correctAnalysis)
            }
        }
        items((0..3).toList()) { original ->
            val isCorrect = original == question.correctIndex
            val wasSelected = original == selected
            DisclosureCard(
                title = "گزینهٔ ${fa(original + 1)}${if (wasSelected) " • انتخاب شما" else ""}${if (isCorrect) " • درست" else ""}",
                expanded = expanded[original] == true,
                onToggle = {
                    if (expanded[original] != true) viewModel.markAnalysesSeen()
                    expanded[original] = !(expanded[original] ?: false)
                },
            ) {
                Text(if (isCorrect) "چرا درست است؟" else "چرا وسوسه‌انگیز است و چرا نادرست است؟", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                ScienceText(question.optionAnalyses[original].orEmpty())
            }
        }
        item {
            DisclosureCard("درس کوتاه، راه سریع و دام", lessonOpen, { lessonOpen = !lessonOpen }) {
                Text("درس کوتاه", fontWeight = FontWeight.Bold); ScienceText(question.shortLesson)
                Spacer(Modifier.height(10.dp)); Text("راه سریع", fontWeight = FontWeight.Bold); ScienceText(question.fastMethod.ifBlank { "در منبع ثبت نشده است." })
                Spacer(Modifier.height(10.dp)); Text("دام اصلی", fontWeight = FontWeight.Bold); ScienceText(question.mainTrap.ifBlank { "در منبع ثبت نشده است." })
            }
        }
        if (!quickReview) item {
            ErrorTypePicker(viewModel.errorType(summary, question.id), viewModel::setErrorType)
        }
        item { SourceAndTime(question, summary) }
        if (summary.entity.reviewPosition == summary.total - 1 && outcome != null) item { SessionOutcomeCard(outcome) }
        item { NavigationControls(summary, viewModel, review = true, experience = experience) }
    }
}

@Composable
private fun DisclosureCard(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit = {},
    content: @Composable () -> Unit,
) {
    Card(Modifier.fillMaxWidth().animateContentSize()) {
        Column {
            Row(
                Modifier.fillMaxWidth().sizeIn(minHeight = 52.dp).clickable(onClick = onToggle).padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(if (expanded) "−" else "+")
            }
            AnimatedVisibility(expanded) {
                Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 16.dp), content = { content() })
            }
        }
    }
}

@Composable
private fun ErrorTypePicker(selected: ErrorType?, onSelect: (ErrorType?) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("نوع خطا (برای اولویت مرور)", fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ErrorType.entries) { type ->
                FilterChip(selected = selected == type, onClick = { onSelect(if (selected == type) null else type) }, label = { Text(type.fa) })
            }
        }
    }
}

@Composable
private fun QuestionNavigator(summary: SessionSummary, viewModel: StudyViewModel, review: Boolean) {
    val current = if (review) summary.entity.reviewPosition else summary.entity.position
    val answers = remember(summary.entity.answersJson) { runCatching { JSONObject(summary.entity.answersJson) }.getOrDefault(JSONObject()) }
    val flags = remember(summary.entity.flagsJson) { runCatching { JSONObject(summary.entity.flagsJson) }.getOrDefault(JSONObject()) }
    val ids = remember(summary.entity.questionIdsJson) {
        val a = org.json.JSONArray(summary.entity.questionIdsJson); (0 until a.length()).map { a.getString(it) }
    }
    LazyRow(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        items(ids.indices.toList()) { index ->
            val id=ids[index]; val marked=flags.optBoolean(id); val answered=answers.has(id)
            FilterChip(selected=index==current, onClick={viewModel.goTo(index)}, label={ Text("${if(marked) "⚑" else if(answered) "✓" else ""}${fa(index+1)}") })
        }
    }
}

@Composable
private fun SessionOutcomeCard(outcome: SessionOutcome) {
    val pct = if(outcome.total==0) 0 else ((outcome.correct*100.0)/outcome.total).roundToInt()
    Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("جمع‌بندی بلوک", fontWeight=FontWeight.Bold)
            Text("درست ${fa(outcome.correct)} • غلط ${fa(outcome.wrong)} • سفید ${fa(outcome.blank)} • خام ${fa(pct)}٪")
            outcome.bySubject.toSortedMap().forEach { (subject,row) -> Text("$subject: ${fa(row.correct)} درست، ${fa(row.wrong)} غلط، ${fa(row.blank)} سفید") }
        }
    }
}

@Composable
private fun NavigationControls(summary: SessionSummary, viewModel: StudyViewModel, review: Boolean, experience: ExperienceController) {
    val position = if (review) summary.entity.reviewPosition else summary.entity.position
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = { viewModel.move(-1) }, enabled = position > 0, modifier = Modifier.weight(1f).height(52.dp)) { Text("قبلی") }
        if (review && position == summary.total - 1) {
            Button(onClick = { experience.playSfx("complete"); experience.haptic(48); viewModel.finishReview() }, modifier = Modifier.weight(1f).height(52.dp)) { ActionLabel(R.drawable.ic_action_complete, "پایان تحلیل") }
        } else {
            Button(onClick = { viewModel.move(1) }, enabled = position < summary.total - 1, modifier = Modifier.weight(1f).height(52.dp)) { Text("بعدی") }
        }
    }
}

@Composable
private fun MetaLine(question: Question) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { AssistChip(onClick = {}, label = { Text(question.subject) }) }
        item { AssistChip(onClick = {}, label = { Text(question.microtopic) }) }
        item { AssistChip(onClick = {}, label = { Text("سطح ${question.teachingLevel.ifBlank { "—" }}") }) }
        item { AssistChip(onClick = {}, label = { Text("${fa(question.estimatedSeconds)} ثانیه") }) }
    }
}

@Composable
private fun SourceAndTime(question: Question, summary: SessionSummary) {
    val elapsed = runCatching { JSONObject(summary.entity.elapsedJson).optInt(question.id) }.getOrDefault(0)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("منبع و زمان", fontWeight = FontWeight.Bold)
            Text(
                "نوع: ${when (question.sourceType) {
                    "real_exam" -> "کنکور واقعیِ راستی‌آزمایی‌شده"
                    "official_exam_stem_training" -> "صورت رسمی؛ کلید مستقل هنوز قطعی نیست (فقط آموزش)"
                    "quarantined_key_conflict" -> "قرنطینهٔ تعارض کلید؛ غیرقابل استفاده"
                    else -> "تألیفی آموزشی"
                }}"
            )
            question.sourceFile?.let { ScienceText("فایل: $it${question.sourcePage?.let { p -> " • صفحه ${fa(p)}" } ?: ""}") }
            Text("زمان ثبت‌شده: ${fa(elapsed)} ثانیه • برآورد: ${fa(question.estimatedSeconds)} ثانیه")
            Text("سختی: ${fa(question.difficulty)} • فرم: ${question.questionForm.ifBlank { "ثبت‌نشده" }}")
        }
    }
}

@Composable
private fun SourceCropImage(dataUri: String, alt: String) {
    var showZoom by remember(dataUri) { mutableStateOf(false) }
    var zoom by remember(dataUri) { mutableStateOf(1f) }
    val bitmap = remember(dataUri) {
        runCatching {
            val bytes = Base64.decode(dataUri.substringAfter("base64,"), Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }.getOrNull()
    }
    Card {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("برش منبع رسمی", fontWeight = FontWeight.Bold)
            bitmap?.let {
                Image(
                    it,
                    contentDescription = "$alt؛ برای بزرگ‌نمایی لمس کنید",
                    modifier = Modifier
                        .fillMaxWidth()
                        .sizeIn(minHeight = 48.dp)
                        .clickable { showZoom = true },
                )
                TextButton(onClick = { showZoom = true }) { Text("بزرگ‌نمایی برش") }
            }
                ?: Text("نمایش برش ممکن نشد؛ متن سؤال همچنان در دسترس است.")
            ScienceText(alt, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (showZoom && bitmap != null) {
        AlertDialog(
            onDismissRequest = { showZoom = false },
            confirmButton = { TextButton(onClick = { showZoom = false }) { Text("بستن") } },
            title = { Text("بزرگ‌نمایی منبع رسمی") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Image(
                            bitmap,
                            contentDescription = alt,
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer(scaleX = zoom, scaleY = zoom),
                        )
                    }
                    Text("بزرگ‌نمایی ${fa((zoom * 100).roundToInt())}٪")
                    Slider(
                        value = zoom,
                        onValueChange = { zoom = it },
                        valueRange = 1f..4f,
                        steps = 5,
                    )
                }
            },
        )
    }
}

@Composable
private fun MemoryScreen(values: List<MasteryEntity>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageTitle("حافظه و تسلط", "حافظه از تسلط جداست؛ درستِ نامطمئن تسلط کامل محسوب نمی‌شود.") }
        if (values.isEmpty()) item { Text("پس از نخستین بلوک، شاخص‌های واقعی اینجا ساخته می‌شوند.") }
        items(values, key = { it.microtopic }) { value -> MasteryCard(value) }
    }
}

@Composable
private fun MasteryCard(value: MasteryEntity) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(value.microtopic, fontWeight = FontWeight.Bold)
            Text(value.subject, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("تسلط ${fa((value.mastery * 100).roundToInt())}٪")
            LinearProgressIndicator(progress = { value.mastery.toFloat() }, modifier = Modifier.fillMaxWidth())
            Text("قدرت حافظه ${fa((value.memoryStrength * 100).roundToInt())}٪")
            LinearProgressIndicator(progress = { value.memoryStrength.toFloat() }, modifier = Modifier.fillMaxWidth())
            Text("${fa(value.distinctQuestions)} سؤال متمایز • ${fa(value.examAttempts)} انتقال آزمونی")
            value.recurringError?.let { key -> Text("خطای تکراری: ${ErrorType.entries.firstOrNull { it.key == key }?.fa ?: key}", color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun PlanScreen(state: StudyUiState, viewModel: StudyViewModel, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageTitle("برنامهٔ واقعی سه‌روزه", "کمتر ببین، بیشتر بلد باش؛ B مشروط است و C فقط با عملکرد عالی و وقت واقعی باز می‌شود.") }
        item { DaySelector(state.allPlans, state.selectedPlanDate, state.todayPlanDate, viewModel::selectDay) }
        state.rescueMetrics?.let { metrics -> item { RescueScopeCard(metrics, state.rescueUnlock) } }
        listOf(RescueTier.A, RescueTier.B, RescueTier.C).forEach { tier ->
            val topics = state.rescueTopics.filter { it.tier == tier }
            if (topics.isNotEmpty()) item(key = "tier_${tier.name}") { RescueTierCard(tier, topics) }
        }
        items(state.allPlans, key = { it.date }) { plan ->
            val selected = plan.date == state.selectedPlanDate
            Card(
                modifier = Modifier.fillMaxWidth().clickable { viewModel.selectDay(plan.date) }.testTag("plan_day_${plan.day}"),
                colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("روز ${fa(plan.day)} • ${persianDate(plan.date)}${if (plan.date == state.todayPlanDate) " • امروز" else ""}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(phaseFa(plan.phase))
                    Text("${fa(plan.totalStudyMinutes)} دقیقه • خواب کمتر از ۶٫۵ ساعت ممنوع", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (plan.attemptBudget > 0) Text("${fa(plan.attemptBudget)} سؤال اجباری • ${fa(plan.microtopics.size)} ریزمبحث A تازه")
                    when (plan.day) {
                        1 -> Text("یادگیری A و بازیابی همان‌روز؛ بدون شبیه‌ساز.", color = MaterialTheme.colorScheme.primary)
                        2 -> Text("۳۰ تمرین A، سپس SIM1 مستقل و ۱۵ ترمیم؛ بدون پیش‌نمایش.", color = MaterialTheme.colorScheme.primary)
                        3 -> Text("SIM2 مستقل، سپس ۱۵ ترمیم فاصله‌دار؛ مبحث تازه ممنوع.", color = MaterialTheme.colorScheme.primary)
                    }
                    Text(if (selected) "انتخاب‌شده" else "لمس برای انتخاب", color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun RescueTierCard(tier: RescueTier, topics: List<RescueTopic>) {
    var open by remember(tier) { mutableStateOf(tier == RescueTier.A) }
    DisclosureCard(
        "${tier.fa} • ${fa(topics.size)} ریزمبحث",
        open,
        { open = !open },
    ) {
        topics.forEach { topic ->
            ScienceText("• ${topic.profile.subject} — ${topic.profile.microtopic}")
            Spacer(Modifier.height(5.dp))
        }
    }
}

@Composable
private fun DaySelector(plans: List<DayPlan>, selectedDate: String?, todayDate: String?, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("انتخاب روز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.testTag("day_selector")) {
            items(plans, key = { it.date }) { plan ->
                FilterChip(
                    selected = plan.date == selectedDate,
                    onClick = { onSelect(plan.date) },
                    modifier = Modifier.testTag("day_chip_${plan.day}"),
                    label = { Text("روز ${fa(plan.day)}${if (plan.date == todayDate) " • امروز" else ""}") },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    settings: AppSettingsEntity,
    viewModel: StudyViewModel,
    onExport: (String) -> Unit,
    onImport: () -> Unit,
    experience: ExperienceController,
    modifier: Modifier = Modifier,
) {
    var confirmWipe by remember { mutableStateOf(false) }
    var sfxPreview by remember(experience.settings.sfxVolume) { mutableStateOf(experience.settings.sfxVolume.toFloat()) }
    var focusPreview by remember(experience.settings.focusVolume) { mutableStateOf(experience.settings.focusVolume.toFloat()) }
    LazyColumn(modifier.fillMaxSize().testTag("settings_list"), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageTitle("تنظیمات مطالعه", "تغییرها زنده و آفلاین‌اند؛ بانک V6.1 و پیشرفت از تنظیمات ظاهری جدا می‌مانند.") }
        item { ThemePreviewRow(settings.theme) { viewModel.saveSettings(settings.copy(theme = it.name)) } }
        item { TextScaleCard(settings.textScale, viewModel) }
        item {
            SettingChoices("فونت خواندن", ReaderFont.entries, experience.settings.readerFont, { it.key }, { it.fa }) { experience.setReaderFont(it.key) }
        }
        item {
            SettingChoices("چیدمان مطالعه", UiDensity.entries, experience.settings.density, { it.key }, { it.fa }) { experience.setDensity(it.key) }
        }
        item {
            SettingChoices("حالت مطالعه", StudyMode.entries, settings.studyMode, { it.name }, { it.fa }) { viewModel.saveSettings(settings.copy(studyMode = it.name)) }
            Text("متعادل: ترکیبی • ایمنی: ضعف/مرور بیشتر • تمرکز عمیق: حداکثر دو ریزمبحث • آزمون سخت: اولویت L5/L6. شبیه‌سازها هیچ‌وقت با این گزینه تغییر نمی‌کنند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            SettingChoices("حرکت", MotionMode.entries, settings.motion, { it.name }, { it.fa }) { viewModel.saveSettings(settings.copy(motion = it.name)) }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تمرکز و نمایش", fontWeight = FontWeight.Bold)
                    ToggleRow("حالت تمرکز؛ یک سؤال/یک کار", settings.focusMode) { viewModel.saveSettings(settings.copy(focusMode = it)) }
                    ToggleRow("مطالعهٔ طولانی؛ کروم و حرکت کمتر", settings.longStudyMode) { viewModel.saveSettings(settings.copy(longStudyMode = it)) }
                    ToggleRow("یادآوری استراحت", settings.breaksEnabled) { viewModel.saveSettings(settings.copy(breaksEnabled = it)) }
                    if (settings.breaksEnabled) SettingChoices("فاصلهٔ استراحت", listOf(20,30,40,50), settings.breakEvery.toString(), { it.toString() }, { "هر ${fa(it)} سؤال" }) { viewModel.saveSettings(settings.copy(breakEvery = it)) }
                    ToggleRow("ADHD / حذف شلوغی هنگام سؤال", experience.settings.adhdMode, experience::setAdhdMode)
                    ToggleRow("کاهش حرکت", experience.settings.reducedMotion, experience::setReducedMotion)
                    ToggleRow("اجبار کنتراست بالا روی هر تم", experience.settings.highContrast, experience::setHighContrast)
                    ToggleRow("روشن ماندن صفحه هنگام مطالعه", experience.settings.keepAwake, experience::setKeepAwake)
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("موسیقی / صدای تمرکز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("پخش با MediaPlayer خود اندروید است و فایل‌ها داخل APK هستند؛ انتخاب هر صدا همان لحظه پیش‌نمایش را پخش می‌کند.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SettingChoices("فضای صوتی", focusTracks, experience.settings.focusTrack, { it.first }, { it.second }) { (key,_) -> experience.setFocusTrack(key, autoPreview = true) }
                    if (experience.settings.focusTrack != "none") {
                        Text("حجم تمرکز: ${fa(focusPreview.roundToInt())}٪", fontWeight = FontWeight.Bold)
                        Slider(
                            value = focusPreview,
                            onValueChange = { focusPreview = it; experience.previewFocusVolume(it.roundToInt()) },
                            onValueChangeFinished = { experience.setFocusVolume(focusPreview.roundToInt()) },
                            valueRange = 0f..100f,
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = experience::toggleFocus, modifier = Modifier.weight(1f).height(50.dp)) { Text(if (experience.focusPlaying) "مکث" else "پخش") }
                            OutlinedButton(onClick = { experience.setFocusTrack("none", autoPreview = false) }, modifier = Modifier.weight(1f).height(50.dp)) { Text("توقف و خاموش") }
                        }
                    }
                    experience.focusError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    Text(if (experience.focusPlaying) "● در حال پخش آفلاین" else "وضعیت: متوقف", color = if (experience.focusPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("تایمر تمرکز", fontWeight = FontWeight.Bold)
                    SettingChoices("مدت", listOf(15,25,40), experience.settings.focusMinutes.toString(), { it.toString() }, { "${fa(it)} دقیقه" }) { experience.setFocusMinutes(it) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = experience::startPauseTimer, modifier = Modifier.weight(1f).height(52.dp)) { Text(if (experience.focusTimerRunning) "مکث تایمر" else "شروع تایمر") }
                        OutlinedButton(onClick = experience::resetTimer, modifier = Modifier.weight(1f).height(52.dp)) { Text("ریست") }
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("بازخورد صدا و لمس", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ToggleRow("افکت صوتی پاسخ‌ها", experience.settings.sfxEnabled, experience::setSfxEnabled)
                    Text("حجم افکت: ${fa(sfxPreview.roundToInt())}٪")
                    Slider(
                        value = sfxPreview,
                        onValueChange = { sfxPreview = it; experience.previewSfxVolume(it.roundToInt()) },
                        onValueChangeFinished = { experience.setSfxVolume(sfxPreview.roundToInt()) },
                        valueRange = 0f..100f,
                    )
                    OutlinedButton(onClick = { experience.playSfx("correct") }, enabled = experience.settings.sfxEnabled, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("تست افکت صوتی") }
                    ToggleRow("هپتیک", experience.settings.hapticsEnabled, experience::setHapticsEnabled)
                    SettingChoices("شدت هپتیک", HapticStrength.entries, experience.settings.hapticStrength, { it.key }, { it.fa }) { experience.setHapticStrength(it.key) }
                    OutlinedButton(onClick = { experience.haptic(28) }, enabled = experience.settings.hapticsEnabled, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("تست لرزش") }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("پشتیبان پیشرفت", fontWeight = FontWeight.Bold)
                    Text("پیش از بازیابی، یک نسخهٔ داخلی از وضعیت فعلی نگه داشته می‌شود. خروجی قدیمی V5 نیز برای مهاجرت قابل انتخاب است.")
                    Button(onClick = { viewModel.exportBackup(onExport) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { ActionLabel(R.drawable.ic_action_export, "خروجی JSON") }
                    OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().height(52.dp)) { ActionLabel(R.drawable.ic_action_import, "بازیابی JSON") }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("بانک و سازگاری V5", fontWeight = FontWeight.Bold)
                    Text("بانک فعال: V6.1 Freeze • ۱۲۱۶ سؤال • SIM1/SIM2 مستقل • قرنطینه فعال")
                    Text("تعویض آزاد JSONِ V5 عمداً با بانک exact-hash جایگزین شده تا کلید، eligibility و شبیه‌سازها قابل خراب‌کردن نباشند.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("SHA DB: d63219dd…b3b673c", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("پیش‌نمایش خوانایی", fontWeight = FontWeight.Bold)
                    ScienceText("نمونهٔ رندر علمی: 5′→3′  H₂SO₄  SO₄²⁻  Fe³⁺  2H₂ + O₂ → 2H₂O  x²  x₁  √x  |x|  lim  sin θ  log₂x  P(A∩B)  3×10⁸  m/s²  Ω  ΔE")
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("نگهداری", fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { experience.resetExperience(); viewModel.resetUiSettings() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("بازنشانی تنظیمات رابط") }
                    OutlinedButton(onClick = { confirmWipe = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("پاک کردن همهٔ پیشرفت") }
                    Text("بازنشانی رابط به progress دست نمی‌زند. پاک‌سازی پیشرفت snapshot داخلی می‌سازد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (confirmWipe) AlertDialog(
        onDismissRequest = { confirmWipe = false },
        title = { Text("پاک‌کردن همهٔ پیشرفت؟") },
        text = { Text("این کار attempts، mastery، مرورهای سررسید و نتایج شبیه‌ساز را پاک می‌کند. یک snapshot بازیابی داخلی قبل از حذف نگه داشته می‌شود.") },
        dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("لغو") } },
        confirmButton = { TextButton(onClick = { confirmWipe = false; viewModel.wipeProgress() }) { Text("پاک کن") } },
    )
}

private val focusTracks = listOf(
    "none" to "بدون صدا", "ambient" to "Ambient", "rain" to "باران", "brown" to "Brown Noise", "pulse" to "پالس آرام"
)

@Composable
private fun TextScaleCard(textScale:Int,viewModel:StudyViewModel){
    val presets=listOf(90,100,110,120,130,140)
    Card {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("اندازهٔ متن: ${fa(textScale)}٪",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
            Text("پیش‌نمایش زنده است؛ دیتابیس فقط بعد از رها کردن اسلایدر نوشته می‌شود.",color=MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                OutlinedButton(onClick={viewModel.previewTextScale((textScale-5).coerceAtLeast(90));viewModel.commitTextScale()}){Text("−")}
                Slider(value=textScale.toFloat(),onValueChange={viewModel.previewTextScale(((it/5f).roundToInt()*5).coerceIn(90,140))},onValueChangeFinished=viewModel::commitTextScale,valueRange=90f..140f,steps=9,modifier=Modifier.weight(1f))
                OutlinedButton(onClick={viewModel.previewTextScale((textScale+5).coerceAtMost(140));viewModel.commitTextScale()}){Text("+")}
            }
            SettingChoices("اندازه‌های سریع",presets,textScale.toString(),{it.toString()},{"${fa(it)}٪"}){viewModel.previewTextScale(it);viewModel.commitTextScale()}
            ScienceText("پیش‌نمایش سؤال: H₂SO₄  x²  √x  5′→3′ و متن فارسی خوانا",color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ThemePreviewRow(selected:String,onSelect:(ThemeFamily)->Unit){
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("تم مطالعه",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        Text("همهٔ تم‌ها جلوی چشم‌اند؛ لازم نیست یک ردیف افقی را شکار کنی.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        ThemeFamily.entries.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                pair.forEach { theme ->
                    val scheme=schemeFor(theme)
                    val active=ThemeFamily.fromStored(selected)==theme
                    Card(onClick={onSelect(theme)},colors=CardDefaults.cardColors(containerColor=scheme.surface),border=androidx.compose.foundation.BorderStroke(if(active)2.dp else 1.dp,if(active)scheme.primary else scheme.outlineVariant),modifier=Modifier.weight(1f).sizeIn(minHeight=96.dp)){
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                            Row(Modifier.fillMaxWidth().height(26.dp).clip(RoundedCornerShape(8.dp))){
                                Box(Modifier.weight(1f).height(26.dp).background(scheme.background));Box(Modifier.weight(1f).height(26.dp).background(scheme.surfaceVariant));Box(Modifier.weight(1f).height(26.dp).background(scheme.primary))
                            }
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(theme.fa,color=scheme.onSurface,fontWeight=if(active)FontWeight.Bold else FontWeight.Medium);if(active)Text("✓",color=scheme.primary,fontWeight=FontWeight.Bold)}
                        }
                    }
                }
                if(pair.size==1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun <T> SettingChoices(title:String,values:List<T>,selected:String,key:(T)->String,label:(T)->String,onSelect:(T)->Unit){
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        values.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                pair.forEach { value -> FilterChip(selected=selected==key(value),onClick={onSelect(value)},label={Text(label(value),textAlign=TextAlign.Center)},modifier=Modifier.weight(1f).sizeIn(minHeight=48.dp)) }
                if(pair.size==1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FocusAudioStrip(experience:ExperienceController){
    val label=focusTracks.firstOrNull{it.first==experience.settings.focusTrack}?.second?:"صدای تمرکز"
    Surface(color=MaterialTheme.colorScheme.surfaceVariant,tonalElevation=2.dp){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
            TextButton(onClick=experience::toggleFocus){Text(if(experience.focusPlaying)"❚❚ مکث" else "▶ پخش")}
            Column(Modifier.weight(1f)){Text(label,fontWeight=FontWeight.Bold);Text(if(experience.focusPlaying)"در حال پخش • آفلاین" else "برای پخش لمس کن",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            experience.focusError?.let{Text("!",color=MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)}
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().sizeIn(minHeight = 56.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun phaseFa(value: String): String = when {
    "mandatory mastery wave 1" in value.lowercase() -> "موج اول A + بازیابی چند ساعت بعد"
    "mandatory wave 2" in value.lowercase() -> "موج دوم A + SIM1 + ترمیم"
    "sim2" in value.lowercase() -> "SIM2 مستقل + ترمیم فاصله‌دار نهایی"
    "simulation 1" in value.lowercase() -> "شبیه‌ساز مستقل اول"
    "simulation 2" in value.lowercase() -> "شبیه‌ساز مستقل دوم"
    "Final" in value -> "جمع‌بندی نهایی"
    "completion" in value -> "تکمیل نجات و سنجش آمادگی"
    else -> "نجات محتوا و انتقال به تست"
}

private fun persianDate(value: String): String = when (value) {
    "2026-08-12" -> "۲۱ مرداد ۱۴۰۵"
    "2026-08-13" -> "۲۲ مرداد ۱۴۰۵"
    "2026-08-14" -> "۲۳ مرداد ۱۴۰۵"
    "2026-08-15" -> "۲۴ مرداد ۱۴۰۵"
    "2026-08-16" -> "۲۵ مرداد ۱۴۰۵"
    "2026-08-17" -> "۲۶ مرداد ۱۴۰۵"
    "2026-08-18" -> "۲۷ مرداد ۱۴۰۵"
    "2026-08-19" -> "۲۸ مرداد ۱۴۰۵"
    "2026-08-20" -> "۲۹ مرداد ۱۴۰۵"
    else -> value
}

private fun fa(value: Int): String = value.toString().map { c -> if (c in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[c - '0'] else c }.joinToString("")
