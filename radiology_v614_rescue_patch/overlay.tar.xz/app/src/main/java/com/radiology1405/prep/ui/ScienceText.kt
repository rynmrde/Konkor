package com.radiology1405.prep.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit

private const val LRI = '⁦'
private const val PDI = '⁩'
private val scienceRun = Regex(
    "[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪|]+(?:[ \t]*[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪]+)*"
)
private val learnerFacingLabels = linkedMapOf(
    "condition_wrong" to "نادیده‌گرفتن شرط", "wrong_condition" to "نادیده‌گرفتن شرط",
    "truth_partial" to "درستِ ناقص", "partial_truth" to "درستِ ناقص",
    "overgeneralization" to "تعمیم نادرست", "correct_reasoning" to "استدلال درست",
    "calculation_trap" to "خطای محاسبه", "calculation_error" to "خطای محاسبه",
    "unit_mistake" to "خطای واحد", "unit_error" to "خطای واحد",
    "direction_error" to "خطای جهت", "false_absolute" to "مطلق‌انگاری نادرست",
    "keyword_trap" to "پاسخ‌دادن بر پایهٔ کلیدواژه", "knowledge_gap" to "نیاز به مرور مفهوم",
    "forgotten_rule" to "فراموشی قاعده", "misread" to "بدخوانی صورت سؤال",
    "time_management" to "مدیریت زمان", "careless_error" to "بی‌دقتی",
)
/** Localizes only internal labels; analysis sentences are never deleted in the UI layer. */
fun learnerFacingScientificText(value: String): String = learnerFacingLabels.entries.fold(value) { rendered, (internal, label) ->
    rendered.replace(internal, label, ignoreCase = true)
}
fun isolateScientificRuns(value: String): String = scienceRun.replace(learnerFacingScientificText(value)) { match ->
    "$LRI${match.value}$PDI"
}
fun removeScientificIsolates(value: String): String = value.replace(LRI.toString(), "").replace(PDI.toString(), "")
@Composable
fun ScienceText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = LocalContentColor.current,
    fontSize: TextUnit = TextUnit.Unspecified,
    style: TextStyle? = null,
    textAlign: TextAlign? = null,
) {
    Text(text = isolateScientificRuns(text), modifier = modifier, color = color, fontSize = fontSize, style = style ?: LocalTextStyle.current, textAlign = textAlign)
}
