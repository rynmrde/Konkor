package com.radiology1405.prep.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit

private const val LRI = '\u2066'
private const val PDI = '\u2069'

/** Internal taxonomy keys must never be exposed in learner-facing Persian text. */
private val learnerFacingTerms = mapOf(
    "wrong_condition" to "نادیده‌گرفتن شرط",
    "partial_truth" to "برداشت ناقص",
    "truth_partial" to "برداشت ناقص",
    "truth_wrong" to "برداشت نادرست",
    "formula_wrong" to "به‌کارگیری رابطهٔ نادرست",
    "calculation_wrong" to "خطای محاسبه",
    "concept_wrong" to "برداشت مفهومی نادرست",
    "calculation_trap" to "خطای محاسبه",
    "unit_mistake" to "خطای واحد",
    "overgeneralization" to "تعمیم نادرست",
)

fun sanitizeLearnerFacingText(value: String): String = learnerFacingTerms.entries.fold(value) { text, (raw, localized) ->
    text.replace(Regex("\\b${Regex.escape(raw)}\\b", RegexOption.IGNORE_CASE), localized)
}

private val scienceRun = Regex(
    "[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪|]+(?:[ \\t]*[A-Za-z0-9₀-₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻′°→←↔×·√ΩΔθπ∞=<>/().∩∪]+)*"
)

/** Unicode bidi isolation keeps formula direction intact inside a Persian paragraph. */
fun isolateScientificRuns(value: String): String = scienceRun.replace(value) { match ->
    "$LRI${match.value}$PDI"
}

fun removeScientificIsolates(value: String): String = value.replace(LRI.toString(), "").replace(PDI.toString(), "")

@Composable
fun ScienceText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = LocalContentColor.current,
    fontSize: TextUnit = TextUnit.Unspecified,
    style: TextStyle? = null,
    textAlign: TextAlign? = null,
) {
    Text(
        text = isolateScientificRuns(sanitizeLearnerFacingText(text)),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        style = style ?: LocalTextStyle.current,
        textAlign = textAlign,
    )
}
