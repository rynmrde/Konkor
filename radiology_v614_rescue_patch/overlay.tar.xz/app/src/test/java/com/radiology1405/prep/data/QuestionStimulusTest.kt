package com.radiology1405.prep.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class QuestionStimulusTest {
    @Test fun readsCanonicalPairWithoutChangingStemOrOptions() {
        val question = Question.fromJson("""{"id":"q","subject":"زیست","microtopic":"x","source_type":"authored","stem":"دربارهٔ دو عبارت A و B، کدام گزینه درست است؟","options":["1","2","3","4"],"correct_index":0,"correct_analysis":"r","distractor_analyses":{"0":"a","1":"b","2":"c","3":"d"},"short_lesson":"l","stimulus":{"left_label":"A","left":"گزارهٔ چپ","right_label":"B","right":"گزارهٔ راست"}}""")
        assertEquals("دربارهٔ دو عبارت A و B، کدام گزینه درست است؟", question.stem)
        assertEquals(listOf("1", "2", "3", "4"), question.options)
        assertNotNull(question.pairedStimulus)
        assertEquals("گزارهٔ چپ", question.pairedStimulus?.left)
        assertEquals("گزارهٔ راست", question.pairedStimulus?.right)
    }
}
