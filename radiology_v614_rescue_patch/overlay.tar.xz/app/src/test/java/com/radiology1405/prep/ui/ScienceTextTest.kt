package com.radiology1405.prep.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScienceTextTest {
    @Test fun localizesInternalTaxonomyWithoutDeletingReasoning() {
        val rendered = learnerFacingScientificText("wrong_condition partial_truth calculation_trap unit_error time_management: کدون روی mRNA است.")
        listOf("wrong_condition", "partial_truth", "calculation_trap", "unit_error", "time_management").forEach { assertFalse(rendered.contains(it)) }
        assertTrue(rendered.contains("کدون روی mRNA است"))
    }
}
