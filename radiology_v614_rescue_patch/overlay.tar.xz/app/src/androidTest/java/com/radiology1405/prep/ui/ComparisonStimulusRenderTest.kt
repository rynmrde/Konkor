package com.radiology1405.prep.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.platform.app.InstrumentationRegistry
import com.radiology1405.prep.data.BankStore
import org.junit.Rule
import org.junit.Test

class ComparisonStimulusRenderTest {
    @get:Rule val compose = createComposeRule()

    @Test fun canonicalComparisonStatementsFromPackagedBankAreVisible() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val bank = BankStore(context)
        try {
            listOf("v3_phys_30_02", "v3_phys_33_02", "v3_phys_34_03").forEach { id ->
                val stimulus = requireNotNull(bank.question(id)?.comparisonStimulus) { "Missing canonical comparison stimulus: $id" }
                compose.setContent { ComparisonStimulusCard(stimulus) }

                compose.onNodeWithTag("comparison_stimulus").assertIsDisplayed()
                compose.onNodeWithText(stimulus.leftLabel).assertIsDisplayed()
                compose.onNodeWithText(stimulus.left).assertIsDisplayed()
                compose.onNodeWithText(stimulus.rightLabel).assertIsDisplayed()
                compose.onNodeWithText(stimulus.right).assertIsDisplayed()
            }
        } finally {
            bank.close()
        }
    }
}
