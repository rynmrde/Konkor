package com.radiology1405.prep.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.ZoneId

@RunWith(AndroidJUnit4::class)
class RescueSessionFlowTest {
    private lateinit var context: Context
    private lateinit var repository: StudyRepository

    @Before fun before() = runBlocking {
        context = ApplicationProvider.getApplicationContext()
        repository = StudyRepository(context)
        repository.initialize()
        repository.wipeProgress()
    }

    @After fun after() = runBlocking {
        repository.wipeProgress()
        repository.close()
    }

    @Test fun answerReviewReopenResumeAndSim1StartRemainExact() = runBlocking {
        val now = LocalDate.parse("2026-08-18").atTime(12, 0)
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val first = repository.startOrResume("2026-08-18", now)
        assertEquals("TRAIN", first.entity.pool)
        assertEquals(15, first.total)
        val firstQuestion = requireNotNull(first.currentQuestion)
        repository.selectOriginal(firstQuestion.id, firstQuestion.correctIndex)
        repository.setConfidence(firstQuestion.id, Confidence.CONFIDENT)
        val review = repository.submit(now + 1_000)
        assertEquals("review", review.entity.phase)
        assertEquals(1, repository.currentOutcome()?.correct)

        val exactAnswers = review.entity.answersJson
        repository.close()
        repository = StudyRepository(context)
        repository.initialize()
        val resumedReview = repository.activeSummary()
        assertNotNull(resumedReview)
        assertEquals("review", resumedReview?.entity?.phase)
        assertEquals(exactAnswers, resumedReview?.entity?.answersJson)
        repository.finishReview()

        val second = repository.startOrResume("2026-08-18", now + 2_000)
        assertEquals("TRAIN", second.entity.pool)
        repository.submit(now + 3_000)
        repository.finishReview()

        val sim = repository.startOrResume("2026-08-18", now + 4_000)
        assertEquals("SIM1", sim.entity.pool)
        assertEquals(117, sim.total)
        val simIds = JSONArray(sim.entity.questionIdsJson)
        assertEquals(117, (0 until simIds.length()).map { simIds.getString(it) }.toSet().size)
        assertTrue(sim.entity.mode.contains("stage=SIM1;leak=0"))

        val exactSimSession = JSONObject()
            .put("ids", sim.entity.questionIdsJson)
            .put("orders", sim.entity.optionOrdersJson)
            .toString()
        repository.close()
        repository = StudyRepository(context)
        repository.initialize()
        val resumedSim = repository.startOrResume("2026-08-18", now + 5_000)
        assertEquals(
            exactSimSession,
            JSONObject().put("ids", resumedSim.entity.questionIdsJson)
                .put("orders", resumedSim.entity.optionOrdersJson).toString(),
        )
    }
}
