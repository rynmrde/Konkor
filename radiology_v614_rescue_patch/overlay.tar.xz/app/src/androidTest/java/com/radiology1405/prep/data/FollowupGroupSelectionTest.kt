package com.radiology1405.prep.data

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FollowupGroupSelectionTest {
    @Test fun documentedPhysicsScenarioPartnersCannotShareTrainingBlock() {
        val bank = BankStore(InstrumentationRegistry.getInstrumentation().targetContext)
        try {
            listOf(
                "v3_phys_30_04" to "v3_phys_30_08",
                "v3_phys_30_06" to "v3_phys_30_10",
            ).forEach { (first, partner) ->
                val firstQuestion = requireNotNull(bank.question(first))
                val partnerQuestion = requireNotNull(bank.question(partner))
                assertEquals(firstQuestion.followupGroup, partnerQuestion.followupGroup)

                val candidates = bank.trainingCandidates(
                    microtopics = listOf(firstQuestion.microtopic),
                    excluded = setOf(first),
                    limit = 40,
                    safeOnly = true,
                    excludedFollowupGroups = setOf(firstQuestion.followupGroup),
                )
                assertFalse("$partner must not share a normal block with $first", partner in candidates)
            }
        } finally {
            bank.close()
        }
    }
}
