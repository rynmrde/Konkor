#!/usr/bin/env python3
"""Deterministic V6.1.4 rescue, bank, compatibility and regression audit."""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import math
import pathlib
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ASSET = APP / "src/main/assets/radiology1405_bank_v6_1.db.gz"
KOTLIN = APP / "src/main/java/com/radiology1405/prep"

EXPECTED_A = [
    "آب‌های زیرزمینی و قنات",
    "تکتونیک ورقه‌ای و زمین‌ساخت",
    "منابع معدنی و اکتشاف",
    "آفرینش کیهان و منظومهٔ شمسی",
    "کانی، سنگ و چرخهٔ سنگ",
    "تنفس جانوری و انسان",
    "بیان ژن: رونویسی، ترجمه و تنظیم",
    "زمین‌شناسی پزشکی و سلامت",
    "گوارش و جذب",
    "خاک و فرسایش",
    "تقسیم یاخته و چرخهٔ یاخته",
    "گردش خون، قلب و تبادل مویرگی",
    "شیمی محیط‌زیست و مواد",
    "جدول تناوبی و روندهای تناوبی",
    "هورمون و تنظیم درون‌ریز",
]

PRIOR = {"زیست": .58, "شیمی": .45, "فیزیک": .26, "ریاضی": .14, "زمین": .18}
TIME_FACTOR = {"زیست": .78, "شیمی": .88, "فیزیک": 1.12, "ریاضی": 1.25, "زمین": .68}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def kotlin_round_positive(value: float) -> int:
    return math.floor(value + .5)


build = (APP / "build.gradle.kts").read_text()
assert 'versionCode = 165' in build and 'versionName = "6.1.4"' in build
assert sha256(ASSET.read_bytes()) == "b5f47e9803638a37798be398ff4a087f336aafa78470e6f5ad94ac3aa5d7fe14"

with tempfile.NamedTemporaryFile(suffix=".db") as tmp:
    with gzip.open(ASSET, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            tmp.write(block)
    tmp.flush()
    assert sha256(pathlib.Path(tmp.name).read_bytes()) == "d63219dd6f1621644df495f6b195763924b5c282961cfecf544f7541ab3b673c"
    db = sqlite3.connect(tmp.name)
    assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"

    safe_counts: dict[str, int] = {}
    ids: set[str] = set()
    crop_count = 0
    for row_id, microtopic, raw in db.execute("SELECT id,microtopic,full_json FROM question"):
        question = json.loads(raw)
        assert row_id == question["id"] and row_id not in ids
        ids.add(row_id)
        assert len(question.get("options") or []) == 4
        assert question.get("correct_index") in range(4)
        assert str(question.get("correct_analysis", "")).strip()
        analyses = question.get("distractor_analyses") or {}
        assert all(str(analyses.get(str(index), "")).strip() for index in range(4))
        stimulus = question.get("stimulus") or {}
        if stimulus.get("type") == "official_source_crop":
            crop_count += 1
            encoded = stimulus["source_crop_data_uri"].split(",", 1)[1]
            assert sha256(base64.b64decode(encoded)) == stimulus["source_crop_sha256"]
        if (
            question.get("access_pool") == "TRAIN"
            and question.get("eligible_for_safety_evidence", True)
            and not question.get("needs_human_review", False)
        ):
            safe_counts[microtopic] = safe_counts.get(microtopic, 0) + 1
    assert len(ids) == 1216 and crop_count == 104

    coverage = json.loads(db.execute("SELECT json FROM bank_root WHERE key='coverage_plan'").fetchone()[0])
    assert len(coverage) == 56
    scored = []
    required_factors = {
        "frequency_1402_1404_weighted", "frequency_1398_1404_weighted", "stability",
        "learning_time_minutes", "prerequisite_cost", "average_difficulty", "error_risk",
        "trap_risk", "calculation_load", "probability_of_mastery_in_11_days",
    }
    for row in coverage:
        factors = row["priority_factors"]
        assert required_factors <= factors.keys() and len(row["microtopics"]) == 1
        topic = row["microtopics"][0]
        prior = PRIOR[row["subject"]]
        complexity = (
            1.0
            - .035 * max(factors["prerequisite_cost"] - 1, 0)
            - .022 * max(factors["calculation_load"] - 1, 0)
            - .018 * max(factors["average_difficulty"] - 2, 0)
            - .025 * max(factors["error_risk"] - .5, 0)
            - .010 * max(factors["trap_risk"] - 3, 0)
        )
        mastery3 = max(.12, min(.90, factors["probability_of_mastery_in_11_days"] * (.72 + .45 * prior) * complexity * .96))
        retention = max(.72, min(.96, .82 + .14 * factors["stability"] + .025 * prior))
        frequency_evidence = .70 * factors["frequency_1402_1404_weighted"] + .30 * factors["frequency_1398_1404_weighted"]
        frequency_calibration = .995 + .010 * frequency_evidence / (frequency_evidence + 2.0)
        minutes = max(1, kotlin_round_positive(
            factors["learning_time_minutes"] * TIME_FACTOR[row["subject"]]
            * (1 + .035 * max(factors["prerequisite_cost"] - 1, 0) + .025 * max(factors["calculation_load"] - 1, 0))
        ))
        gain = row["expected_questions"] * frequency_calibration * mastery3 * retention
        scored.append({
            "topic": topic, "minutes": minutes, "gain": gain, "roi": gain / minutes,
            "coverage": row["expected_questions"], "safe": safe_counts.get(topic, 0),
        })
    scored.sort(key=lambda value: (-value["roi"], value["topic"]))
    mandatory_minutes = 0
    for value in scored:
        if value["safe"] == 0:
            value["tier"] = "Q"
        elif value["safe"] >= 3 and mandatory_minutes + value["minutes"] <= 900:
            value["tier"] = "A"
            mandatory_minutes += value["minutes"]
        elif value["safe"] >= 2 and value["roi"] >= .0087:
            value["tier"] = "B"
        else:
            value["tier"] = "C"

    tiers = {tier: [value for value in scored if value["tier"] == tier] for tier in "ABCQ"}
    assert [value["topic"] for value in tiers["A"]] == EXPECTED_A
    assert {tier: len(values) for tier, values in tiers.items()} == {"A": 15, "B": 21, "C": 20, "Q": 0}
    assert mandatory_minutes == 869
    assert abs(sum(value["coverage"] for value in scored) - 112.9) < 1e-9
    assert abs(sum(value["coverage"] for value in tiers["A"]) - 29.9) < 1e-9

    blueprints = json.loads(db.execute("SELECT json FROM bank_root WHERE key='simulation_blueprints'").fetchone()[0])
    sim1 = set(blueprints["SIM1"]["question_ids"])
    sim2 = set(blueprints["SIM2"]["question_ids"])
    assert len(sim1) == len(sim2) == 117 and not sim1 & sim2
    placeholders = ",".join("?" for _ in sim1 | sim2)
    for raw, in db.execute(f"SELECT full_json FROM question WHERE id IN ({placeholders})", tuple(sim1 | sim2)):
        question = json.loads(raw)
        assert question["access_pool"] in {"SIM1", "SIM2"}
        assert question.get("eligible_for_safety_evidence") is True
        assert question.get("needs_human_review") is False
        assert question.get("source_type") == "authored"
    assert db.execute("SELECT COUNT(*) FROM question WHERE access_pool='QUARANTINE'").fetchone()[0] == 16
    assert db.execute("SELECT COUNT(*) FROM question WHERE access_pool='QUARANTINE' AND id IN (%s)" % placeholders, tuple(sim1 | sim2)).fetchone()[0] == 0
    db.close()

planner = (KOTLIN / "engine/RescuePlanner.kt").read_text()
store = (KOTLIN / "data/BankStore.kt").read_text()
repo = (KOTLIN / "data/StudyRepository.kt").read_text()
progress = (KOTLIN / "data/ProgressDatabase.kt").read_text()
vm = (KOTLIN / "StudyViewModel.kt").read_text()
ui = (KOTLIN / "ui/RadiologyApp.kt").read_text()
normalized = "".join(planner.split()).replace("_", "")
for token in [
    "BASELINESTUDYMINUTES=5955", "RESCUESTUDYMINUTES=1950",
    "BASELINEQUESTIONBUDGET=544", "RESCUEQUESTIONBUDGET=354",
]:
    assert token in normalized, token
for token in ["RescueTier.A", "RescueTier.B", "RescueTier.C", "RescueTier.Q", "preferredTeachingLevels", "RescueStage.SIM1", "RescueStage.SIM2"]:
    assert token in planner, token
for token in ["safeOnly = true", "eligibleForSafetyEvidence", "needsHumanReview", "overlap == 0", "__orientation__", "__guided__", "stage=$stage;leak=$overlap"]:
    assert token in repo, token
for token in ["rescueProfiles", "coverage_plan", "safeTrainQuestions", "simulationIds"]:
    assert token in store, token
assert "version = 3" in progress and "fallbackToDestructiveMigration" not in progress
assert "radiology1405_progress_v6.db" in progress and "trainingAttemptCountForDate" in progress
for token in ["sessionCompatible", "exportBackup", "restoreBackup", "pre_restore", "optionOrder"]:
    assert token in repo, token
for token in ["guided", "orientation", "spaced", "primer"]:
    assert f'"{token}"' in vm, token
for token in ["مرور سریع", "تحلیل کامل پاسخ درست (اختیاری)", "جهت‌گیری ۶۰ ثانیه‌ای", "برنامهٔ واقعی سه‌روزه", "C ${fa(metrics.lowPriorityMicrotopics)} فقط وقت اضافه"]:
    assert token in ui, token

scope_reduction = 100 * 41 / 56
question_reduction = 100 * 190 / 544
time_reduction = 100 * 4005 / 5955
coverage_reduction = 100 * 83.0 / 112.9
print(
    "V614_RESCUE_VALIDATION=PASS",
    f"tiers=A15/B21/C20/Q0 scope_reduction={scope_reduction:.1f}%",
    f"question_reduction={question_reduction:.1f}% time_reduction={time_reduction:.1f}%",
    f"raw_coverage_reduction={coverage_reduction:.1f}% mandatory_learning_minutes={mandatory_minutes}",
)
