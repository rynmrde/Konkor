#!/usr/bin/env python3
"""Physics second-pass QA: renderer safety, targeted reasoning, comparison stimulus, and session evidence."""
from __future__ import annotations
import gzip, json, pathlib, re, sqlite3, tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSET = ROOT / 'app/src/main/assets/radiology1405_bank_v6_1.db.gz'
SCIENCE = ROOT / 'app/src/main/java/com/radiology1405/prep/ui/ScienceText.kt'
MODELS = ROOT / 'app/src/main/java/com/radiology1405/prep/data/Models.kt'
UI = ROOT / 'app/src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt'
STORE = ROOT / 'app/src/main/java/com/radiology1405/prep/data/BankStore.kt'
REPO = ROOT / 'app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt'
UI_TEST = ROOT / 'app/src/androidTest/java/com/radiology1405/prep/ui/ComparisonStimulusRenderTest.kt'
FOLLOWUP_TEST = ROOT / 'app/src/androidTest/java/com/radiology1405/prep/data/FollowupGroupSelectionTest.kt'

RAW = {
    'wrong_condition': 'نادیده‌گرفتن شرط',
    'partial_truth': 'برداشت ناقص',
    'truth_partial': 'برداشت ناقص',
    'truth_wrong': 'برداشت نادرست',
    'formula_wrong': 'به‌کارگیری رابطهٔ نادرست',
    'calculation_wrong': 'خطای محاسبه',
    'concept_wrong': 'برداشت مفهومی نادرست',
    'calculation_trap': 'خطای محاسبه',
    'unit_mistake': 'خطای واحد',
    'overgeneralization': 'تعمیم نادرست',
}
RAW_RE = re.compile(r'\b(?:' + '|'.join(map(re.escape, RAW)) + r')\b', re.I)
FILLER = (
    'این گزینه با همهٔ شرط‌ها سازگار است',
    'این گزاره با کتاب سازگار است',
    'نکتهٔ تثبیتی',
    'از کلیدواژه جواب نده',
    'منشأ دام این گزینه',
)
TARGET_IDS = {
    'v3_phys_27_01', 'v3_phys_29_01', 'v3_phys_30_01', 'v3_phys_30_02',
    'v3_phys_30_04', 'v3_phys_30_06', 'v3_phys_30_08', 'v3_phys_30_10',
    'v3_phys_33_01', 'v3_phys_33_02', 'v3_phys_33_05', 'v3_phys_28_01',
    'v3_phys_28_02', 'v3_phys_31_01', 'v3_phys_35_01', 'v3_phys_35_05',
    'v3_phys_32_01', 'v3_phys_34_03',
}
SHORT_IDS = {
    'v3_phys_30_04', 'v3_phys_30_06', 'v3_phys_30_08',
    'v3_phys_30_10', 'v3_phys_33_05', 'v3_phys_35_05',
}
EXPECTED_KEYS = {
    'v3_phys_27_01': 1, 'v3_phys_29_01': 1, 'v3_phys_30_01': 1, 'v3_phys_30_02': 2,
    'v3_phys_30_04': 0, 'v3_phys_30_06': 2, 'v3_phys_30_08': 0, 'v3_phys_30_10': 2,
    'v3_phys_33_01': 1, 'v3_phys_33_02': 2, 'v3_phys_33_05': 1, 'v3_phys_28_01': 1,
    'v3_phys_28_02': 2, 'v3_phys_31_01': 1, 'v3_phys_35_01': 1, 'v3_phys_35_05': 1,
    'v3_phys_32_01': 1, 'v3_phys_34_03': 3,
}

def leaves(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for nested in value.values():
            yield from leaves(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from leaves(nested)

def rendered(value: str) -> str:
    for raw, localized in RAW.items():
        value = re.sub(r'\b' + re.escape(raw) + r'\b', localized, value, flags=re.I)
    return value

with tempfile.NamedTemporaryFile(suffix='.db') as temp:
    with gzip.open(ASSET, 'rb') as source:
        temp.write(source.read())
    temp.flush()
    db = sqlite3.connect(temp.name)
    records = {qid: json.loads(raw) for qid, raw in db.execute("SELECT id,full_json FROM question WHERE subject='فیزیک'")}
    db.close()

assert len(records) == 187
assert set(EXPECTED_KEYS) == TARGET_IDS
assert set(SHORT_IDS) <= TARGET_IDS
assert all(records[qid]['correct_index'] == expected for qid, expected in EXPECTED_KEYS.items())

user_fields = ('stem', 'options', 'correct_analysis', 'distractor_analyses', 'review_default', 'short_lesson', 'fast_method', 'start_method', 'main_trap', 'stimulus')
raw_bank_occurrences = 0
raw_rendered_occurrences = 0
target_raw_occurrences = 0
target_filler_occurrences = 0
short_failures = []
for qid, q in records.items():
    text = '\n'.join(text for field in user_fields for text in leaves(q.get(field, '')))
    raw_bank_occurrences += len(RAW_RE.findall(text))
    raw_rendered_occurrences += len(RAW_RE.findall(rendered(text)))
    if qid in TARGET_IDS:
        target_raw_occurrences += len(RAW_RE.findall(text))
        target_filler_occurrences += sum(text.count(phrase) for phrase in FILLER)
    if qid in SHORT_IDS:
        analysis = q['correct_analysis']
        if len(analysis) < 150 or not all(token in analysis for token in ('=', 'گزینه')):
            short_failures.append(qid)

assert raw_rendered_occurrences == 0, raw_rendered_occurrences
assert target_raw_occurrences == 0, target_raw_occurrences
assert target_filler_occurrences == 0, target_filler_occurrences
assert not short_failures, short_failures

for qid in ('v3_phys_30_02', 'v3_phys_33_02', 'v3_phys_34_03'):
    stimulus = records[qid]['stimulus']
    assert stimulus['type'] == 'comparison' and stimulus['left'].strip() and stimulus['right'].strip()
    assert stimulus['left'] not in records[qid]['stem'] and stimulus['right'] not in records[qid]['stem']

for left, right in (('v3_phys_30_04', 'v3_phys_30_08'), ('v3_phys_30_06', 'v3_phys_30_10')):
    assert records[left]['followup_group'] == records[right]['followup_group']

science = SCIENCE.read_text(encoding='utf-8')
models = MODELS.read_text(encoding='utf-8')
ui = UI.read_text(encoding='utf-8')
store = STORE.read_text(encoding='utf-8')
repo = REPO.read_text(encoding='utf-8')
ui_test = UI_TEST.read_text(encoding='utf-8')
followup_test = FOLLOWUP_TEST.read_text(encoding='utf-8')
for raw in RAW:
    assert f'"{raw}"' in science
assert 'sanitizeLearnerFacingText(text)' in science
assert 'data class ComparisonStimulus' in models and 'comparisonStimulus = comparison' in models
assert ui.count('question.comparisonStimulus?.let') == 2
assert 'ComparisonStimulusCard(stimulus)' in ui and 'testTag("comparison_stimulus")' in ui
assert 'canonicalComparisonStatementsFromPackagedBankAreVisible' in ui_test and 'ComparisonStimulusCard(stimulus)' in ui_test
for comparison_id in ('v3_phys_30_02', 'v3_phys_33_02', 'v3_phys_34_03'):
    assert comparison_id in ui_test
for token in ('excludedFollowupGroups', 'followupLeak', 'TRAIN follow-up scenario leakage detected'):
    assert token in store or token in repo
assert 'documentedPhysicsScenarioPartnersCannotShareTrainingBlock' in followup_test
for scenario_id in ('v3_phys_30_04', 'v3_phys_30_08', 'v3_phys_30_06', 'v3_phys_30_10'):
    assert scenario_id in followup_test

print(json.dumps({
    'physics_records': len(records),
    'target_rewrites': len(TARGET_IDS),
    'short_analysis_rewrites': len(SHORT_IDS),
    'raw_tokens_in_bank_user_fields': raw_bank_occurrences,
    'raw_tokens_after_shared_renderer': raw_rendered_occurrences,
    'raw_tokens_in_rewritten_target': target_raw_occurrences,
    'generic_filler_in_rewritten_target': target_filler_occurrences,
    'short_analysis_failures': short_failures,
    'comparison_ids': ['v3_phys_30_02', 'v3_phys_33_02', 'v3_phys_34_03'],
    'scenario_pair_contracts': [['v3_phys_30_04', 'v3_phys_30_08'], ['v3_phys_30_06', 'v3_phys_30_10']],
}, ensure_ascii=False, indent=2))
