from pathlib import Path
import hashlib,re,wave,subprocess
root=Path(__file__).resolve().parents[1]
app=root/'app'
models=(app/'src/main/java/com/radiology1405/prep/data/Models.kt').read_text()
ui=(app/'src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt').read_text()
theme=(app/'src/main/java/com/radiology1405/prep/ui/Theme.kt').read_text()
science=(app/'src/main/java/com/radiology1405/prep/ui/ScienceText.kt').read_text()
exp=(app/'src/main/java/com/radiology1405/prep/ui/ExperienceController.kt').read_text()
vm=(app/'src/main/java/com/radiology1405/prep/StudyViewModel.kt').read_text()
repo=(app/'src/main/java/com/radiology1405/prep/data/StudyRepository.kt').read_text()
build=(app/'build.gradle.kts').read_text()
bankstore=(app/'src/main/java/com/radiology1405/prep/data/BankStore.kt').read_text()
# Feature/UI parity and new UX fixes.
for token in ['MIDNIGHT','OLED','GRAPHITE','EMERALD','VIOLET','ICE','SUNSET','WARM','LIGHT','CONTRAST']:
    assert token in models,token
assert models.count('("') >= 10
for token in ['ThemePreviewRow','chunked(2)','TextScaleCard','ReaderFont.entries','HapticStrength.entries','FocusAudioStrip','پیش‌نمایش زنده','بازنشانی تنظیمات رابط']:
    assert token in ui,token
assert 'valueRange=90f..140f' in ui.replace(' ','')
assert 'testTag(\"settings_list\")' in ui
smoke=(app/'src/androidTest/java/com/radiology1405/prep/ui/NativeExperienceSmokeTest.kt').read_text()
assert 'performScrollToNode' in smoke and 'onNodeWithTag(\"settings_list\")' in smoke
assert 'previewTextScale' in vm and 'commitTextScale' in vm
assert 'coerceIn(90,140)' in theme.replace(' ','')
assert 'LocalTextStyle.current' in science and 'style: TextStyle? = null' in science
for token in ['MediaPlayer()','setAudioAttributes','setDataSource','focusError','autoPreview','ReaderFont','HapticStrength','ToneGenerator','previewFocusVolume','previewSfxVolume']:
    assert token in exp,token
assert 'view.keepScreenOn = experience.settings.keepAwake && (state.screen == AppScreen.STUDY || experience.focusTimerRunning)' in ui
assert 'versionCode = 165' in build and 'versionName = "6.1.4"' in build
# Runtime must consume AAPT's expanded .db asset while retaining a .db.gz fallback.
db_match=re.search(r'EXPECTED_DB_SHA256\s*=\s*"([0-9a-f]{64})"',bankstore)
gzip_match=re.search(r'EXPECTED_GZIP_SHA256\s*=\s*"([0-9a-f]{64})"',bankstore)
assert db_match and gzip_match
for token in ['PACKAGED_ASSET = "radiology1405_bank_v6_1.db"','SOURCE_GZIP_ASSET = "radiology1405_bank_v6_1.db.gz"','FileNotFoundException','GZIPInputStream','dbDelegate.isInitialized()']:
    assert token in bankstore,token
# Heavy bank open/plans must not block the Compose main thread on first launch.
assert 'suspend fun plans(): List<DayPlan> = withContext(Dispatchers.IO)' in repo
assert 'suspend fun planFor' in repo and '= withContext(Dispatchers.IO)' in repo
assert 'viewModelScope.launch { refreshAll() }' not in vm
# The packaged bank must match the runtime integrity pin for this versioned source tree.
bank=app/'src/main/assets/radiology1405_bank_v6_1.db.gz'
assert hashlib.sha256(bank.read_bytes()).hexdigest()==gzip_match.group(1)
# Offline focus media must be real Ogg/Vorbis and non-empty.
for name in ['focus_ambient.ogg','focus_rain.ogg','focus_brown.ogg','focus_pulse.ogg']:
    p=app/'src/main/res/raw'/name
    assert p.is_file() and p.stat().st_size>5000,name
    assert p.read_bytes()[:4]==b'OggS',name
print('V611_UX_STATIC=PASS themes=10 text=90..140 native_audio=4 bank_sha=PASS')

# V6.1.2 parity hardening: no fake controls.
assert 'UiDensity' in exp and 'setDensity' in exp and 'dueBreak' in exp and 'acknowledgeBreak' in exp
assert 'breakRevision' in exp and 'AdaptiveEngine.breakBoundary' in exp
assert 'motionDuration' in ui and 'MotionMode.CALM -> if (screenChange) 130 else 110' in ui
assert 'MotionMode.DYNAMIC -> if (screenChange) 230 else 190' in ui
assert 'MotionMode.LIVELY -> if (screenChange) 320 else 250' in ui
assert 'BreakReminderBanner' in ui and 'state.submittedToday + summary.answered' in ui
assert 'experience.playSfx("complete")' in ui
assert 'چیدمان مطالعه' in ui and 'UiDensity.entries' in ui
assert 'متعادل: ترکیبی' in ui
for name in ['ic_action_start.xml','ic_action_submit.xml','ic_action_complete.xml','ic_action_export.xml','ic_action_import.xml']:
    assert (app/'src/main/res/drawable'/name).is_file(), name
assert 'glass' not in ui.lower() and 'reduceglow' not in ui.lower()
print('V612_PARITY_STATIC=PASS real_break real_modes density restrained_icons')

# V6.1.4 real three-day selector.
repo=(app/'src/main/java/com/radiology1405/prep/data/StudyRepository.kt').read_text()
vm=(app/'src/main/java/com/radiology1405/prep/StudyViewModel.kt').read_text()
smoke=(app/'src/androidTest/java/com/radiology1405/prep/ui/NativeExperienceSmokeTest.kt').read_text()
for token in ['planForDate','resolvePlanSelection','isHoldoutLocked','startOrResume(selectedDate: String? = null']:
    assert token in repo,token
for token in ['selectedPlanDate','todayPlanDate','selectedDaySubmitted','fun selectDay(date: String)','repository.startOrResume(_state.value.selectedPlanDate)']:
    assert token in vm,token
for token in ['DaySelector(','day_chip_${plan.day}','روز انتخاب‌شده','بازگشت به امروز','plan_day_${plan.day}']:
    assert token in ui,token
assert 'day_chip_1' in smoke and 'روز انتخاب‌شده: ۲ از ۳' in smoke
print('V614_DAY_SELECTOR_STATIC=PASS selectable_days=3 future_holdout_protection=ON')
