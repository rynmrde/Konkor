import json
from pathlib import Path
p = json.loads((Path(__file__).parents[1] / "app/src/main/assets/biology_v621_second_pass_successor.json").read_text())
updates = p["updates"]
ids = [row["id"] for row in updates]
assert len(updates) == 142 and len(ids) == len(set(ids))
assert set(p["conflict_ids_resolved_to"]) <= set(ids)
assert all(row["source_payload"] == "biology-v6.1.5-analysis-safety" for row in updates if row["id"] in p["conflict_ids_resolved_to"])
assert all(set(row["fields"]) == {"correct_analysis", "distractor_analyses", "short_lesson"} for row in updates)
assert p["residual_second_pass_ids"] == ["v3_bio_12_08", "v3_bio_15_11", "v3_bio_16_13"]
assert p["canonical_paired_stimulus_ids"] == ["v3_bio_10_11", "v3_bio_11_07", "v3_bio_12_07", "v3_bio_14_10", "v3_bio_15_15", "v3_bio_16_10"]
assert p["visible_stem_quarantined_ids"] == ["v3_bio_11_24", "v3_bio_13_15", "v3_bio_14_20", "v3_bio_15_24", "v3_bio_16_16"]
assert p["unresolved_quarantined_ids"] == ["real_1401_in_geo_153"]
assert p["selection_excluded_ids"] == p["visible_stem_quarantined_ids"]
print("BIOLOGY_SECOND_PASS_SUCCESSOR_OK", len(updates), len(p["canonical_paired_stimulus_ids"]))
