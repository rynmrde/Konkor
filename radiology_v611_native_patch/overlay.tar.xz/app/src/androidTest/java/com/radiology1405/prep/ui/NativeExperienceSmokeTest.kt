package com.radiology1405.prep.ui

import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import com.radiology1405.prep.MainActivity
import org.junit.Rule
import org.junit.Test

class NativeExperienceSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    private fun waitForText(text: String, timeoutMs: Long = 120_000L) {
        compose.waitUntil(timeoutMs) {
            runCatching { compose.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty() }.getOrDefault(false)
        }
    }

    private fun scrollTo(text: String) {
        compose.onNodeWithTag("settings_list").performScrollToNode(hasText(text))
        waitForText(text)
    }

    @Test fun settingsThemeTextAndOfflineAudioAreInteractive() {
        waitForText("تنظیمات", 180_000L)
        compose.onNodeWithText("تنظیمات").performClick()
        waitForText("تم مطالعه")
        compose.onNodeWithText("OLED مشکی").performClick()

        scrollTo("۱۴۰٪")
        compose.onNodeWithText("۱۴۰٪").performClick()
        waitForText("اندازهٔ متن: ۱۴۰٪")

        scrollTo("موسیقی / صدای تمرکز")
        scrollTo("باران")
        compose.onNodeWithText("باران").performClick()
        waitForText("● در حال پخش آفلاین")

        scrollTo("مکث")
        compose.onNodeWithText("مکث").performClick()
        waitForText("وضعیت: متوقف")
    }
}
