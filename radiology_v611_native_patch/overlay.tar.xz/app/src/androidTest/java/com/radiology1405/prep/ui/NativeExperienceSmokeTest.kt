package com.radiology1405.prep.ui

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.radiology1405.prep.MainActivity
import org.junit.Rule
import org.junit.Test

class NativeExperienceSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    private fun waitForText(text: String, timeoutMs: Long = 120_000L) {
        compose.waitUntil(timeoutMs) {
            runCatching { compose.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty() }.getOrDefault(false)
        }
    }

    @Test fun settingsThemeTextAndOfflineAudioAreInteractive() {
        // CI's x86_64 emulator can run without KVM, so first-launch bank verification/copy
        // is intentionally allowed longer while still failing if the real UI never appears.
        waitForText("تنظیمات", 180_000L)
        compose.onNodeWithText("تنظیمات").performClick()
        waitForText("تم مطالعه")
        compose.onNodeWithText("تم مطالعه").fetchSemanticsNode()
        waitForText("OLED مشکی")
        compose.onNodeWithText("OLED مشکی").performClick()
        waitForText("۱۴۰٪")
        compose.onNodeWithText("۱۴۰٪").performScrollTo().performClick()
        waitForText("اندازهٔ متن: ۱۴۰٪")
        compose.onNodeWithText("اندازهٔ متن: ۱۴۰٪").fetchSemanticsNode()
        waitForText("موسیقی / صدای تمرکز")
        compose.onNodeWithText("موسیقی / صدای تمرکز").performScrollTo().fetchSemanticsNode()
        waitForText("باران")
        compose.onNodeWithText("باران").performScrollTo().performClick()
        waitForText("● در حال پخش آفلاین")
        compose.onNodeWithText("● در حال پخش آفلاین").fetchSemanticsNode()
        waitForText("مکث")
        compose.onNodeWithText("مکث").performClick()
    }
}
