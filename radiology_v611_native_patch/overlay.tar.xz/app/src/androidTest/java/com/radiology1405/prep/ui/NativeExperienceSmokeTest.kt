package com.radiology1405.prep.ui

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.radiology1405.prep.MainActivity
import org.junit.Rule
import org.junit.Test

class NativeExperienceSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test fun settingsThemeTextAndOfflineAudioAreInteractive() {
        compose.waitUntil(30_000) { runCatching { compose.onAllNodesWithText("تنظیمات").fetchSemanticsNodes().isNotEmpty() }.getOrDefault(false) }
        compose.onNodeWithText("تنظیمات").performClick()
        compose.onNodeWithText("تم مطالعه").assertExists()
        compose.onNodeWithText("OLED مشکی").performClick()
        compose.onNodeWithText("۱۴۰٪").performScrollTo().performClick()
        compose.waitUntil(5_000) { runCatching { compose.onAllNodesWithText("اندازهٔ متن: ۱۴۰٪").fetchSemanticsNodes().isNotEmpty() }.getOrDefault(false) }
        compose.onNodeWithText("اندازهٔ متن: ۱۴۰٪").assertExists()
        compose.onNodeWithText("موسیقی / صدای تمرکز").performScrollTo().assertExists()
        compose.onNodeWithText("باران").performScrollTo().performClick()
        compose.waitUntil(5_000) { runCatching { compose.onAllNodesWithText("● در حال پخش آفلاین").fetchSemanticsNodes().isNotEmpty() }.getOrDefault(false) }
        compose.onNodeWithText("● در حال پخش آفلاین").assertExists()
        compose.onNodeWithText("مکث").performClick()
    }
}
