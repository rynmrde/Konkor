#!/usr/bin/env python3
import subprocess,sys
for script in ['verify_asset_v6_1.py','verify_native_experience_v61.py','verify_ux_v611.py']:
    r=subprocess.run([sys.executable,script],cwd=__import__('pathlib').Path(__file__).parent)
    if r.returncode: raise SystemExit(r.returncode)
print('V61_PROJECT_STATIC_VALIDATION=PASS')
