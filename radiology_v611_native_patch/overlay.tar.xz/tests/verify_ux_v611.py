from pathlib import Path
import hashlib,re,wave,subprocess
root=Path(__file__).resolve().parents[1]
app=root/'app'
models=(app/'src/main/java/com/radiology1405/prep/data/Models.kt').read_text()
ui=(app/'src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt').read_text()
theme=(app/'src/main/java/com/radiology1405/prep/ui/Theme.kt').read_text()
science=(app/'src/main/java/com/radiology1405/prep/ui/ScienceText.kt').read_text()
exp=(app/'src/main/java/com/radiology1405/prep/ui/ExperienceController.kt').read_text()
vm=(app/'src/main/java/com/radiology1405/prep/StudyViewModel.kt').read_text()
repo=(app/'src/main/java/com/radiology1405/prep/data/StudyRepository.kt').read_text()
build=(app/'build.gradle.kts').read_text()
bankstore=(app/'src/main/java/com/radiology1405/prep/data/BankStore.kt').read_text()
# Feature/UI parity and new UX fixes.
for token in ['MIDNIGHT','OLED','GRAPHITE','EMERALD','VIOLET','ICE','SUNSET','WARM','LIGHT','CONTRAST']:
    assert token in models,token
assert models.count('("') >= 10
for token in ['ThemePreviewRow','chunked(2)','TextScaleCard','ReaderFont.entries','HapticStrength.entries','FocusAudioStrip','پیش‌نمایش زنده','بازنشانی تنظیمات رابط']:
    assert token in ui,token
assert 'valueRange=90f..140f' in ui.replace(' ','')
assert 'testTag(\"settings_list\")' in ui
smoke=(app/'src/androidTest/java/com/radiology1405/prep/ui/NativeExperienceSmokeTest.kt').read_text()
assert 'performScrollToNode' in smoke and 'onNodeWithTag(\"settings_list\")' in smoke
assert 'previewTextScale' in vm and 'commitTextScale' in vm
assert 'coerceIn(90,140)' in theme.replace(' ','')
assert 'LocalTextStyle.current' in science and 'style: TextStyle? = null' in science
for token in ['MediaPlayer()','setAudioAttributes','setDataSource','focusError','autoPreview','ReaderFont','HapticStrength','ToneGenerator','previewFocusVolume','previewSfxVolume']:
    assert token in exp,token
assert 'view.keepScreenOn = experience.settings.keepAwake && (state.screen == AppScreen.STUDY || experience.focusTimerRunning)' in ui
assert 'versionCode = 162' in build and 'versionName = "6.1.1"' in build
# Runtime must consume AAPT's expanded .db asset while retaining a .db.gz fallback.
for token in ['PACKAGED_ASSET = "radiology1405_bank_v6_1.db"','SOURCE_GZIP_ASSET = "radiology1405_bank_v6_1.db.gz"','EXPECTED_DB_SHA256 = "d63219dd6f1621644df495f6b195763924b5c282961cfecf544f7541ab3b673c"','FileNotFoundException','GZIPInputStream','dbDelegate.isInitialized()']:
    assert token in bankstore,token
# Heavy bank open/plans must not block the Compose main thread on first launch.
assert 'suspend fun plans(): List<DayPlan> = withContext(Dispatchers.IO)' in repo
assert 'suspend fun planFor' in repo and '= withContext(Dispatchers.IO)' in repo
assert 'viewModelScope.launch { refreshAll() }' not in vm
# Frozen bank must be byte-identical.
bank=app/'src/main/assets/radiology1405_bank_v6_1.db.gz'
assert hashlib.sha256(bank.read_bytes()).hexdigest()=='b5f47e9803638a37798be398ff4a087f336aafa78470e6f5ad94ac3aa5d7fe14'
# Offline focus media must be real Ogg/Vorbis and non-empty.
for name in ['focus_ambient.ogg','focus_rain.ogg','focus_brown.ogg','focus_pulse.ogg']:
    p=app/'src/main/res/raw'/name
    assert p.is_file() and p.stat().st_size>5000,name
    assert p.read_bytes()[:4]==b'OggS',name
print('V611_UX_STATIC=PASS themes=10 text=90..140 native_audio=4 bank_sha=PASS')
