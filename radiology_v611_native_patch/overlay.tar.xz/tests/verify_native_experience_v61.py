from pathlib import Path
root=Path(__file__).resolve().parents[1];app=root/'app'
build=(app/'build.gradle.kts').read_text();manifest=(app/'src/main/AndroidManifest.xml').read_text();ui=(app/'src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt').read_text();exp=(app/'src/main/java/com/radiology1405/prep/ui/ExperienceController.kt').read_text();legacy=(app/'src/main/java/com/radiology1405/prep/data/LegacyProgressImporter.kt').read_text();repo=(app/'src/main/java/com/radiology1405/prep/data/StudyRepository.kt').read_text();progress=(app/'src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt').read_text()
assert 'applicationId = "com.rynmrde.konkor"' in build
assert 'versionCode = 162' in build and 'versionName = "6.1.1"' in build
assert 'android.permission.INTERNET' not in manifest and 'android.permission.VIBRATE' in manifest
assert 'version = 3' in progress and 'fallbackToDestructiveMigration' not in progress
assert 'radiology1405_progress_v6.db' in progress and 'radiology1405_progress.db' in legacy
assert 'importExternal' in legacy and 'pre_v5_external_restore' in repo
for token in ['sfxEnabled','hapticsEnabled','hapticStrength','readerFont','focusTrack','focusVolume','adhdMode','reducedMotion','highContrast','keepAwake','focusMinutes','startPauseTimer','resetTimer','focusError','autoPreview']:assert token in exp,token
for hook in ['experience.playSfx("select")','experience.playSfx("submit")','ExperienceController','ThemePreviewRow','QuestionNavigator','SessionOutcomeCard']:assert hook in ui,hook
raw=app/'src/main/res/raw';required=[f'sfx_{x}.ogg' for x in ['select','submit','correct','wrong','complete','focus_start','focus_end']]+[f'focus_{x}.ogg' for x in ['ambient','rain','brown','pulse']]
for name in required:
 p=raw/name;assert p.is_file() and p.stat().st_size>1000,name;assert p.read_bytes()[:4]==b'OggS',name
for name in ['ic_nav_home.xml','ic_nav_memory.xml','ic_nav_plan.xml','ic_nav_settings.xml','ic_launcher.xml']:assert (app/'src/main/res/drawable'/name).is_file(),name
print('NATIVE_EXPERIENCE_V61_STATIC=PASS',len(required))
