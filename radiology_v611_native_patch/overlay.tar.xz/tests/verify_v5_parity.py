from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'app/src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt').read_text()
exp=(root/'app/src/main/java/com/radiology1405/prep/ui/ExperienceController.kt').read_text()
models=(root/'app/src/main/java/com/radiology1405/prep/data/Models.kt').read_text()
repo=(root/'app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt').read_text()
vm=(root/'app/src/main/java/com/radiology1405/prep/StudyViewModel.kt').read_text()
build=(root/'app/build.gradle.kts').read_text();manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
for token in ['MIDNIGHT','OLED','GRAPHITE','EMERALD','WARM','LIGHT','fromStored']:assert token in models,token
for token in ['focusTimerRunning','focusRemainingSeconds','focusMinutes','keepAwake','highContrast','"none"','startPauseTimer','resetTimer']:assert token in exp,token
for token in ['FocusTimerCard','QuestionNavigator','SessionOutcomeCard','WeaknessPreview','بازسازی بلوک ثبت‌نشده','پاک کردن همهٔ پیشرفت','کنتراست بالا','روشن ماندن صفحه']:assert token in ui,token
for token in ['restartUnsubmittedSession','wipeProgress','currentOutcome']:assert token in repo and token in vm,token
assert ui.count('ToggleRow("هپتیک"')==1
assert 'applicationId = "com.rynmrde.konkor"' in build
assert 'android.permission.INTERNET' not in manifest
assert 'android.permission.VIBRATE' in manifest
assert 'fallbackToDestructiveMigration' not in (root/'app/src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt').read_text()
print('V5_UI_FEATURE_PARITY_STATIC=PASS')
