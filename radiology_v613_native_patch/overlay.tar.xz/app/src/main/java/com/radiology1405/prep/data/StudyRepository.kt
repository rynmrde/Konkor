package com.radiology1405.prep.data

import android.content.Context
import androidx.room.withTransaction
import com.radiology1405.prep.engine.AdaptiveEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class SessionSummary(
    val entity: ActiveSessionEntity,
    val currentQuestion: Question?,
    val answered: Int,
    val total: Int,
)

internal fun resolvePlanSelection(plans: List<DayPlan>, selectedDate: String?, currentDate: String): DayPlan? {
    if (plans.isEmpty()) return null
    if (selectedDate != null) return plans.firstOrNull { it.date == selectedDate }
    return plans.firstOrNull { it.date == currentDate }
}

internal fun isHoldoutLocked(pool: String, planDate: String, currentDate: String): Boolean =
    pool in setOf("SIM1", "SIM2", "FINAL") && LocalDate.parse(planDate).isAfter(LocalDate.parse(currentDate))

class StudyRepository(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val bank = BankStore(appContext)
    private val database = ProgressDatabase.get(appContext)
    private val dao = database.progressDao()
    private val mutex = Mutex()

    val settings: Flow<AppSettingsEntity?> = dao.observeSettings()
    val mastery: Flow<List<MasteryEntity>> = dao.observeMastery()
    val simulations: Flow<List<SimulationResultEntity>> = dao.observeSimulations()

    suspend fun initialize(): String = withContext(Dispatchers.IO) {
        LegacyProgressImporter(appContext, dao, bank).importOnce().also {
            if (dao.settings() == null) dao.upsertSettings(AppSettingsEntity())
            isolateIncompatibleV6Session()
        }
    }

    /**
     * Stable IDs let V6 progress migrate intact.  A half-finished V6 holdout session is
     * the sole exception: its pool may now contain a quarantined/provisional item.  The
     * raw session is snapshotted and closed; attempts/mastery/settings are never erased.
     */
    private suspend fun isolateIncompatibleV6Session() {
        val active = dao.activeSession() ?: return
        if (sessionCompatible(active)) return
        val raw = sessionJson(active).toString()
        dao.upsertSnapshot(ProgressSnapshotEntity("v6_1_incompatible_active_session", raw, sha256(raw), System.currentTimeMillis()))
        dao.deleteSession(active.name)
    }

    private fun sessionCompatible(session: ActiveSessionEntity): Boolean = runCatching {
        jsonStringList(session.questionIdsJson).all { id ->
            val q = bank.question(id) ?: return@all false
            when (session.pool) {
                "SIM1", "SIM2", "FINAL" -> q.accessPool == session.pool && q.eligibleForSafetyEvidence && !q.needsHumanReview
                else -> q.accessPool == "TRAIN"
            }
        }
    }.getOrDefault(false)

    suspend fun plans(): List<DayPlan> = withContext(Dispatchers.IO) { bank.dayPlans() }

    suspend fun planFor(now: Long = System.currentTimeMillis()): DayPlan? = withContext(Dispatchers.IO) {
        val list = bank.dayPlans()
        if (list.isEmpty()) return@withContext null
        val current = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        resolvePlanSelection(list, null, current)
    }

    suspend fun planForDate(date: String): DayPlan? = withContext(Dispatchers.IO) {
        bank.dayPlans().firstOrNull { it.date == date }
    }

    suspend fun attemptCountForDate(date: String): Int = withContext(Dispatchers.IO) { dao.attemptCountForDate(date) }

    suspend fun activeSummary(): SessionSummary? = withContext(Dispatchers.IO) {
        val entity = dao.activeSession() ?: return@withContext null
        val ids = jsonStringList(entity.questionIdsJson)
        val index = if (entity.phase == "review") entity.reviewPosition else entity.position
        SessionSummary(entity, ids.getOrNull(index)?.let(bank::question), jsonObject(entity.answersJson).length(), ids.size)
    }

    suspend fun startOrResume(selectedDate: String? = null, now: Long = System.currentTimeMillis()): SessionSummary = mutex.withLock {
        withContext(Dispatchers.IO) {
            dao.activeSession()?.takeUnless { it.phase == "done" }?.let { existing ->
                val ids = jsonStringList(existing.questionIdsJson)
                val position = if (existing.phase == "review") existing.reviewPosition else existing.position
                return@withContext SessionSummary(
                    existing,
                    ids.getOrNull(position)?.let(bank::question),
                    jsonObject(existing.answersJson).length(),
                    ids.size,
                )
            }
            dao.deleteSession()
            val currentDate = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate().toString()
            val plan = resolvePlanSelection(bank.dayPlans(), selectedDate, currentDate)
                ?: error(if (selectedDate == null) "امروز خارج از بازهٔ واقعی برنامه است؛ جلسهٔ تازه ساخته نمی‌شود." else "روز انتخاب‌شده در برنامه وجود ندارد.")
            val pool = when (plan.date) {
                "2026-08-17" -> "SIM1"
                "2026-08-18" -> "SIM2"
                "2026-08-19" -> "FINAL"
                else -> "TRAIN"
            }
            require(!isHoldoutLocked(pool, plan.date, currentDate)) {
                "این شبیه‌ساز تا ${plan.date} قفل است تا سؤال‌های Holdout زودتر دیده نشوند."
            }
            val attempted = dao.attemptedQuestionIds().toSet()
            val selectedMode = runCatching { StudyMode.valueOf(dao.settings()?.studyMode ?: StudyMode.AGGRESSIVE_SAFETY.name) }
                .getOrDefault(StudyMode.AGGRESSIVE_SAFETY)
            val policy = AdaptiveEngine.studyModePolicy(selectedMode)
            val masterySnapshot = if (pool == "TRAIN") dao.allMastery() else emptyList()
            val deepTopics = if (pool == "TRAIN" && policy.focusTopicLimit > 0) {
                val weakestInPlan = masterySnapshot.filter { it.microtopic in plan.microtopics }.sortedBy { it.mastery }.map { it.microtopic }
                (weakestInPlan + plan.microtopics).distinct().take(policy.focusTopicLimit)
            } else emptyList()
            val due = if (pool == "TRAIN") {
                dao.dueCredits(now, (policy.dueLimit * 4).coerceAtLeast(policy.dueLimit))
                    .filter { deepTopics.isEmpty() || it.microtopic in deepTopics }
                    .take(policy.dueLimit)
            } else emptyList()
            val selected = mutableListOf<String>()
            val dueQuestionIds = mutableSetOf<String>()
            val consumedCreditIds = mutableListOf<Long>()
            due.forEach { credit ->
                val remediationLevels = when {
                    selectedMode == StudyMode.HARD_EXAM -> policy.preferredLevels
                    credit.reason in setOf("wrong", "blank", "correct_unsure") -> listOf("L2_CONCEPT", "L3_TRAP")
                    else -> policy.preferredLevels
                }
                val excluded = attempted + selected + credit.sourceQuestionId
                val alternative = bank.distinctAlternative(credit.microtopic, excluded, remediationLevels)
                    ?: bank.distinctAlternative(credit.microtopic, excluded)
                if (alternative != null) {
                    selected += alternative
                    dueQuestionIds += alternative
                    consumedCreditIds += credit.id
                }
            }
            if (pool == "TRAIN" && selected.size < policy.weakSlots) {
                masterySnapshot
                    .asSequence()
                    .filter { deepTopics.isEmpty() || it.microtopic in deepTopics }
                    .filter { it.mastery < 0.65 || it.recurringError != null }
                    .sortedWith(compareByDescending<MasteryEntity> { it.recurringError != null }.thenBy { it.mastery })
                    .take((policy.weakSlots - selected.size).coerceAtLeast(0))
                    .forEach { weak ->
                        val levels = when {
                            weak.recurringError != null -> listOf("L2_CONCEPT", "L3_TRAP")
                            weak.confidentCorrectStreak >= 2 -> listOf("L3_TRAP", "L4_TRANSFER")
                            weak.mastery < .45 -> listOf("L2_CONCEPT", "L3_TRAP")
                            else -> listOf("L3_TRAP", "L4_TRANSFER", "L5_STRICT_EXAM")
                        }
                        val excluded = attempted + selected
                        (bank.distinctAlternative(weak.microtopic, excluded, levels)
                            ?: bank.distinctAlternative(weak.microtopic, excluded))?.let { selected += it }
                    }
            }
            val ids = when (pool) {
                "SIM1", "SIM2", "FINAL" -> bank.simulationIds(pool)
                else -> {
                    val size = 15
                    val planTopics = if (deepTopics.isNotEmpty()) deepTopics else plan.microtopics
                    if (policy.hardFirst || policy.focusTopicLimit > 0) {
                        val targetTopics = if (deepTopics.isNotEmpty()) deepTopics
                            else (planTopics + masterySnapshot.sortedBy { it.mastery }.map { it.microtopic }).distinct()
                        var added = true
                        while (selected.size < size && added) {
                            added = false
                            for (topic in targetTopics) {
                                if (selected.size >= size) break
                                val id = bank.distinctAlternative(topic, attempted + selected, policy.preferredLevels)
                                    ?: if (!policy.hardFirst) bank.distinctAlternative(topic, attempted + selected) else null
                                if (id != null) { selected += id; added = true }
                            }
                        }
                    }
                    if (selected.size < size) selected += bank.trainingCandidates(planTopics, attempted + selected, size - selected.size)
                    if (selected.size < size) selected += bank.trainingCandidates(emptyList(), attempted + selected, size - selected.size)
                    // Exact repeat is intentionally last resort after all distinct selected-scope TRAIN items.
                    if (selected.isEmpty()) selected += bank.poolIds("TRAIN").filterNot { it in attempted }.take(size)
                    if (selected.isEmpty()) selected += bank.poolIds("TRAIN").take(size)
                    selected.distinct().take(size)
                }
            }
            require(ids.isNotEmpty()) { "No eligible questions for ${plan.date}" }
            if (consumedCreditIds.isNotEmpty()) dao.consumeCredits(consumedCreditIds)
            val sessionSeed = "${plan.date}|$pool|${dao.allAttempts().size}"
            val orders = JSONObject()
            val cueFlags = JSONObject()
            ids.forEach { id ->
                val question = bank.question(id) ?: error("Bank question $id is missing")
                orders.put(id, JSONArray(AdaptiveEngine.optionOrder(id, sessionSeed, question.sourceCrop != null)))
                when {
                    id in dueQuestionIds -> {
                        cueFlags.put("__cue__$id", true)
                        cueFlags.put("__spaced_attempt__$id", true)
                    }
                    pool == "TRAIN" && question.difficulty >= 3 &&
                        (dao.mastery(question.microtopic)?.mastery ?: 0.0) < .35 ->
                        cueFlags.put("__primer__$id", true)
                }
            }
            val overlap = if (pool in setOf("SIM1", "SIM2")) ids.count { it in attempted } else 0
            val entity = ActiveSessionEntity(
                name = "current",
                date = plan.date,
                mode = "${dao.settings()?.studyMode ?: StudyMode.AGGRESSIVE_SAFETY.name};leak=$overlap",
                pool = pool,
                phase = "test",
                questionIdsJson = JSONArray(ids).toString(),
                position = 0,
                reviewPosition = 0,
                answersJson = "{}",
                confidenceJson = "{}",
                optionOrdersJson = orders.toString(),
                flagsJson = cueFlags.toString(),
                elapsedJson = "{}",
                analysesSeenJson = "{}",
                errorTypesJson = "{}",
                startedEpochMs = now,
                updatedEpochMs = now,
            )
            dao.upsertSession(entity)
            SessionSummary(entity, bank.question(ids.first()), 0, ids.size)
        }
    }

    suspend fun selectOriginal(questionId: String, originalIndex: Int?) = mutateSession { entity ->
        require(originalIndex == null || originalIndex in 0..3)
        val values = jsonObject(entity.answersJson)
        if (originalIndex == null) values.remove(questionId) else values.put(questionId, originalIndex)
        entity.copy(answersJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun setConfidence(questionId: String, confidence: Confidence) = mutateSession { entity ->
        val values = jsonObject(entity.confidenceJson).put(questionId, confidence.name)
        entity.copy(confidenceJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun setErrorType(questionId: String, errorType: ErrorType?) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val entity = dao.activeSession() ?: return@withContext
            val values = jsonObject(entity.errorTypesJson)
            if (errorType == null) values.remove(questionId) else values.put(questionId, errorType.key)
            dao.upsertSession(entity.copy(errorTypesJson = values.toString(), updatedEpochMs = System.currentTimeMillis()))
            if (entity.phase == "review") {
                dao.updateAttemptError("${entity.date}-${entity.pool}-${entity.startedEpochMs}", questionId, errorType?.key)
            }
        }
    }

    suspend fun toggleFlag(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.flagsJson)
        values.put(questionId, !values.optBoolean(questionId))
        entity.copy(flagsJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun dismissCue(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.flagsJson)
        values.remove("__cue__$questionId")
        values.remove("__primer__$questionId")
        entity.copy(flagsJson = values.toString(), cueShown = true, updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun move(delta: Int) = mutateSession { entity ->
        val size = jsonStringList(entity.questionIdsJson).size
        if (entity.phase == "review") entity.copy(
            reviewPosition = (entity.reviewPosition + delta).coerceIn(0, size - 1),
            updatedEpochMs = System.currentTimeMillis(),
        ) else entity.copy(
            position = (entity.position + delta).coerceIn(0, size - 1),
            updatedEpochMs = System.currentTimeMillis(),
        )
    }

    suspend fun goTo(index: Int) = mutateSession { entity ->
        val last = jsonStringList(entity.questionIdsJson).lastIndex
        if (entity.phase == "review") entity.copy(reviewPosition = index.coerceIn(0, last), updatedEpochMs = System.currentTimeMillis())
        else entity.copy(position = index.coerceIn(0, last), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun addElapsed(questionId: String, seconds: Int) = mutateSession { entity ->
        val values = jsonObject(entity.elapsedJson)
        values.put(questionId, values.optInt(questionId) + seconds.coerceAtLeast(0))
        entity.copy(elapsedJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun markAnalysesSeen(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.analysesSeenJson).put(questionId, true)
        entity.copy(analysesSeenJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    private suspend fun mutateSession(block: (ActiveSessionEntity) -> ActiveSessionEntity) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val current = dao.activeSession() ?: return@withContext
            dao.upsertSession(block(current))
        }
    }

    suspend fun submit(now: Long = System.currentTimeMillis()): SessionSummary = mutex.withLock {
        withContext(Dispatchers.IO) {
            val current = dao.activeSession() ?: error("No active session")
            if (current.phase == "review") return@withContext activeSummary() ?: error("Session disappeared")
            val ids = jsonStringList(current.questionIdsJson)
            val answers = jsonObject(current.answersJson)
            val confidence = jsonObject(current.confidenceJson)
            val errors = jsonObject(current.errorTypesJson)
            val elapsed = jsonObject(current.elapsedJson)
            val flags = jsonObject(current.flagsJson)
            val attempts = mutableListOf<AttemptEntity>()
            val masteryUpdates = mutableListOf<MasteryEntity>()
            val masteryByTopic = mutableMapOf<String, MasteryEntity>()
            val credits = mutableListOf<DueCreditEntity>()
            val batchCreditCount = mutableMapOf<String, Int>()
            ids.forEachIndexed { index, id ->
                val q = bank.question(id) ?: error("Missing question $id")
                val selected = if (answers.has(id)) answers.optInt(id) else null
                val confidenceValue = runCatching { Confidence.valueOf(confidence.optString(id, Confidence.CONFIDENT.name)) }
                    .getOrDefault(Confidence.CONFIDENT)
                val grade = AdaptiveEngine.grade(selected, q.correctIndex, confidenceValue)
                val error = ErrorType.entries.firstOrNull { it.key == errors.optString(id) }
                val attempt = AttemptEntity(
                    questionId = id,
                    sessionName = "${current.date}-${current.pool}-${current.startedEpochMs}",
                    date = current.date,
                    subject = q.subject,
                    microtopic = q.microtopic,
                    pool = current.pool,
                    selectedOriginal = selected,
                    correctIndex = q.correctIndex,
                    status = grade.status,
                    confidence = confidenceValue.name,
                    errorType = error?.key,
                    solveSeconds = elapsed.optInt(id),
                    difficulty = q.difficulty,
                    scenarioFamily = q.scenarioFamily,
                    strictOrVerifiedReal = q.strictOrVerifiedReal && q.eligibleForSafetyEvidence,
                    spacedRetrieval = flags.optBoolean("__spaced_attempt__$id"),
                    createdEpochMs = now + index,
                )
                val prior = dao.attemptsFor(q.microtopic) + attempts.filter { it.microtopic == q.microtopic }
                val updatedMastery = AdaptiveEngine.updateMastery(
                    masteryByTopic[q.microtopic] ?: dao.mastery(q.microtopic), attempt, prior,
                )
                attempts += attempt
                masteryByTopic[q.microtopic] = updatedMastery
                masteryUpdates += updatedMastery
                val repeated = error != null && prior.take(4).count { it.errorType == error.key } >= 1
                val capacity = (8 - dao.openCreditCount(q.microtopic) - (batchCreditCount[q.microtopic] ?: 0)).coerceAtLeast(0)
                val newCredits = AdaptiveEngine.buildCredits(q.microtopic, id, grade, error, repeated, now).take(capacity)
                credits += newCredits
                batchCreditCount[q.microtopic] = (batchCreditCount[q.microtopic] ?: 0) + newCredits.size
            }
            val review = current.copy(phase = "review", reviewPosition = 0, updatedEpochMs = now)
            database.withTransaction {
                dao.persistSubmittedSession(review, attempts, masteryUpdates, credits)
                if (current.pool in setOf("SIM1", "SIM2")) {
                    val scores = AdaptiveEngine.reliableScore(attempts)
                    val leak = Regex("leak=(\\d+)").find(current.mode)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    val duration = attempts.sumOf { it.solveSeconds }
                    dao.upsertSimulation(
                        SimulationResultEntity(
                            pool = current.pool,
                            date = current.date,
                            questionIdsJson = current.questionIdsJson,
                            subjectReliableJson = mapJson(scores).toString(),
                            durationSeconds = duration,
                            leakCount = leak,
                            passed = AdaptiveEngine.simulationPassed(scores, leak, duration),
                            remediationJson = remediationMap(attempts).toString(),
                        )
                    )
                }
            }
            SessionSummary(review, ids.firstOrNull()?.let(bank::question), answers.length(), ids.size)
        }
    }

    suspend fun finishReview() = mutateSession { it.copy(phase = "done", updatedEpochMs = System.currentTimeMillis()) }

    suspend fun currentOutcome(): SessionOutcome? = withContext(Dispatchers.IO) {
        val active = dao.activeSession() ?: return@withContext null
        if (active.phase !in setOf("review", "done")) return@withContext null
        val key = "${active.date}-${active.pool}-${active.startedEpochMs}"
        val attempts = dao.allAttempts().filter { it.sessionName == key }
        if (attempts.isEmpty()) return@withContext null
        val bySubject = attempts.groupBy { it.subject }.mapValues { (_, rows) ->
            SubjectOutcome(
                correct = rows.count { it.status == "correct" },
                wrong = rows.count { it.status == "wrong" },
                blank = rows.count { it.status == "blank" },
            )
        }
        SessionOutcome(
            correct = attempts.count { it.status == "correct" },
            wrong = attempts.count { it.status == "wrong" },
            blank = attempts.count { it.status == "blank" },
            total = attempts.size,
            bySubject = bySubject,
        )
    }

    /** V5 parity: rebuild only an unsubmitted test block; submitted history is never erased. */
    suspend fun restartUnsubmittedSession(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val active = dao.activeSession() ?: return@withContext false
            if (active.phase != "test") return@withContext false
            val raw = sessionJson(active).toString()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_restart_${active.startedEpochMs}", raw, sha256(raw), System.currentTimeMillis()))
            dao.deleteSession(active.name)
            true
        }
    }

    /** V5 parity: destructive progress reset with an internal recovery snapshot; bank and UI preferences are preserved. */
    suspend fun wipeProgress(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val before = exportBackup()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_wipe_${System.currentTimeMillis()}", before, sha256(before), System.currentTimeMillis()))
            database.withTransaction {
                dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations(); dao.clearLegacyImport()
            }
            true
        }
    }

    suspend fun saveSettings(value: AppSettingsEntity) = withContext(Dispatchers.IO) { dao.upsertSettings(value.copy(id = 1)) }

    suspend fun safetyState(): SafetyState = withContext(Dispatchers.IO) {
        val recurring = dao.allMastery().any { it.recurringError != null && it.mastery < .65 }
        val spacedConfidentTopics = dao.allAttempts()
            .filter { it.spacedRetrieval && it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }
            .map { it.microtopic }
            .distinct()
            .size
        AdaptiveEngine.safetyState(dao.simulations(), recurring, spacedConfidentTopics)
    }

    private fun remediationMap(attempts: List<AttemptEntity>): JSONObject {
        fun ids(predicate: (AttemptEntity) -> Boolean) = JSONArray(attempts.filter(predicate).map { it.questionId })
        val recurring = attempts.mapNotNull { it.errorType }.groupingBy { it }.eachCount().filterValues { it >= 2 }.keys
        return JSONObject()
            .put("high_ROI_wrong", ids { it.status == "wrong" })
            .put("blank", ids { it.status == "blank" })
            .put("unsure", ids { it.confidence == Confidence.UNSURE.name })
            .put("recurring_trap", JSONArray(recurring.toList()))
            .put("time_loss", ids { it.solveSeconds > 120 })
            .put("prerequisite_failure", ids { it.errorType == ErrorType.KNOWLEDGE_GAP.key || it.errorType == ErrorType.FORGOTTEN_RULE.key })
            .put("low_confidence_correct", ids { it.status == "correct" && it.confidence == Confidence.UNSURE.name })
    }

    suspend fun exportBackup(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
            .put("kind", "radiology1405_v6_1_progress")
            .put("schema", 3)
            .put("bank_sha256", BankStore.EXPECTED_DB_SHA256)
            .put("exported_epoch_ms", System.currentTimeMillis())
        dao.activeSession()?.let { root.put("active_session", sessionJson(it)) }
        root.put("attempts", JSONArray(dao.allAttempts().map(::attemptJson)))
        root.put("mastery", JSONArray(dao.allMastery().map(::masteryJson)))
        root.put("credits", JSONArray(dao.allCredits().map(::creditJson)))
        root.put("simulations", JSONArray(dao.simulations().map(::simulationJson)))
        dao.settings()?.let { root.put("settings", settingsJson(it)) }
        val raw = root.toString(2)
        dao.upsertSnapshot(ProgressSnapshotEntity("latest_export", raw, sha256(raw), System.currentTimeMillis()))
        raw
    }

    /** Import is called only after an explicit UI confirmation; a pre-restore snapshot is retained. */
    suspend fun restoreBackup(raw: String): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val root = runCatching { JSONObject(raw) }.getOrNull() ?: return@withContext false
            if (root.optString("kind") == "radiology1405_progress" || (root.optString("kind").isBlank() && root.has("state"))) {
                val before = exportBackup()
                dao.upsertSnapshot(ProgressSnapshotEntity("pre_v5_external_restore", before, sha256(before), System.currentTimeMillis()))
                database.withTransaction {
                    dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations(); dao.clearSettings(); dao.clearLegacyImport()
                }
                val status = LegacyProgressImporter(appContext, dao, bank).importExternal(raw)
                if (dao.settings() == null) dao.upsertSettings(AppSettingsEntity())
                isolateIncompatibleV6Session()
                return@withContext status.startsWith("converted")
            }
            if (root.optString("kind") !in setOf("radiology1405_v6_progress", "radiology1405_v6_1_progress") || root.optInt("schema") !in 1..3) return@withContext false
            if (root.optString("bank_sha256") !in setOf(
                    "87488c9adc8635a8433fa957c72aaf5950fc5b7af2968bf4511bf933399270ab",
                    BankStore.EXPECTED_DB_SHA256,
                )) return@withContext false
            val ids = root.optJSONArray("attempts") ?: JSONArray()
            for (i in 0 until ids.length()) {
                if (bank.question(ids.getJSONObject(i).getString("questionId")) == null) return@withContext false
            }
            val before = exportBackup()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_restore", before, sha256(before), System.currentTimeMillis()))
            database.withTransaction {
                dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations()
                root.optJSONObject("active_session")?.let(::sessionFromJson)?.takeIf(::sessionCompatible)?.let { dao.upsertSession(it) }
                val attemptValues = jsonObjects(root.optJSONArray("attempts")).map(::attemptFromJson)
                if (attemptValues.isNotEmpty()) dao.insertAttempts(attemptValues)
                jsonObjects(root.optJSONArray("mastery")).map(::masteryFromJson).forEach { dao.upsertMastery(it) }
                val creditValues = jsonObjects(root.optJSONArray("credits")).map(::creditFromJson)
                if (creditValues.isNotEmpty()) dao.insertCredits(creditValues)
                jsonObjects(root.optJSONArray("simulations")).map(::simulationFromJson).forEach { dao.upsertSimulation(it) }
                root.optJSONObject("settings")?.let { dao.upsertSettings(settingsFromJson(it)) }
            }
            true
        }
    }

    override fun close() = bank.close()

    private fun jsonStringList(raw: String): List<String> {
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) add(array.getString(i)) }
    }

    private fun jsonObject(raw: String): JSONObject = runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
    private fun mapJson(values: Map<String, Double>) = JSONObject().also { o -> values.forEach { (k, v) -> o.put(k, v) } }
    private fun jsonObjects(array: JSONArray?): List<JSONObject> = if (array == null) emptyList() else buildList {
        for (i in 0 until array.length()) add(array.getJSONObject(i))
    }
    private fun sha256(raw: String) = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun sessionJson(x: ActiveSessionEntity) = JSONObject().apply {
        put("name", x.name); put("date", x.date); put("mode", x.mode); put("pool", x.pool); put("phase", x.phase)
        put("questionIdsJson", x.questionIdsJson); put("position", x.position); put("reviewPosition", x.reviewPosition)
        put("answersJson", x.answersJson); put("confidenceJson", x.confidenceJson); put("optionOrdersJson", x.optionOrdersJson)
        put("flagsJson", x.flagsJson); put("elapsedJson", x.elapsedJson); put("analysesSeenJson", x.analysesSeenJson)
        put("errorTypesJson", x.errorTypesJson); put("startedEpochMs", x.startedEpochMs); put("updatedEpochMs", x.updatedEpochMs)
        put("cueShown", x.cueShown)
    }
    private fun sessionFromJson(o: JSONObject) = ActiveSessionEntity(
        o.getString("name"), o.getString("date"), o.getString("mode"), o.getString("pool"), o.getString("phase"),
        o.getString("questionIdsJson"), o.getInt("position"), o.getInt("reviewPosition"), o.getString("answersJson"),
        o.getString("confidenceJson"), o.getString("optionOrdersJson"), o.getString("flagsJson"), o.getString("elapsedJson"),
        o.getString("analysesSeenJson"), o.getString("errorTypesJson"), o.getLong("startedEpochMs"), o.getLong("updatedEpochMs"),
        o.optBoolean("cueShown"),
    )
    private fun attemptJson(x: AttemptEntity) = JSONObject().apply {
        put("questionId", x.questionId); put("sessionName", x.sessionName); put("date", x.date); put("subject", x.subject)
        put("microtopic", x.microtopic); put("pool", x.pool); put("selectedOriginal", x.selectedOriginal ?: JSONObject.NULL)
        put("correctIndex", x.correctIndex); put("status", x.status); put("confidence", x.confidence)
        put("errorType", x.errorType ?: JSONObject.NULL); put("solveSeconds", x.solveSeconds)
        put("difficulty", x.difficulty); put("scenarioFamily", x.scenarioFamily)
        put("strictOrVerifiedReal", x.strictOrVerifiedReal); put("spacedRetrieval", x.spacedRetrieval)
        put("createdEpochMs", x.createdEpochMs)
    }
    private fun attemptFromJson(o: JSONObject) = AttemptEntity(
        questionId = o.getString("questionId"), sessionName = o.getString("sessionName"), date = o.getString("date"),
        subject = o.getString("subject"), microtopic = o.getString("microtopic"), pool = o.getString("pool"),
        selectedOriginal = if (o.isNull("selectedOriginal")) null else o.getInt("selectedOriginal"), correctIndex = o.getInt("correctIndex"),
        status = o.getString("status"), confidence = o.getString("confidence"),
        errorType = if (o.isNull("errorType")) null else o.getString("errorType"), solveSeconds = o.getInt("solveSeconds"),
        difficulty = o.optInt("difficulty", 2), scenarioFamily = o.optString("scenarioFamily"),
        strictOrVerifiedReal = o.optBoolean("strictOrVerifiedReal"), spacedRetrieval = o.optBoolean("spacedRetrieval"),
        createdEpochMs = o.getLong("createdEpochMs"),
    )
    private fun masteryJson(x: MasteryEntity) = JSONObject().apply {
        put("microtopic", x.microtopic); put("subject", x.subject); put("mastery", x.mastery); put("memoryStrength", x.memoryStrength)
        put("attempts", x.attempts); put("distinctQuestions", x.distinctQuestions); put("examAttempts", x.examAttempts)
        put("confidentCorrectStreak", x.confidentCorrectStreak); put("recurringError", x.recurringError ?: JSONObject.NULL)
        put("lastAttemptEpochMs", x.lastAttemptEpochMs); put("nextDueEpochMs", x.nextDueEpochMs)
    }
    private fun masteryFromJson(o: JSONObject) = MasteryEntity(
        o.getString("microtopic"), o.getString("subject"), o.getDouble("mastery"), o.getDouble("memoryStrength"),
        o.getInt("attempts"), o.getInt("distinctQuestions"), o.getInt("examAttempts"), o.getInt("confidentCorrectStreak"),
        if (o.isNull("recurringError")) null else o.getString("recurringError"), o.getLong("lastAttemptEpochMs"), o.getLong("nextDueEpochMs"),
    )
    private fun creditJson(x: DueCreditEntity) = JSONObject().apply {
        put("microtopic", x.microtopic); put("reason", x.reason); put("priority", x.priority); put("remaining", x.remaining)
        put("dueEpochMs", x.dueEpochMs); put("sourceQuestionId", x.sourceQuestionId); put("createdEpochMs", x.createdEpochMs); put("consumed", x.consumed)
    }
    private fun creditFromJson(o: JSONObject) = DueCreditEntity(
        microtopic = o.getString("microtopic"), reason = o.getString("reason"), priority = o.getInt("priority"), remaining = o.getInt("remaining"),
        dueEpochMs = o.getLong("dueEpochMs"), sourceQuestionId = o.getString("sourceQuestionId"), createdEpochMs = o.getLong("createdEpochMs"),
        consumed = o.optBoolean("consumed"),
    )
    private fun simulationJson(x: SimulationResultEntity) = JSONObject().apply {
        put("pool", x.pool); put("date", x.date); put("questionIdsJson", x.questionIdsJson); put("subjectReliableJson", x.subjectReliableJson)
        put("durationSeconds", x.durationSeconds); put("leakCount", x.leakCount); put("passed", x.passed)
        put("remediationJson", x.remediationJson)
    }
    private fun simulationFromJson(o: JSONObject) = SimulationResultEntity(
        o.getString("pool"), o.getString("date"), o.getString("questionIdsJson"), o.getString("subjectReliableJson"),
        o.getInt("durationSeconds"), o.getInt("leakCount"), o.getBoolean("passed"), o.optString("remediationJson", "{}"),
    )
    private fun settingsJson(x: AppSettingsEntity) = JSONObject().apply {
        put("theme", x.theme); put("studyMode", x.studyMode); put("motion", x.motion); put("textScale", x.textScale)
        put("focusMode", x.focusMode); put("longStudyMode", x.longStudyMode); put("breaksEnabled", x.breaksEnabled); put("breakEvery", x.breakEvery)
    }
    private fun settingsFromJson(o: JSONObject) = AppSettingsEntity(
        theme = o.getString("theme"), studyMode = o.getString("studyMode"), motion = o.getString("motion"), textScale = o.getInt("textScale").coerceIn(90, 140),
        focusMode = o.getBoolean("focusMode"), longStudyMode = o.getBoolean("longStudyMode"), breaksEnabled = o.getBoolean("breaksEnabled"),
        breakEvery = o.getInt("breakEvery").coerceIn(20, 90),
    )
}
