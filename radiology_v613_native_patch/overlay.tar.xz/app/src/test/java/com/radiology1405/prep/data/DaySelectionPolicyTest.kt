package com.radiology1405.prep.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DaySelectionPolicyTest {
    private fun plan(day: Int, date: String) = DayPlan(date, day, "coverage", 600, 120, listOf("m$day"))

    @Test fun explicitSelectedDayOverridesCalendarDay() {
        val p1 = plan(1, "2026-08-12")
        val p2 = plan(2, "2026-08-13")
        assertEquals(p1, resolvePlanSelection(listOf(p1, p2), p1.date, p2.date))
        assertEquals(p2, resolvePlanSelection(listOf(p1, p2), null, p2.date))
        assertNull(resolvePlanSelection(listOf(p1, p2), "2026-08-20", p2.date))
    }

    @Test fun futureSimulationPoolsStayProtectedButTrainingDaysRemainSelectable() {
        assertTrue(isHoldoutLocked("SIM1", "2026-08-17", "2026-08-13"))
        assertTrue(isHoldoutLocked("FINAL", "2026-08-19", "2026-08-18"))
        assertFalse(isHoldoutLocked("TRAIN", "2026-08-17", "2026-08-13"))
        assertFalse(isHoldoutLocked("SIM1", "2026-08-17", "2026-08-17"))
        assertFalse(isHoldoutLocked("SIM1", "2026-08-17", "2026-08-18"))
    }
}
