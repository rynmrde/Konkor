#!/usr/bin/env python3
"""Static contract guard for the A2 + Final-Hours + A3 disposable composition helper."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
read = lambda path: (root / path).read_text(encoding='utf-8')
repo = read('app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt')
bank = read('app/src/main/java/com/radiology1405/prep/data/BankStore.kt')
models = read('app/src/main/java/com/radiology1405/prep/data/Models.kt')
engine = read('app/src/main/java/com/radiology1405/prep/engine/AdaptiveEngine.kt')
db = read('app/src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt')
validator = read('app/src/main/java/com/radiology1405/prep/data/ProgressPayloadValidator.kt')
test = read('app/src/test/java/com/radiology1405/prep/engine/AdaptiveEngineTest.kt')
start = repo[repo.index('suspend fun startOrResume'):repo.index('val entity = ActiveSessionEntity', repo.index('suspend fun startOrResume'))]
submit = repo[repo.index('suspend fun submit'):repo.index('suspend fun finishReview')]
finish = repo[repo.index('suspend fun finishReview'):repo.index('suspend fun currentOutcome')]
checks = {
    'final-hours dynamic decision and SIM gating': 'FinalHoursPlanner.decide' in repo and 'RecommendationKind.SIM1' in repo and 'RecommendationKind.SIM2' in repo,
    'active-session precedence': 'dao.activeSession()?.takeUnless { it.phase == "done" }' in repo,
    'no exact TRAIN fallback': 'bank.poolIds("TRAIN", allowedTopics' not in start and 'No distinct eligible TRAIN questions remain' in start,
    'evidence followup scenario filter': 'fun selectionKeys' in bank and 'followup:' in bank and 'scenario:' in bank and 'excludedSelectionKeys' in bank,
    'selection threaded all paths': start.count('excludedSelectionKeys = selectedSelectionKeys()') >= 6,
    'final selection invariant': 'Evidence, follow-up, or canonical-scenario repeat in normal TRAIN block' in start,
    'review-repeat accounting': 'attemptEvidenceTag(q)' in submit and 'spacedRetrieval = flags.optBoolean("__spaced_attempt__$id") || reviewRepeat' in submit and 'reviewRepeat && correct' in engine,
    'unique evidence accounting': 'val unique = allAttempts.map(::evidenceKey).distinct().size' in engine,
    'followup regression': 'correctFollowupRepeatIsReviewNotNewMasteryOrCoverage' in test,
    'canonical selection metadata': 'followupGroup' in models and 'canonicalScenarioFingerprint' in models,
    'fail closed session': 'ProgressPayloadValidator.session' in repo and 'fun session(' in validator,
    'fail closed restore': 'ProgressPayloadValidator.backup' in repo and 'RestoredProgress(' in repo,
    'atomic SIM review': 'database.withTransaction' in finish and 'dao.markSimulationReviewed' in finish,
    'migration v4': 'MIGRATION_3_4' in db and 'reviewedEpochMs' in db,
}
failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items(): print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed: raise SystemExit('failed: ' + ', '.join(failed))
print('PASS — A2/Final-Hours/A3 selection composition contract')
