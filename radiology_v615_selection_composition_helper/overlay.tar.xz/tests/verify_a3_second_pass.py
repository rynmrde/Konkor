#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
repo = (root / "app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt").read_text()
bank = (root / "app/src/main/java/com/radiology1405/prep/data/BankStore.kt").read_text()
db = (root / "app/src/main/java/com/radiology1405/prep/data/ProgressDatabase.kt").read_text()
validator = (root / "app/src/main/java/com/radiology1405/prep/data/ProgressPayloadValidator.kt").read_text()
viewmodel = (root / "app/src/main/java/com/radiology1405/prep/StudyViewModel.kt").read_text()
ui = (root / "app/src/main/java/com/radiology1405/prep/ui/RadiologyApp.kt").read_text()
engine = (root / "app/src/main/java/com/radiology1405/prep/engine/AdaptiveEngine.kt").read_text()

checks = {
    "final-hours decision": "finalHoursDecisionInternal" in repo,
    "evidence-family bank filter": "excludedSelectionKeys" in bank and "fun evidenceFamily" in bank and "fun selectionKeys" in bank,
    "no historical train repeat": "Historical question repeat in normal TRAIN block" in repo,
    "no repeat fallback": 'bank.poolIds("TRAIN", allowedTopics, safeOnly = true)' not in repo,
    "unique mastery repeat semantics": "reviewRepeat && correct" in engine and "evidenceKey" in engine and "distinctQuestions = max" in engine,
    "atomic sim finish": "database.withTransaction" in repo[repo.index("suspend fun finishReview"):repo.index("suspend fun currentOutcome")],
    "review witness": "dao.markSimulationReviewed" in repo,
    "fail closed session": "ProgressPayloadValidator.session" in repo,
    "fail closed restore": "ProgressPayloadValidator.backup" in repo and "RestoredProgress(" in repo,
    "session attempts query": "attemptsForSession" in db,
    "review map projection": "persistedQuestionMap" in repo and "questionMap" in viewmodel and "نقشهٔ سؤال‌ها" in ui,
    "schema v4 migration": "MIGRATION_3_4" in db and "reviewedEpochMs" in db,
}
failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed:
    raise SystemExit("failed: " + ", ".join(failed))
