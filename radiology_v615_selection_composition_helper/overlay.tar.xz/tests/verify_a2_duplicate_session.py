#!/usr/bin/env python3
"""A2 deterministic QA: normal-block uniqueness, cosmetic variant suppression and SIM isolation."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
import re
import sqlite3
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--bank-gz', type=Path)
args = parser.parse_args()
# The Git overlay intentionally excludes the immutable bank; use the reconstructed base project
# during local QA, an explicit authoritative bank path, or the colocated CI asset.
BANK_GZ = args.bank_gz or ROOT / 'app/src/main/assets/radiology1405_bank_v6_1.db.gz'
if not BANK_GZ.exists():
    BANK_GZ = ROOT.parent / 'active-project/app/src/main/assets/radiology1405_bank_v6_1.db.gz'
EXPECTED_GZ = 'b5f47e9803638a37798be398ff4a087f336aafa78470e6f5ad94ac3aa5d7fe14'
CANONICAL_PAIRED_STIMULUS_IDS = {
    'v3_bio_02_12','v3_bio_05_12','v3_bio_06_07','v3_bio_07_15','v3_bio_08_07',
    'v3_bio_10_11','v3_bio_11_07','v3_bio_12_07','v3_bio_14_10','v3_bio_15_15',
    'v3_bio_16_10','v3_chem_20_03','v3_chem_26_03','v3_chem_54_07','v3_phys_30_02',
    'v3_phys_33_02','v3_phys_34_03','v3_geo_45_09','v3_geo_46_08','v3_geo_47_07','v3_geo_49_08',
}
PHYSICS_FOLLOWUP_PAIRS = (
    ('v3_phys_30_04', 'v3_phys_30_08'),
    ('v3_phys_30_06', 'v3_phys_30_10'),
)
SOURCE_REPOSITORY = ROOT / 'app/src/main/java/com/radiology1405/prep/data/StudyRepository.kt'
SOURCE_STORE = ROOT / 'app/src/main/java/com/radiology1405/prep/data/BankStore.kt'
SOURCE_ENGINE = ROOT / 'app/src/main/java/com/radiology1405/prep/engine/AdaptiveEngine.kt'
TMP_DB = ROOT / '.a2_duplicate_session_bank.db'

assert hashlib.sha256(BANK_GZ.read_bytes()).hexdigest() == EXPECTED_GZ, 'frozen bank gzip hash mismatch'
with gzip.open(BANK_GZ, 'rb') as src, TMP_DB.open('wb') as dst:
    dst.write(src.read())

translate = str.maketrans({'ي':'ی','ك':'ک','ى':'ی','ة':'ه','ؤ':'و','إ':'ا','أ':'ا'})
def normal(value: object) -> str:
    text = unicodedata.normalize('NFKC', str(value or '')).translate(translate).lower()
    text = text.replace('\u200c', ' ')
    text = re.sub(r'[۰-۹0-9]+', '#', text)
    text = re.sub(r'[\s\W_]+', ' ', text, flags=re.UNICODE).strip()
    return text

def family(row: dict) -> str:
    body = str(row['stem']).split('\n')[-1]
    body = re.sub(r'^داده.?های زیر را با مدل مناسب پیوند دهید.*?به.?دست می.?آید[؟?]\\s*', '', body)
    body = re.sub(r'^برای حل مسئله.? زیر.*?جفت شده است[؟?]\\s*', '', body)
    options = '|'.join(sorted(normal(str(x).split('؛')[0].split(';')[0]) for x in row['options']))
    source = '|'.join([row['subject'], row['microtopic'], normal(body), options])
    return hashlib.sha256(source.encode()).hexdigest()

def selection_keys(row: dict) -> set[str]:
    keys = {f"evidence:{row['evidence_family']}"}
    if row.get('followup_group'):
        keys.add(f"followup:{row['followup_group']}")
    scenario = row.get('canonical_scenario_fingerprint') or row.get('scenario_fingerprint')
    if scenario:
        keys.add(f"scenario:{scenario}")
    return keys

conn = sqlite3.connect(f'file:{TMP_DB}?mode=ro', uri=True)
conn.row_factory = sqlite3.Row
questions = []
for dbrow in conn.execute('SELECT id, subject, microtopic, priority, difficulty, access_pool, selected_scope, obsolete, full_json FROM question'):
    raw = json.loads(dbrow['full_json'])
    question = {
        'id': dbrow['id'], 'subject': dbrow['subject'], 'microtopic': dbrow['microtopic'],
        'priority': dbrow['priority'], 'difficulty': dbrow['difficulty'], 'access_pool': dbrow['access_pool'],
        'selected_scope': bool(dbrow['selected_scope']), 'obsolete': bool(dbrow['obsolete']), **raw,
    }
    question['evidence_family'] = family(question)
    questions.append(question)

ids = [q['id'] for q in questions]
assert len(ids) == len(set(ids)), 'duplicate question ID in frozen bank'
assert all(len(q['options']) == 4 for q in questions), 'a frozen-bank record does not have exactly four options'
assert all(isinstance(q['correct_index'], int) and 0 <= q['correct_index'] < 4 for q in questions), 'a frozen-bank key is outside its four options'
assert all(set((q.get('distractor_analyses') or {}).keys()) >= {'0','1','2','3'} for q in questions), 'a frozen-bank record lacks option analysis coverage'
by_id = {q['id']: q for q in questions}
for first, second in PHYSICS_FOLLOWUP_PAIRS:
    assert first in by_id and second in by_id, 'Physics follow-up regression ID missing'
    assert by_id[first].get('followup_group') and by_id[first].get('followup_group') == by_id[second].get('followup_group'), \
        f'{first}/{second}: frozen followup_group contract lost'
    assert selection_keys(by_id[first]).intersection(selection_keys(by_id[second])), \
        f'{first}/{second}: selector has no shared suppression key'
assert len(CANONICAL_PAIRED_STIMULUS_IDS) == 21, 'canonical paired-stimulus gate must retain the exact confirmed ID set'
assert CANONICAL_PAIRED_STIMULUS_IDS <= set(by_id), 'canonical stimulus set contains an unknown stable ID'
for qid in CANONICAL_PAIRED_STIMULUS_IDS:
    q = by_id[qid]
    stimulus = q.get('stimulus') or {}
    assert q['id'] == qid, f'{qid}: stable ID changed'
    assert q['access_pool'] == 'TRAIN' and q['selected_scope'] and not q['obsolete'], f'{qid}: active TRAIN identity changed'
    assert isinstance(stimulus.get('left'), str) and stimulus['left'].strip(), f'{qid}: canonical stimulus.left missing'
    assert isinstance(stimulus.get('right'), str) and stimulus['right'].strip(), f'{qid}: canonical stimulus.right missing'
train = [q for q in questions if q['access_pool'] == 'TRAIN' and q['selected_scope'] and not q['obsolete'] and q.get('eligible_for_safety_evidence', True) and not q.get('needs_human_review', False)]
by_topic = defaultdict(list)
for q in train:
    by_topic[q['microtopic']].append(q)
for values in by_topic.values():
    values.sort(key=lambda q: (-q['priority'], q['difficulty'], q['id']))

blueprints = json.loads(conn.execute("SELECT json FROM bank_root WHERE key='simulation_blueprints'").fetchone()[0])
sim_sets = {}
for pool in ('SIM1','SIM2'):
    pool_ids = list(blueprints[pool]['question_ids'])
    assert len(pool_ids) == 117 and len(pool_ids) == len(set(pool_ids)), f'{pool} must contain 117 distinct IDs'
    assert all(qid in by_id and by_id[qid]['access_pool'] == pool for qid in pool_ids), f'{pool} pool mismatch'
    assert all(by_id[qid].get('eligible_for_safety_evidence', True) and not by_id[qid].get('needs_human_review', False) for qid in pool_ids), f'{pool} unsafe holdout'
    sim_sets[pool] = set(pool_ids)
assert sim_sets['SIM1'].isdisjoint(sim_sets['SIM2']), 'SIM holdouts overlap'
assert not (set(q['id'] for q in train) & (sim_sets['SIM1'] | sim_sets['SIM2'])), 'SIM holdout leaks into safe TRAIN candidates'
assert not (CANONICAL_PAIRED_STIMULUS_IDS & (sim_sets['SIM1'] | sim_sets['SIM2'])), 'canonical paired-statement records intersect protected SIM holdouts'

rng = random.Random(1405)
topics = sorted(by_topic)
short_blocks = 0
for iteration in range(2000):
    scope = rng.sample(topics, rng.randint(1, len(topics)))
    historical = {q['id'] for q in train if rng.random() < 0.30}
    selected = []
    selected_keys = set()
    # Mirrors patched normal selection: round-robin per topic then global fill, never falling back to historical IDs.
    while len(selected) < 15:
        changed = False
        for topic in scope:
            for q in by_topic[topic]:
                if q['id'] not in historical and q['id'] not in selected and not selection_keys(q).intersection(selected_keys):
                    selected.append(q['id']); selected_keys.update(selection_keys(q)); changed = True
                    break
            if len(selected) == 15:
                break
        if not changed:
            break
    if len(selected) < 15:
        short_blocks += 1
    assert len(selected) == len(set(selected)), f'iteration {iteration}: duplicate question ID'
    assert not (set(selected) & historical), f'iteration {iteration}: historical repeat in normal block'
    observed_keys = [key for qid in selected for key in selection_keys(by_id[qid])]
    assert len(observed_keys) == len(set(observed_keys)), f'iteration {iteration}: evidence/follow-up/canonical-scenario repeat'
    for first, second in PHYSICS_FOLLOWUP_PAIRS:
        assert not ({first, second} <= set(selected)), f'iteration {iteration}: Physics follow-up pair repeated in one normal block'
    assert not (set(selected) & (sim_sets['SIM1'] | sim_sets['SIM2'])), f'iteration {iteration}: SIM holdout leak'

repo = SOURCE_REPOSITORY.read_text(encoding='utf-8')
store = SOURCE_STORE.read_text(encoding='utf-8')
engine = SOURCE_ENGINE.read_text(encoding='utf-8')
# This source gate is deliberately run after all overlays are composed. A Final-Hours change
# may change priorities/stages, but it must not add a normal-TRAIN fallback that ignores history.
selection_start = repo.index('suspend fun startOrResume')
selection_end = repo.index('val entity = ActiveSessionEntity', selection_start)
selection_path = repo[selection_start:selection_end]
assert 'Historical question repeat in normal TRAIN block' in selection_path
assert 'Evidence, follow-up, or canonical-scenario repeat in normal TRAIN block' in selection_path
assert 'selected += bank.poolIds("TRAIN", allowedTopics' not in selection_path, 'Final-Hours composition reintroduced an exact-repeat TRAIN fallback'
assert 'excluded = attempted + selected' in selection_path, 'normal TRAIN selection no longer excludes prior attempts'
assert selection_path.count('excludedSelectionKeys = selectedSelectionKeys()') >= 3, 'selection-key suppression was removed from a selection path'
assert 'fun selectionKeys' in store and 'followup:' in store and 'scenario:' in store
assert 'val masteryDelta = if (reviewRepeat && correct) 0.0 else delta' in engine
assert 'correctFollowupRepeatIsReviewNotNewMasteryOrCoverage' in (ROOT / 'app/src/test/java/com/radiology1405/prep/engine/AdaptiveEngineTest.kt').read_text(encoding='utf-8')
print(json.dumps({
    'status': 'PASS', 'frozen_question_ids': len(ids), 'four_option_and_key_gate': 'PASS', 'safe_train_candidates': len(train),
    'canonical_paired_stimulus_ids_preserved': len(CANONICAL_PAIRED_STIMULUS_IDS),
    'simulation_sizes': {pool: len(values) for pool, values in sim_sets.items()},
    'mass_normal_blocks': 2000, 'adaptive_short_blocks_without_repeat': short_blocks,
    'final_hours_composed_selection_source_gate': 'PASS',
    'physics_followup_pair_regressions': len(PHYSICS_FOLLOWUP_PAIRS),
}, ensure_ascii=False))
TMP_DB.unlink(missing_ok=True)
