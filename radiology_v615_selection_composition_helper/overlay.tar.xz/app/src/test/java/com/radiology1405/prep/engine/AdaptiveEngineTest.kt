package com.radiology1405.prep.engine

import com.radiology1405.prep.data.AttemptEntity
import com.radiology1405.prep.data.Confidence
import com.radiology1405.prep.data.SimulationResultEntity
import com.radiology1405.prep.data.StudyMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

class AdaptiveEngineTest {
    @Test fun optionShuffleIsStablePermutationAndMappingRoundTrips() {
        val first = AdaptiveEngine.optionOrder("q-42", "2026-08-12|TRAIN|0", false)
        val second = AdaptiveEngine.optionOrder("q-42", "2026-08-12|TRAIN|0", false)
        assertEquals(listOf(0, 1, 2, 3), first.sorted())
        assertEquals(first, second)
        assertEquals(listOf(0, 1, 2, 3), AdaptiveEngine.optionOrder("q-42", "s", true))
        first.indices.forEach { display -> assertEquals(first[display], AdaptiveEngine.originalIndex(display, first)) }
    }

    @Test fun adaptiveTwoFourContractIsExact() {
        assertEquals(2, AdaptiveEngine.grade(1, 1, Confidence.CONFIDENT).creditCount)
        assertEquals(4, AdaptiveEngine.grade(1, 1, Confidence.UNSURE).creditCount)
        assertEquals(4, AdaptiveEngine.grade(2, 1, Confidence.CONFIDENT).creditCount)
        assertEquals(4, AdaptiveEngine.grade(null, 1, Confidence.CONFIDENT).creditCount)
    }

    @Test fun spacingIsIncreasingAndClampedToFinalConsolidation() {
        val zone = ZoneId.of("Europe/Helsinki")
        val now = LocalDateTime.of(2026, 8, 17, 10, 0).atZone(zone).toInstant().toEpochMilli()
        val due = AdaptiveEngine.dueTimes(now, 4, zone)
        assertEquals(4, due.size)
        assertTrue(due.zipWithNext().all { it.first <= it.second })
        val cutoff = LocalDateTime.of(2026, 8, 19, 22, 0).atZone(zone).toInstant().toEpochMilli()
        assertTrue(due.last() <= cutoff)
    }

    @Test fun finalDaySpacingNeverSchedulesIntoThePast() {
        val zone = ZoneId.of("Europe/Helsinki")
        val now = LocalDateTime.of(2026, 8, 19, 10, 0).atZone(zone).toInstant().toEpochMilli()
        val due = AdaptiveEngine.dueTimes(now, 4, zone)
        assertTrue(due.all { it >= now })
        assertTrue(due.zipWithNext().all { it.first <= it.second })
    }

    @Test fun safetyRequiresTwoIndependentPassingSimulations() {
        fun result(pool: String, passed: Boolean, leak: Int = 0) = SimulationResultEntity(
            pool, "2026-08-18", "[]", "{}", 0, leak, passed,
        )
        assertFalse(AdaptiveEngine.safetyState(listOf(result("SIM1", true)), false, 5).eligible)
        assertFalse(AdaptiveEngine.safetyState(listOf(result("SIM1", true), result("SIM2", false)), false, 5).eligible)
        assertFalse(AdaptiveEngine.safetyState(listOf(result("SIM1", true, 1), result("SIM2", true)), false, 5).eligible)
        assertTrue(AdaptiveEngine.safetyState(listOf(result("SIM1", true), result("SIM2", true)), false, 5).eligible)
        assertFalse(AdaptiveEngine.safetyState(listOf(result("SIM1", true), result("SIM2", true)), true, 5).eligible)
        assertFalse(AdaptiveEngine.safetyState(listOf(result("SIM1", true), result("SIM2", true)), false, 4).eligible)
    }

    @Test fun reliableScoreDiscountsCorrectButUnsure() {
        val attempts = listOf(
            attempt("زیست", "correct", Confidence.CONFIDENT),
            attempt("زیست", "correct", Confidence.UNSURE),
            attempt("زیست", "wrong", Confidence.CONFIDENT),
        )
        assertEquals(38.8889, AdaptiveEngine.reliableScore(attempts)["زیست"]!!, 0.001)
    }

    @Test fun simulationGateRejectsMissingOrOvertimeDuration() {
        val passing = AdaptiveEngine.safetyThresholds.mapValues { it.value + 1.0 }
        assertFalse(AdaptiveEngine.simulationPassed(passing, 0, 0))
        assertFalse(AdaptiveEngine.simulationPassed(passing, 0, 135 * 60 + 1))
        assertFalse(AdaptiveEngine.simulationPassed(passing, 1, 120 * 60))
        assertTrue(AdaptiveEngine.simulationPassed(passing, 0, 120 * 60))
    }

    @Test fun studyModesHaveDistinctRealPolicies() {
        val balanced = AdaptiveEngine.studyModePolicy(StudyMode.BALANCED_SMART)
        val safety = AdaptiveEngine.studyModePolicy(StudyMode.AGGRESSIVE_SAFETY)
        val deep = AdaptiveEngine.studyModePolicy(StudyMode.DEEP_FOCUS)
        val hard = AdaptiveEngine.studyModePolicy(StudyMode.HARD_EXAM)
        assertTrue(safety.dueLimit > balanced.dueLimit)
        assertEquals(2, deep.focusTopicLimit)
        assertTrue(hard.hardFirst)
        assertTrue("L6_VERIFIED_REAL" in hard.preferredLevels)
        assertNotEquals(balanced, safety)
        assertNotEquals(deep, hard)
    }

    @Test fun breakReminderUsesCumulativeBoundariesWithoutRepeatingAckedOne() {
        assertNull(AdaptiveEngine.breakBoundary(19, 20, emptySet()))
        assertEquals(20, AdaptiveEngine.breakBoundary(20, 20, emptySet()))
        assertNull(AdaptiveEngine.breakBoundary(20, 20, setOf(20)))
        assertEquals(40, AdaptiveEngine.breakBoundary(41, 20, setOf(20)))
    }

    @Test fun correctExactRepeatDoesNotInflateMasteryOrUniqueCoverage() {
        val first = attempt("ریاضی", "correct", Confidence.CONFIDENT, questionId = "math-q-1", createdEpochMs = 1_000L)
        val initial = AdaptiveEngine.updateMastery(null, first, emptyList())
        val repeat = first.copy(createdEpochMs = 2_000L)
        val updated = AdaptiveEngine.updateMastery(initial, repeat, listOf(first))
        assertEquals(initial.mastery, updated.mastery, 0.0000001)
        assertEquals(1, updated.distinctQuestions)
        assertEquals(2, updated.attempts)
    }

    @Test fun correctFollowupRepeatIsReviewNotNewMasteryOrCoverage() {
        val first = attempt("فیزیک", "correct", Confidence.CONFIDENT, questionId = "v3_phys_30_04", createdEpochMs = 1_000L)
            .copy(scenarioFamily = "sf:quantitative_direct|ef:velocity-family|fg:فشار، چگالی و شاره‌ها::subskill_4")
        val initial = AdaptiveEngine.updateMastery(null, first, emptyList())
        val followup = first.copy(
            questionId = "v3_phys_30_08",
            scenarioFamily = "sf:solution_path_audit|ef:velocity-path-family|fg:فشار، چگالی و شاره‌ها::subskill_4",
            createdEpochMs = 2_000L,
            spacedRetrieval = true,
        )
        val updated = AdaptiveEngine.updateMastery(initial, followup, listOf(first))
        assertEquals(initial.mastery, updated.mastery, 0.0000001)
        assertEquals(1, updated.distinctQuestions)
        assertEquals(2, updated.attempts)
    }

    private fun attempt(
        subject: String,
        status: String,
        confidence: Confidence,
        questionId: String = "$subject-$status-${confidence.name}",
        createdEpochMs: Long = 1,
    ) = AttemptEntity(
        questionId = questionId, sessionName = "test", date = "2026-08-12",
        subject = subject, microtopic = "micro", pool = "TRAIN", selectedOriginal = 0, correctIndex = 0,
        status = status, confidence = confidence.name, errorType = null, solveSeconds = 10, createdEpochMs = createdEpochMs,
    )
}
