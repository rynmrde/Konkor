package com.radiology1405.prep

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.radiology1405.prep.ui.RadiologyApp

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels { StudyViewModel.factory(application) }
    private var pendingExport: String? = null

    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val payload = pendingExport
        pendingExport = null
        if (uri == null || payload == null) return@registerForActivityResult
        runCatching {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8).use { writer ->
                requireNotNull(writer) { "Output stream is unavailable" }
                writer.write(payload)
            }
        }.onSuccess {
            Toast.makeText(this, "پشتیبان پیشرفت ذخیره شد", Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(this, "ذخیرهٔ پشتیبان ناموفق بود", Toast.LENGTH_SHORT).show()
        }
    }

    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val raw = runCatching {
            contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8).use { reader -> requireNotNull(reader).readText() }
        }.getOrElse {
            Toast.makeText(this, "خواندن پشتیبان ناموفق بود", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        AlertDialog.Builder(this)
            .setTitle("بازیابی پیشرفت؟")
            .setMessage("پیشرفت فعلی ابتدا نسخه‌برداری داخلی می‌شود، سپس دادهٔ این فایل جایگزین می‌شود.")
            .setNegativeButton("لغو", null)
            .setPositiveButton("بازیابی") { _, _ -> viewModel.restoreBackup(raw) }
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RadiologyApp(
                viewModel = viewModel,
                onExport = { raw ->
                    pendingExport = raw
                    createBackup.launch("radiology1405_progress_v6.json")
                },
                onImport = { openBackup.launch(arrayOf("application/json")) },
            )
        }
    }
}
