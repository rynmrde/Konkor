package com.radiology1405.prep.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Validates persisted payloads before they may replace Room progress.  It deliberately rejects
 * malformed or internally inconsistent state instead of silently normalising it into a different
 * study session.  Legacy V5 import remains a separately snapshotted migration path.
 */
internal object ProgressPayloadValidator {
    private val pools = setOf("TRAIN", "SIM1", "SIM2", "FINAL")
    private val phases = setOf("test", "review", "done")
    private val statuses = setOf("correct", "wrong", "blank")
    private val creditReasons = setOf("wrong", "blank", "correct_unsure")
    private val cuePrefixes = setOf("__cue__", "__spaced_attempt__", "__guided__", "__orientation__", "__primer__")

    fun session(
        value: ActiveSessionEntity,
        questionForId: (String) -> Question?,
    ): Boolean = runCatching {
        require(value.name == "current")
        require(value.pool in pools && value.phase in phases)
        require(value.date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
        require(value.startedEpochMs > 0 && value.updatedEpochMs >= value.startedEpochMs)
        val ids = stringList(value.questionIdsJson)
        require(ids.isNotEmpty() && ids.size == ids.distinct().size)
        require(ids.all { id ->
            val question = questionForId(id) ?: return@all false
            val expectedPool = if (value.pool == "TRAIN") "TRAIN" else value.pool
            question.accessPool == expectedPool && question.eligibleForSafetyEvidence && !question.needsHumanReview
        })
        require(value.position in ids.indices && value.reviewPosition in ids.indices)
        indexedObject(value.answersJson, ids) { raw -> raw is Int && raw in 0..3 }
        indexedObject(value.confidenceJson, ids) { raw -> raw is String && raw in Confidence.entries.map { it.name } }
        optionOrders(value.optionOrdersJson, ids)
        flags(value.flagsJson, ids)
        indexedObject(value.elapsedJson, ids) { raw -> raw is Int && raw >= 0 }
        indexedObject(value.analysesSeenJson, ids) { raw -> raw is Boolean }
        indexedObject(value.errorTypesJson, ids) { raw -> raw is String && ErrorType.entries.any { it.key == raw } }
        true
    }.getOrDefault(false)

    /** The backup is valid only when every row can be reconstructed without coercion. */
    fun backup(
        root: JSONObject,
        questionForId: (String) -> Question?,
        sessionCompatible: (ActiveSessionEntity) -> Boolean,
    ): Boolean = runCatching {
        require(root.optString("kind") in setOf("radiology1405_v6_progress", "radiology1405_v6_1_progress"))
        require(root.optInt("schema") in 1..4)
        val attempts = objects(root.optJSONArray("attempts"))
        val attemptKeys = mutableSetOf<Pair<String, String>>()
        attempts.forEach { attempt ->
            val id = attempt.getString("questionId")
            val question = questionForId(id) ?: error("Unknown attempt question")
            val sessionName = attempt.getString("sessionName")
            require(sessionName.isNotBlank() && attemptKeys.add(sessionName to id))
            require(attempt.getString("date").matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
            require(attempt.getString("pool") in pools)
            require(attempt.getString("subject") == question.subject && attempt.getString("microtopic") == question.microtopic)
            require(attempt.getInt("correctIndex") == question.correctIndex)
            if (!attempt.isNull("selectedOriginal")) require(attempt.getInt("selectedOriginal") in 0..3)
            require(attempt.getString("status") in statuses)
            require(attempt.getString("confidence") in Confidence.entries.map { it.name })
            if (!attempt.isNull("errorType")) require(ErrorType.entries.any { it.key == attempt.getString("errorType") })
            require(attempt.getInt("solveSeconds") >= 0 && attempt.getLong("createdEpochMs") > 0)
            require(attempt.optInt("difficulty", 2) in 1..5)
        }
        val mastery = objects(root.optJSONArray("mastery"))
        require(mastery.map { it.getString("microtopic") }.distinct().size == mastery.size)
        mastery.forEach { row ->
            require(row.getString("microtopic").isNotBlank() && row.getString("subject").isNotBlank())
            require(row.getDouble("mastery").isFinite() && row.getDouble("mastery") in 0.0..1.0)
            require(row.getDouble("memoryStrength").isFinite() && row.getDouble("memoryStrength") in 0.0..1.0)
            require(row.getInt("attempts") >= 0 && row.getInt("distinctQuestions") >= 0 && row.getInt("examAttempts") >= 0)
            require(row.getLong("lastAttemptEpochMs") >= 0 && row.getLong("nextDueEpochMs") >= 0)
            if (!row.isNull("recurringError")) require(ErrorType.entries.any { it.key == row.getString("recurringError") })
        }
        val credits = objects(root.optJSONArray("credits"))
        credits.forEach { row ->
            val source = questionForId(row.getString("sourceQuestionId")) ?: error("Unknown credit source")
            require(row.getString("microtopic") == source.microtopic && row.getString("reason") in creditReasons)
            require(row.getInt("priority") >= 0 && row.getInt("remaining") >= 0)
            require(row.getLong("dueEpochMs") >= 0 && row.getLong("createdEpochMs") >= 0)
        }
        val simulations = objects(root.optJSONArray("simulations"))
        require(simulations.map { it.getString("pool") }.distinct().size == simulations.size)
        simulations.forEach { row ->
            val pool = row.getString("pool")
            require(pool in setOf("SIM1", "SIM2"))
            val ids = stringList(row.getString("questionIdsJson"))
            require(ids.isNotEmpty() && ids.size == ids.distinct().size)
            require(ids.all { questionForId(it)?.accessPool == pool })
            require(row.getInt("durationSeconds") >= 0 && row.getInt("leakCount") >= 0)
            require(JSONObject(row.getString("subjectReliableJson")).keys().asSequence().all { key ->
                JSONObject(row.getString("subjectReliableJson")).getDouble(key).isFinite()
            })
            require(JSONObject(row.optString("remediationJson", "{}")).length() >= 0)
            if (!row.isNull("reviewedEpochMs")) require(row.getLong("reviewedEpochMs") > 0)
        }
        root.optJSONObject("active_session")?.let { active ->
            val session = ActiveSessionEntity(
                active.getString("name"), active.getString("date"), active.getString("mode"), active.getString("pool"), active.getString("phase"),
                active.getString("questionIdsJson"), active.getInt("position"), active.getInt("reviewPosition"), active.getString("answersJson"),
                active.getString("confidenceJson"), active.getString("optionOrdersJson"), active.getString("flagsJson"), active.getString("elapsedJson"),
                active.getString("analysesSeenJson"), active.getString("errorTypesJson"), active.getLong("startedEpochMs"), active.getLong("updatedEpochMs"), active.optBoolean("cueShown"),
            )
            require(sessionCompatible(session))
        }
        root.optJSONObject("settings")?.let { settings ->
            require(settings.getString("theme").isNotBlank())
            require(settings.getString("studyMode") in StudyMode.entries.map { it.name })
            require(settings.getString("motion") in MotionMode.entries.map { it.name })
            require(settings.getInt("textScale") in 90..140 && settings.getInt("breakEvery") in 20..90)
            settings.getBoolean("focusMode"); settings.getBoolean("longStudyMode"); settings.getBoolean("breaksEnabled")
        }
        true
    }.getOrDefault(false)

    private fun stringList(raw: String): List<String> {
        val array = JSONArray(raw)
        return List(array.length()) { index -> array.getString(index).also { require(it.isNotBlank()) } }
    }

    private fun objects(array: JSONArray?): List<JSONObject> = if (array == null) emptyList() else List(array.length()) { index -> array.getJSONObject(index) }

    private fun indexedObject(raw: String, ids: List<String>, predicate: (Any) -> Boolean) {
        val objectValue = JSONObject(raw)
        objectValue.keys().forEach { key -> require(key in ids && predicate(objectValue.get(key))) }
    }

    private fun optionOrders(raw: String, ids: List<String>) {
        val objectValue = JSONObject(raw)
        require(objectValue.length() == ids.size)
        ids.forEach { id ->
            val order = objectValue.getJSONArray(id)
            require(order.length() == 4 && List(4) { order.getInt(it) }.sorted() == listOf(0, 1, 2, 3))
        }
    }

    private fun flags(raw: String, ids: List<String>) {
        val objectValue = JSONObject(raw)
        objectValue.keys().forEach { key ->
            require(objectValue.get(key) is Boolean)
            if (key !in ids) {
                val id = cuePrefixes.firstNotNullOfOrNull { prefix -> key.removePrefix(prefix).takeIf { key.startsWith(prefix) } }
                require(id != null && id in ids)
            }
        }
    }
}
