package com.radiology1405.prep.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.radiology1405.prep.engine.AdaptiveEngine
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.time.LocalDate

/** One-way, non-destructive bridge from the V5 WebView snapshot database. */
class LegacyProgressImporter(
    private val context: Context,
    private val dao: ProgressDao,
    private val bank: BankStore,
) {
    private fun digest(raw: String): String = MessageDigest.getInstance("SHA-256")
        .digest(raw.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    suspend fun importOnce(): String {
        dao.legacyImport()?.let { return it.status }
        val now = System.currentTimeMillis()
        val oldFile = context.getDatabasePath("radiology1405_progress.db")
        if (!oldFile.exists()) {
            dao.upsertLegacyImport(LegacyImportEntity(rawJson = "", status = "not_present", importedEpochMs = now))
            return "not_present"
        }
        val raw = readLatest(oldFile)
        if (raw.isNullOrBlank()) {
            dao.upsertLegacyImport(LegacyImportEntity(rawJson = "", status = "empty", importedEpochMs = now))
            return "empty"
        }

        return importRaw(raw, now, "legacy_v5_raw")
    }

    /** Explicit import path for a V5 JSON export. Used when Android signing prevents an in-place APK update. */
    suspend fun importExternal(raw: String): String = importRaw(raw, System.currentTimeMillis(), "legacy_v5_external_raw")

    /** Reject malformed external state before the caller clears current Room progress. */
    fun isValidExternalPayload(raw: String): Boolean = runCatching {
        val outer = JSONObject(raw)
        require(outer.optString("kind").let { it.isBlank() || it == "radiology1405_progress" })
        val state = outer.optJSONObject("state") ?: outer
        state.optJSONArray("attempts")?.let { attempts ->
            for (index in 0 until attempts.length()) {
                val row = attempts.getJSONObject(index)
                val id = row.getString("question_id")
                require(bank.question(id) != null)
                row.opt("answer_original")?.let { answer ->
                    if (answer != JSONObject.NULL) require((answer as? Number)?.toInt() in 0..3)
                }
            }
        }
        val days = state.optJSONObject("days") ?: return@runCatching
        days.keys().asSequence().forEach { date ->
            val rounds = days.optJSONObject(date)?.optJSONArray("rounds") ?: return@forEach
            for (index in 0 until rounds.length()) {
                val round = rounds.optJSONObject(index) ?: continue
                require(round.optString("phase", "test") in setOf("test", "review", "done"))
                val ids = round.optJSONArray("ids") ?: continue
                val unique = buildList { for (item in 0 until ids.length()) add(ids.getString(item)) }
                require(unique.isNotEmpty() && unique.size == unique.distinct().size)
                require(unique.all { bank.question(it)?.accessPool == "TRAIN" })
            }
        }
    }.isSuccess

    private suspend fun importRaw(raw: String, now: Long, snapshotName: String): String {
        // Raw preservation happens before interpretation: parse failure cannot erase V5 progress.
        dao.upsertLegacyImport(LegacyImportEntity(rawJson = raw, status = "preserved_raw_only", importedEpochMs = now))
        dao.upsertSnapshot(ProgressSnapshotEntity(snapshotName, raw, digest(raw), now))
        return try {
            val outer = JSONObject(raw)
            require(outer.optString("kind").let { it.isBlank() || it == "radiology1405_progress" })
            val state = outer.optJSONObject("state") ?: outer
            importSettings(state.optJSONObject("settings"))
            importAttempts(state.optJSONArray("attempts") ?: JSONArray(), now)
            rebuildMasteryFromImportedAttempts()
            val activeImported = importActiveRound(state, now)
            val status = if (activeImported) "converted_with_exact_train_resume" else "converted_history_raw_resume_not_eligible"
            dao.upsertLegacyImport(LegacyImportEntity(rawJson = raw, status = status, importedEpochMs = now))
            status
        } catch (_: Exception) {
            dao.upsertLegacyImport(LegacyImportEntity(rawJson = raw, status = "preserved_raw_only", importedEpochMs = now))
            "preserved_raw_only"
        }
    }

    private suspend fun rebuildMasteryFromImportedAttempts() {
        if (dao.allMastery().isNotEmpty()) return
        val prior = mutableMapOf<String, MutableList<AttemptEntity>>()
        val current = mutableMapOf<String, MasteryEntity>()
        dao.allAttempts().sortedBy { it.createdEpochMs }.forEach { attempt ->
            val earlier = prior.getOrPut(attempt.microtopic) { mutableListOf() }
            val next = AdaptiveEngine.updateMastery(current[attempt.microtopic], attempt, earlier.toList())
            current[attempt.microtopic] = next
            dao.upsertMastery(next)
            earlier += attempt
        }
    }

    private fun readLatest(file: File): String? {
        val opened = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try {
            opened.rawQuery(
                "SELECT raw FROM snapshot WHERE name IN ('latest','previous_session','previous_day') " +
                    "ORDER BY CASE name WHEN 'latest' THEN 0 WHEN 'previous_session' THEN 1 ELSE 2 END LIMIT 1",
                null,
            ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
        } finally {
            opened.close()
        }
    }

    private suspend fun importSettings(old: JSONObject?) {
        if (old == null || dao.settings() != null) return
        val theme = ThemeFamily.fromStored(old.optString("theme"))
        val study = when (old.optString("studyProfile")) {
            "aggressive" -> StudyMode.AGGRESSIVE_SAFETY
            "deep" -> StudyMode.DEEP_FOCUS
            "hard" -> StudyMode.HARD_EXAM
            else -> StudyMode.BALANCED_SMART
        }
        val motion = when (old.optString("motion")) {
            "minimal" -> MotionMode.MINIMAL
            "dynamic" -> MotionMode.DYNAMIC
            "lively" -> MotionMode.LIVELY
            else -> MotionMode.CALM
        }
        dao.upsertSettings(
            AppSettingsEntity(
                theme = theme.name,
                studyMode = study.name,
                motion = motion.name,
                textScale = old.optInt("fontScale", 100).coerceIn(90, 140),
                focusMode = old.optBoolean("focus", true),
                longStudyMode = old.optBoolean("longMode", false),
                breaksEnabled = old.optBoolean("breaks", true),
                breakEvery = old.optInt("breakEvery", 40).coerceIn(20, 90),
            )
        )
    }

    private suspend fun importAttempts(array: JSONArray, importedAt: Long) {
        if (dao.allAttempts().isNotEmpty()) return
        val converted = buildList {
            for (i in 0 until array.length()) {
                val old = array.optJSONObject(i) ?: continue
                val id = old.optString("question_id")
                val question = bank.question(id) ?: continue
                val status = when {
                    old.optBoolean("blank") -> "blank"
                    old.optBoolean("correct") -> "correct"
                    else -> "wrong"
                }
                add(
                    AttemptEntity(
                        questionId = id,
                        sessionName = "legacy-${old.optInt("day", 0)}-${old.optInt("round", 0)}",
                        date = old.optString("date", "2026-08-12"),
                        subject = question.subject,
                        microtopic = question.microtopic,
                        pool = old.optString("pool", "TRAIN"),
                        selectedOriginal = old.opt("answer_original")?.let { if (it == JSONObject.NULL) null else (it as? Number)?.toInt() },
                        correctIndex = question.correctIndex,
                        status = status,
                        confidence = if (old.optBoolean("unsure")) Confidence.UNSURE.name else Confidence.CONFIDENT.name,
                        errorType = old.optString("error_type").takeIf { it.isNotBlank() && it != "null" },
                        solveSeconds = old.optInt("solve_seconds", 0),
                        difficulty = question.difficulty,
                        scenarioFamily = question.scenarioFamily,
                        strictOrVerifiedReal = question.strictOrVerifiedReal && question.eligibleForSafetyEvidence,
                        spacedRetrieval = false,
                        createdEpochMs = importedAt - (array.length() - i) * 1000L,
                    )
                )
            }
        }
        if (converted.isNotEmpty()) dao.insertAttempts(converted)
    }

    private suspend fun importActiveRound(state: JSONObject, now: Long): Boolean {
        if (dao.activeSession() != null) return false
        val dayNumber = state.optInt("day", 1)
        val legacyDate = LocalDate.of(2026, 8, 11).plusDays((dayNumber - 1).coerceAtLeast(0).toLong()).toString()
        val day = state.optJSONObject("days")?.optJSONObject(legacyDate) ?: return false
        val rounds = day.optJSONArray("rounds") ?: return false
        var round: JSONObject? = null
        for (i in 0 until rounds.length()) {
            val candidate = rounds.optJSONObject(i) ?: continue
            if (candidate.optString("phase") in setOf("test", "review")) round = candidate
        }
        val active = round ?: return false
        val idsArray = active.optJSONArray("ids") ?: return false
        val ids = buildList { for (i in 0 until idsArray.length()) add(idsArray.getString(i)) }
        if (ids.isEmpty()) return false
        // Never import a V5 session that could expose a newly isolated V6 simulation/final item.
        if (ids.any { bank.question(it)?.accessPool != "TRAIN" }) return false
        val ordersOld = active.optJSONObject("optionOrders") ?: JSONObject()
        val normalizedOrders = JSONObject()
        ids.forEach { id ->
            val oldOrder = ordersOld.optJSONArray(id)
            val parsedOrder = oldOrder?.let { array ->
                if (array.length() == 4) (0..3).map(array::getInt) else null
            }
            val valid = parsedOrder?.sorted() == listOf(0, 1, 2, 3)
            val order = if (valid) JSONArray(requireNotNull(parsedOrder)) else JSONArray(AdaptiveEngine.optionOrder(id, "legacy-$legacyDate", false))
            normalizedOrders.put(id, order)
        }
        dao.upsertSession(
            ActiveSessionEntity(
                name = "current",
                date = maxOf(legacyDate, "2026-08-12"),
                mode = "legacy_import",
                pool = "TRAIN",
                phase = active.optString("phase", "test"),
                questionIdsJson = JSONArray(ids).toString(),
                position = active.optInt("currentIndex", 0).coerceIn(0, ids.lastIndex),
                reviewPosition = active.optInt("reviewIndex", 0).coerceIn(0, ids.lastIndex),
                answersJson = (active.optJSONObject("answers") ?: JSONObject()).toString(),
                confidenceJson = legacyConfidence(active, ids).toString(),
                optionOrdersJson = normalizedOrders.toString(),
                flagsJson = (active.optJSONObject("flags") ?: JSONObject()).toString(),
                elapsedJson = (active.optJSONObject("solveTimes") ?: JSONObject()).toString(),
                analysesSeenJson = (active.optJSONObject("analysesSeen") ?: JSONObject()).toString(),
                errorTypesJson = (active.optJSONObject("errorTypes") ?: JSONObject()).toString(),
                startedEpochMs = now,
                updatedEpochMs = now,
            )
        )
        return true
    }

    private fun legacyConfidence(active: JSONObject, ids: List<String>): JSONObject {
        val unsure = active.optJSONObject("unsure") ?: JSONObject()
        return JSONObject().also { output ->
            ids.forEach { id -> output.put(id, if (unsure.optBoolean(id)) Confidence.UNSURE.name else Confidence.CONFIDENT.name) }
        }
    }
}
