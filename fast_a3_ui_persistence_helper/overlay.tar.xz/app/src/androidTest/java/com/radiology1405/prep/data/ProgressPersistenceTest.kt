package com.radiology1405.prep.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProgressPersistenceTest {
    private lateinit var context: Context
    private val name = "process-death-test.db"

    @Before fun before() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase(name)
    }

    @After fun after() { context.deleteDatabase(name) }

    @Test fun exactSessionSurvivesDatabaseCloseAndReopen() = runBlocking {
        val expected = ActiveSessionEntity(
            name = "current", date = "2026-08-12", mode = "AGGRESSIVE_SAFETY;leak=0", pool = "TRAIN",
            phase = "test", questionIdsJson = "[\"q1\",\"q2\"]", position = 1, reviewPosition = 0,
            answersJson = "{\"q1\":2}", confidenceJson = "{\"q1\":\"UNSURE\"}",
            optionOrdersJson = "{\"q1\":[2,0,3,1],\"q2\":[0,1,2,3]}", flagsJson = "{\"q1\":true}",
            elapsedJson = "{\"q1\":83}", analysesSeenJson = "{}", errorTypesJson = "{}",
            startedEpochMs = 10, updatedEpochMs = 20, cueShown = false,
        )
        var database = open()
        database.progressDao().upsertSession(expected)
        database.close()

        database = open()
        val restored = database.progressDao().activeSession()
        assertNotNull(restored)
        assertEquals(expected, restored)
        database.close()
    }

    private fun open(): ProgressDatabase = Room.databaseBuilder(context, ProgressDatabase::class.java, name)
        .addMigrations(ProgressDatabase.MIGRATION_1_2, ProgressDatabase.MIGRATION_2_3)
        .build()
}
