package com.radiology1405.prep.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScienceTextTest {
    @Test fun isolationPreservesEveryScienceCharacter() {
        val source = "5′→3′ H₂SO₄ SO₄²⁻ Fe³⁺ 2H₂ + O₂ → 2H₂O x² x₁ √x |x| lim sin θ log₂x P(A∩B) 3×10⁸ m/s² Ω ΔE"
        val isolated = isolateScientificRuns(source)
        assertTrue(isolated.contains('\u2066'))
        assertTrue(isolated.contains('\u2069'))
        assertEquals(source, removeScientificIsolates(isolated))
    }
}
