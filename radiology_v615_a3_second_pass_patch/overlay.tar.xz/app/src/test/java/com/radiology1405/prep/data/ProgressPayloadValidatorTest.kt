package com.radiology1405.prep.data

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressPayloadValidatorTest {
    private val question = Question(
        id = "q1", subject = "Biology", microtopic = "m1", sourceType = "authored", sourceFile = null, sourcePage = null,
        difficulty = 2, estimatedSeconds = 60, questionForm = "mcq", scenarioFamily = "family-1", stem = "stem",
        options = listOf("a", "b", "c", "d"), correctIndex = 1, correctAnalysis = "why", optionAnalyses = (0..3).associateWith { "x" },
        shortLesson = "lesson", fastMethod = "method", mainTrap = "trap", teachingLevel = "L1_DIRECT", accessPool = "TRAIN",
        needsHumanReview = false, eligibleForSafetyEvidence = true, strictOrVerifiedReal = false, sourceCrop = null,
    )

    private fun session(ids: String = "[\"q1\"]", answers: String = "{}") = ActiveSessionEntity(
        name = "current", date = "2026-08-20", mode = "safe", pool = "TRAIN", phase = "test", questionIdsJson = ids,
        position = 0, reviewPosition = 0, answersJson = answers, confidenceJson = "{}", optionOrdersJson = "{\"q1\":[0,1,2,3]}",
        flagsJson = "{}", elapsedJson = "{}", analysesSeenJson = "{}", errorTypesJson = "{}", startedEpochMs = 1, updatedEpochMs = 1,
    )

    @Test fun activeSessionRejectsDuplicateIdsAndForeignPayloadKeys() {
        assertFalse(ProgressPayloadValidator.session(session(ids = "[\"q1\",\"q1\"]"), ::find))
        assertFalse(ProgressPayloadValidator.session(session(answers = "{\"other\":1}"), ::find))
        assertTrue(ProgressPayloadValidator.session(session(), ::find))
    }

    @Test fun backupRejectsDuplicateAttemptRowsBeforeReplacement() {
        val row = JSONObject()
            .put("questionId", "q1").put("sessionName", "s").put("date", "2026-08-20")
            .put("subject", "Biology").put("microtopic", "m1").put("pool", "TRAIN")
            .put("selectedOriginal", 1).put("correctIndex", 1).put("status", "correct")
            .put("confidence", "CONFIDENT").put("errorType", JSONObject.NULL).put("solveSeconds", 20).put("createdEpochMs", 10)
        val root = JSONObject()
            .put("kind", "radiology1405_v6_1_progress").put("schema", 4)
            .put("attempts", JSONArray().put(row).put(JSONObject(row.toString())))
            .put("mastery", JSONArray()).put("credits", JSONArray()).put("simulations", JSONArray())
        assertFalse(ProgressPayloadValidator.backup(root, ::find) { ProgressPayloadValidator.session(it, ::find) })
    }

    private fun find(id: String): Question? = question.takeIf { it.id == id }
}
