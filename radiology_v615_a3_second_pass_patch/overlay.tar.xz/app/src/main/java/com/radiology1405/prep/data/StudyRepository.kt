package com.radiology1405.prep.data

import android.content.Context
import androidx.room.withTransaction
import com.radiology1405.prep.engine.AdaptiveEngine
import com.radiology1405.prep.engine.FinalHoursPlanner
import com.radiology1405.prep.engine.FinalHoursPlanner.FinalHoursDecision
import com.radiology1405.prep.engine.FinalHoursPlanner.FinalHoursInput
import com.radiology1405.prep.engine.FinalHoursPlanner.RecommendationKind
import com.radiology1405.prep.engine.RescueMetrics
import com.radiology1405.prep.engine.RescuePlanner
import com.radiology1405.prep.engine.RescueTopic
import com.radiology1405.prep.engine.TeachingEvidence
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.time.Instant

data class SessionSummary(
    val entity: ActiveSessionEntity,
    val currentQuestion: Question?,
    val answered: Int,
    val total: Int,
)

class StudyRepository(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val bank = BankStore(appContext)
    private val database = ProgressDatabase.get(appContext)
    private val dao = database.progressDao()
    private val mutex = Mutex()
    private val rescueTriage by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        RescuePlanner.triage(bank.rescueProfiles())
    }

    val settings: Flow<AppSettingsEntity?> = dao.observeSettings()
    val mastery: Flow<List<MasteryEntity>> = dao.observeMastery()
    val simulations: Flow<List<SimulationResultEntity>> = dao.observeSimulations()

    suspend fun initialize(): String = withContext(Dispatchers.IO) {
        LegacyProgressImporter(appContext, dao, bank).importOnce().also {
            if (dao.settings() == null) dao.upsertSettings(AppSettingsEntity())
            isolateIncompatibleV6Session()
        }
    }

    /**
     * Stable IDs let V6 progress migrate intact. A half-finished session containing an
     * item that is no longer eligible for the rescue/Safety path is the sole exception.
     * Its raw session is snapshotted and closed; attempts/mastery/settings are never erased.
     */
    private suspend fun isolateIncompatibleV6Session() {
        val active = dao.activeSession() ?: return
        if (sessionCompatible(active)) return
        val raw = sessionJson(active).toString()
        dao.upsertSnapshot(ProgressSnapshotEntity("v6_1_incompatible_active_session", raw, sha256(raw), System.currentTimeMillis()))
        dao.deleteSession(active.name)
    }

    private fun sessionCompatible(session: ActiveSessionEntity): Boolean =
        ProgressPayloadValidator.session(session, bank::question)

    /**
     * The Day Selector remains available, but its sole live card is derived from actual
     * Iran-time/Room evidence rather than from historical calendar quotas.
     */
    suspend fun plans(now: Long = System.currentTimeMillis()): List<DayPlan> = withContext(Dispatchers.IO) {
        listOf(dayPlan(finalHoursDecisionInternal(now), now))
    }

    suspend fun rescueTopics(): List<RescueTopic> = withContext(Dispatchers.IO) { rescueTriage }

    suspend fun rescueMetrics(): RescueMetrics = withContext(Dispatchers.IO) { RescuePlanner.metrics(rescueTriage) }

    suspend fun finalHoursDecision(now: Long = System.currentTimeMillis()): FinalHoursDecision = withContext(Dispatchers.IO) {
        finalHoursDecisionInternal(now)
    }

    private suspend fun finalHoursDecisionInternal(now: Long): FinalHoursDecision {
        val attempts = dao.allAttempts()
        val simulations = dao.simulations()
        return FinalHoursPlanner.decide(
            FinalHoursInput(
                profiles = rescueTriage.map { it.profile },
                attempts = attempts,
                mastery = dao.allMastery(),
                dueCredits = dao.allCredits(),
                simulations = simulations,
                activeSession = dao.activeSession(),
                sim1UnrepairedTopics = unresolvedSim1Topics(simulations, attempts),
                nowEpochMs = now,
            )
        )
    }

    private fun dayPlan(decision: FinalHoursDecision, now: Long): DayPlan {
        val date = Instant.ofEpochMilli(now).atZone(FinalHoursPlanner.IRAN_ZONE).toLocalDate().toString()
        return DayPlan(
            date = date,
            day = decision.phase.ordinal + 1,
            phase = decision.phase.fa,
            totalStudyMinutes = decision.availableStudyMinutes,
            attemptBudget = decision.questionCount,
            microtopics = decision.recommendedTopics,
        )
    }

    private fun unresolvedSim1Topics(simulations: List<SimulationResultEntity>, attempts: List<AttemptEntity>): Set<String> {
        val sim1 = simulations.firstOrNull { it.pool == "SIM1" } ?: return emptySet()
        val simAttempts = attempts.filter { it.pool == "SIM1" && it.questionId in jsonStringList(sim1.questionIdsJson) }
        val weakTopics = simAttempts.filter { it.status != "correct" || it.confidence != Confidence.CONFIDENT.name }
            .map { it.microtopic }.toSet()
        val lastSimEvidence = simAttempts.maxOfOrNull { it.createdEpochMs } ?: return weakTopics
        return weakTopics.filter { topic ->
            attempts.none {
                it.pool == "TRAIN" && it.microtopic == topic && it.createdEpochMs > lastSimEvidence &&
                    it.status == "correct" && it.confidence == Confidence.CONFIDENT.name
            }
        }.toSet()
    }

    suspend fun planFor(now: Long = System.currentTimeMillis()): DayPlan? = withContext(Dispatchers.IO) {
        dayPlan(finalHoursDecisionInternal(now), now)
    }

    suspend fun planForDate(date: String, now: Long = System.currentTimeMillis()): DayPlan? = withContext(Dispatchers.IO) {
        planFor(now)?.takeIf { it.date == date }
    }

    suspend fun attemptCountForDate(date: String): Int = withContext(Dispatchers.IO) { dao.attemptCountForDate(date) }

    suspend fun activeSummary(): SessionSummary? = withContext(Dispatchers.IO) {
        val entity = dao.activeSession() ?: return@withContext null
        if (!sessionCompatible(entity)) return@withContext null
        val ids = jsonStringList(entity.questionIdsJson)
        val index = if (entity.phase == "review") entity.reviewPosition else entity.position
        SessionSummary(entity, ids.getOrNull(index)?.let(bank::question), jsonObject(entity.answersJson).length(), ids.size)
    }

    /** Stable Question Map projection survives navigation, recreation, reopening Review, and backup restore. */
    suspend fun persistedQuestionMap(): List<PersistedQuestionMapEntry> = withContext(Dispatchers.IO) {
        val active = dao.activeSession() ?: return@withContext emptyList()
        if (!sessionCompatible(active)) return@withContext emptyList()
        val ids = jsonStringList(active.questionIdsJson)
        val answers = jsonObject(active.answersJson)
        val flags = jsonObject(active.flagsJson)
        val attempts = if (active.phase in setOf("review", "done")) {
            dao.attemptsForSession("${active.date}-${active.pool}-${active.startedEpochMs}").associateBy { it.questionId }
        } else emptyMap()
        ids.map { id ->
            val result = when (attempts[id]?.status) {
                "correct" -> QuestionMapResult.CORRECT
                "wrong" -> QuestionMapResult.WRONG
                "blank" -> QuestionMapResult.BLANK
                else -> null
            }
            PersistedQuestionMapEntry(
                questionId = id,
                selectedOriginalIndex = if (answers.has(id)) answers.optInt(id) else null,
                isFlagged = flags.optBoolean(id),
                result = result,
            )
        }
    }

    /** UI-neutral persisted snapshot retained for the corrected Review/Map integration. */
    suspend fun questionMapSnapshot(): PersistedQuestionMapSnapshot? = withContext(Dispatchers.IO) {
        val session = dao.activeSession() ?: return@withContext null
        if (!sessionCompatible(session)) return@withContext null
        val attempts = if (session.phase in setOf("review", "done")) dao.attemptsForSession("${session.date}-${session.pool}-${session.startedEpochMs}") else emptyList()
        QuestionMapSessionProjection.snapshot(session, attempts)
    }

    /** Direct map navigation persists the corresponding test or Review position atomically. */
    suspend fun goToQuestion(questionId: String) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val session = dao.activeSession() ?: return@withContext
            require(sessionCompatible(session)) { "Malformed active session cannot navigate Question Map" }
            val index = QuestionMapSessionProjection.snapshot(session, emptyList()).indexOf(questionId)
            require(index >= 0) { "Question is not in the active session" }
            val updated = if (session.phase == "review") session.copy(reviewPosition = index, updatedEpochMs = System.currentTimeMillis())
            else session.copy(position = index, updatedEpochMs = System.currentTimeMillis())
            dao.upsertSession(updated)
        }
    }

    suspend fun startOrResume(selectedDate: String? = null, now: Long = System.currentTimeMillis()): SessionSummary = mutex.withLock {
        withContext(Dispatchers.IO) {
            dao.activeSession()?.takeUnless { it.phase == "done" }?.let { existing ->
                if (sessionCompatible(existing)) {
                    val ids = jsonStringList(existing.questionIdsJson)
                    val position = if (existing.phase == "review") existing.reviewPosition else existing.position
                    return@withContext SessionSummary(
                        existing,
                        ids.getOrNull(position)?.let(bank::question),
                        jsonObject(existing.answersJson).length(),
                        ids.size,
                    )
                }
                val raw = sessionJson(existing).toString()
                dao.upsertSnapshot(ProgressSnapshotEntity("malformed_active_session", raw, sha256(raw), now))
                dao.deleteSession(existing.name)
            }
            dao.deleteSession()
            val currentDate = Instant.ofEpochMilli(now).atZone(FinalHoursPlanner.IRAN_ZONE).toLocalDate().toString()
            val plan = dayPlan(finalHoursDecisionInternal(now), now)
            require(selectedDate == null || selectedDate == plan.date) { "روز انتخاب‌شده دیگر کارت زندهٔ برنامه‌ریز نیست؛ امروز را دوباره انتخاب کن." }
            val decision = finalHoursDecisionInternal(now)
            require(decision.kind !in setOf(RecommendationKind.REST, RecommendationKind.COMPLETE)) { decision.detailFa }
            val allAttempts = dao.allAttempts()
            val pool = when (decision.kind) {
                RecommendationKind.SIM1 -> "SIM1"
                RecommendationKind.SIM2 -> "SIM2"
                else -> "TRAIN"
            }
            val diagnosticBlock = decision.kind == RecommendationKind.DIAGNOSTIC
            val attempted = allAttempts.map { it.questionId }.toSet()
            val selectedMode = runCatching { StudyMode.valueOf(dao.settings()?.studyMode ?: StudyMode.AGGRESSIVE_SAFETY.name) }
                .getOrDefault(StudyMode.AGGRESSIVE_SAFETY)
            val policy = AdaptiveEngine.studyModePolicy(selectedMode)
            val masterySnapshot = if (pool == "TRAIN") dao.allMastery() else emptyList()
            val allEligibleTopics = rescueTriage.filter { it.profile.safeTrainQuestions > 0 }.map { it.profile.microtopic }
            val allowedTopics = when (decision.kind) {
                RecommendationKind.MIXED_DIAGNOSTIC -> allEligibleTopics
                else -> decision.recommendedTopics.ifEmpty { allEligibleTopics }
            }.distinct()
            val primaryTopics = decision.recommendedTopics.ifEmpty { allowedTopics }
            val deepTopics = if (pool == "TRAIN" && !diagnosticBlock && policy.focusTopicLimit > 0) {
                val weakestInPlan = masterySnapshot.filter { it.microtopic in primaryTopics }
                    .sortedBy { it.mastery }.map { it.microtopic }
                (weakestInPlan + primaryTopics).distinct().take(policy.focusTopicLimit)
            } else emptyList()
            val due = if (pool == "TRAIN") {
                dao.dueCredits(now, (policy.dueLimit * 4).coerceAtLeast(policy.dueLimit))
                    .filter { it.microtopic in allowedTopics }
                    .take(policy.dueLimit)
            } else emptyList()
            val selected = mutableListOf<String>()
            fun selectedEvidenceFamilies(): Set<String> = selected.mapNotNull(bank::evidenceFamily).toSet()
            val dueQuestionIds = mutableSetOf<String>()
            val guidedQuestionIds = mutableSetOf<String>()
            val consumedCreditIds = mutableListOf<Long>()
            fun evidenceFor(topic: String): List<TeachingEvidence> = allAttempts.asSequence()
                .filter { it.microtopic == topic }
                .mapNotNull { attempt ->
                    bank.question(attempt.questionId)?.let { question ->
                        TeachingEvidence(question.teachingLevel, attempt.status, attempt.confidence)
                    }
                }
                .toList()
            due.forEach { credit ->
                val remediation = credit.reason in setOf("wrong", "blank", "correct_unsure")
                val preferredLevels = if (remediation) listOf("L2_CONCEPT", "L1_DIRECT")
                    else RescuePlanner.preferredTeachingLevels(evidenceFor(credit.microtopic))
                val excluded = attempted + selected + credit.sourceQuestionId
                val alternative = bank.distinctAlternative(
                    microtopic = credit.microtopic,
                    excluded = excluded,
                    excludedEvidenceFamilies = selectedEvidenceFamilies(),
                    preferredLevels = preferredLevels,
                    safeOnly = true,
                ) ?: bank.distinctAlternative(
                    microtopic = credit.microtopic,
                    excluded = excluded,
                    excludedEvidenceFamilies = selectedEvidenceFamilies(),
                    safeOnly = true,
                )
                if (alternative != null) {
                    selected += alternative
                    dueQuestionIds += alternative
                    if (remediation) guidedQuestionIds += alternative
                    consumedCreditIds += credit.id
                }
            }
            if (pool == "TRAIN" && selected.size < policy.weakSlots) {
                val weakScope = if (diagnosticBlock) primaryTopics else allowedTopics
                masterySnapshot
                    .asSequence()
                    .filter { it.microtopic in weakScope }
                    .filter { deepTopics.isEmpty() || it.microtopic in deepTopics }
                    .filter { it.mastery < 0.65 || it.recurringError != null }
                    .sortedWith(compareByDescending<MasteryEntity> { it.recurringError != null }.thenBy { it.mastery })
                    .take((policy.weakSlots - selected.size).coerceAtLeast(0))
                    .forEach { weak ->
                        val remediation = weak.recurringError != null || weak.mastery < .45
                        val levels = if (remediation) listOf("L2_CONCEPT", "L1_DIRECT")
                            else RescuePlanner.preferredTeachingLevels(evidenceFor(weak.microtopic))
                        val excluded = attempted + selected
                        (bank.distinctAlternative(
                            microtopic = weak.microtopic,
                            excluded = excluded,
                            excludedEvidenceFamilies = selectedEvidenceFamilies(),
                            preferredLevels = levels,
                            safeOnly = true,
                        ) ?: bank.distinctAlternative(
                            microtopic = weak.microtopic,
                            excluded = excluded,
                            excludedEvidenceFamilies = selectedEvidenceFamilies(),
                            safeOnly = true,
                        ))?.let {
                            selected += it
                            if (remediation) guidedQuestionIds += it
                        }
                    }
            }
            val ids = when (pool) {
                "SIM1", "SIM2" -> bank.simulationIds(pool)
                else -> {
                    val size = decision.questionCount.coerceIn(1, 75)
                    val targetTopics = if (deepTopics.isNotEmpty()) deepTopics else primaryTopics
                    var added = true
                    while (selected.size < size && added) {
                        added = false
                        for (topic in targetTopics) {
                            if (selected.size >= size) break
                            val levels = RescuePlanner.preferredTeachingLevels(evidenceFor(topic))
                            val id = bank.distinctAlternative(
                                microtopic = topic,
                                excluded = attempted + selected,
                                excludedEvidenceFamilies = selectedEvidenceFamilies(),
                                preferredLevels = levels,
                                safeOnly = true,
                            ) ?: bank.distinctAlternative(
                                microtopic = topic,
                                excluded = attempted + selected,
                                excludedEvidenceFamilies = selectedEvidenceFamilies(),
                                safeOnly = true,
                            )
                            if (id != null) {
                                selected += id
                                added = true
                            }
                        }
                    }
                    if (selected.size < size) {
                        selected += bank.trainingCandidates(
                            microtopics = allowedTopics,
                            excluded = attempted + selected,
                            excludedEvidenceFamilies = selectedEvidenceFamilies(),
                            limit = size - selected.size,
                            safeOnly = true,
                        )
                    }
                    if (selected.size < size) {
                        error("No distinct eligible TRAIN questions remain for this adaptive block; reduce the recommendation rather than repeat a question.")
                    }
                    // A shorter adaptive block is better than re-serving an exact or cosmetic variant as new evidence.
                    selected.distinct().take(size)
                }
            }
            require(ids.isNotEmpty()) { "No eligible questions for ${plan.date}" }
            require(ids.size == ids.distinct().size) { "Duplicate question ID in $pool block" }
            if (pool == "TRAIN") {
                require(ids.size <= decision.questionCount.coerceIn(1, 75)) {
                    "Unexpected TRAIN block size: ${ids.size}"
                }
                require(ids.none { it in attempted }) { "Historical question repeat in normal TRAIN block" }
                val evidenceFamilies = ids.mapNotNull(bank::evidenceFamily)
                require(evidenceFamilies.size == evidenceFamilies.distinct().size) {
                    "Cosmetic evidence repeat in normal TRAIN block"
                }
            } else {
                require(ids.size == 117) { "Unexpected $pool block size: ${ids.size}" }
            }
            if (consumedCreditIds.isNotEmpty()) dao.consumeCredits(consumedCreditIds)
            val sessionSeed = "${plan.date}|$pool|${allAttempts.size}"
            val orders = JSONObject()
            val cueFlags = JSONObject()
            val orientedTopics = mutableSetOf<String>()
            ids.forEach { id ->
                val question = bank.question(id) ?: error("Bank question $id is missing")
                orders.put(id, JSONArray(AdaptiveEngine.optionOrder(id, sessionSeed, question.sourceCrop != null)))
                when {
                    id in dueQuestionIds -> {
                        cueFlags.put("__cue__$id", true)
                        cueFlags.put("__spaced_attempt__$id", true)
                        if (id in guidedQuestionIds) cueFlags.put("__guided__$id", true)
                    }
                    id in guidedQuestionIds -> cueFlags.put("__guided__$id", true)
                    pool == "TRAIN" && allAttempts.none { it.microtopic == question.microtopic } &&
                        orientedTopics.add(question.microtopic) ->
                        cueFlags.put("__orientation__$id", true)
                    pool == "TRAIN" && question.difficulty >= 3 &&
                        (dao.mastery(question.microtopic)?.mastery ?: 0.0) < .35 ->
                        cueFlags.put("__primer__$id", true)
                }
            }
            val overlap = ids.count { it in attempted }
            require(overlap == 0) { "$pool session repeats a previously attempted question: $overlap" }
            require(ids.distinct().size == ids.size) { "$pool session contains duplicate question IDs" }
            val entity = ActiveSessionEntity(
                name = "current",
                date = plan.date,
                mode = "${dao.settings()?.studyMode ?: StudyMode.AGGRESSIVE_SAFETY.name};finalHours=${decision.kind.name};repeatCount=$overlap",
                pool = pool,
                phase = "test",
                questionIdsJson = JSONArray(ids).toString(),
                position = 0,
                reviewPosition = 0,
                answersJson = "{}",
                confidenceJson = "{}",
                optionOrdersJson = orders.toString(),
                flagsJson = cueFlags.toString(),
                elapsedJson = "{}",
                analysesSeenJson = "{}",
                errorTypesJson = "{}",
                startedEpochMs = now,
                updatedEpochMs = now,
            )
            dao.upsertSession(entity)
            SessionSummary(entity, bank.question(ids.first()), 0, ids.size)
        }
    }

    suspend fun selectOriginal(questionId: String, originalIndex: Int?) = mutateSession { entity ->
        require(originalIndex == null || originalIndex in 0..3)
        val values = jsonObject(entity.answersJson)
        if (originalIndex == null) values.remove(questionId) else values.put(questionId, originalIndex)
        entity.copy(answersJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun setConfidence(questionId: String, confidence: Confidence) = mutateSession { entity ->
        val values = jsonObject(entity.confidenceJson).put(questionId, confidence.name)
        entity.copy(confidenceJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun setErrorType(questionId: String, errorType: ErrorType?) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val entity = dao.activeSession() ?: return@withContext
            val values = jsonObject(entity.errorTypesJson)
            if (errorType == null) values.remove(questionId) else values.put(questionId, errorType.key)
            dao.upsertSession(entity.copy(errorTypesJson = values.toString(), updatedEpochMs = System.currentTimeMillis()))
            if (entity.phase == "review") {
                dao.updateAttemptError("${entity.date}-${entity.pool}-${entity.startedEpochMs}", questionId, errorType?.key)
            }
        }
    }

    suspend fun toggleFlag(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.flagsJson)
        values.put(questionId, !values.optBoolean(questionId))
        entity.copy(flagsJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun dismissCue(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.flagsJson)
        values.remove("__cue__$questionId")
        values.remove("__primer__$questionId")
        values.remove("__orientation__$questionId")
        values.remove("__guided__$questionId")
        entity.copy(flagsJson = values.toString(), cueShown = true, updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun move(delta: Int) = mutateSession { entity ->
        val size = jsonStringList(entity.questionIdsJson).size
        if (entity.phase == "review") entity.copy(
            reviewPosition = (entity.reviewPosition + delta).coerceIn(0, size - 1),
            updatedEpochMs = System.currentTimeMillis(),
        ) else entity.copy(
            position = (entity.position + delta).coerceIn(0, size - 1),
            updatedEpochMs = System.currentTimeMillis(),
        )
    }

    suspend fun goTo(index: Int) = mutateSession { entity ->
        val last = jsonStringList(entity.questionIdsJson).lastIndex
        if (entity.phase == "review") entity.copy(reviewPosition = index.coerceIn(0, last), updatedEpochMs = System.currentTimeMillis())
        else entity.copy(position = index.coerceIn(0, last), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun addElapsed(questionId: String, seconds: Int) = mutateSession { entity ->
        val values = jsonObject(entity.elapsedJson)
        values.put(questionId, values.optInt(questionId) + seconds.coerceAtLeast(0))
        entity.copy(elapsedJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    suspend fun markAnalysesSeen(questionId: String) = mutateSession { entity ->
        val values = jsonObject(entity.analysesSeenJson).put(questionId, true)
        entity.copy(analysesSeenJson = values.toString(), updatedEpochMs = System.currentTimeMillis())
    }

    private suspend fun mutateSession(block: (ActiveSessionEntity) -> ActiveSessionEntity) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val current = dao.activeSession() ?: return@withContext
            dao.upsertSession(block(current))
        }
    }

    suspend fun submit(now: Long = System.currentTimeMillis()): SessionSummary = mutex.withLock {
        withContext(Dispatchers.IO) {
            val current = dao.activeSession() ?: error("No active session")
            if (current.phase == "review") return@withContext activeSummary() ?: error("Session disappeared")
            val ids = jsonStringList(current.questionIdsJson)
            val answers = jsonObject(current.answersJson)
            val confidence = jsonObject(current.confidenceJson)
            val errors = jsonObject(current.errorTypesJson)
            val elapsed = jsonObject(current.elapsedJson)
            val flags = jsonObject(current.flagsJson)
            val attempts = mutableListOf<AttemptEntity>()
            val masteryUpdates = mutableListOf<MasteryEntity>()
            val masteryByTopic = mutableMapOf<String, MasteryEntity>()
            val credits = mutableListOf<DueCreditEntity>()
            val batchCreditCount = mutableMapOf<String, Int>()
            ids.forEachIndexed { index, id ->
                val q = bank.question(id) ?: error("Missing question $id")
                val selected = if (answers.has(id)) answers.optInt(id) else null
                val confidenceValue = runCatching { Confidence.valueOf(confidence.optString(id, Confidence.CONFIDENT.name)) }
                    .getOrDefault(Confidence.CONFIDENT)
                val grade = AdaptiveEngine.grade(selected, q.correctIndex, confidenceValue)
                val error = ErrorType.entries.firstOrNull { it.key == errors.optString(id) }
                val attempt = AttemptEntity(
                    questionId = id,
                    sessionName = "${current.date}-${current.pool}-${current.startedEpochMs}",
                    date = current.date,
                    subject = q.subject,
                    microtopic = q.microtopic,
                    pool = current.pool,
                    selectedOriginal = selected,
                    correctIndex = q.correctIndex,
                    status = grade.status,
                    confidence = confidenceValue.name,
                    errorType = error?.key,
                    solveSeconds = elapsed.optInt(id),
                    difficulty = q.difficulty,
                    scenarioFamily = q.scenarioFamily,
                    strictOrVerifiedReal = q.strictOrVerifiedReal && q.eligibleForSafetyEvidence,
                    spacedRetrieval = flags.optBoolean("__spaced_attempt__$id"),
                    createdEpochMs = now + index,
                )
                val prior = dao.attemptsFor(q.microtopic) + attempts.filter { it.microtopic == q.microtopic }
                val updatedMastery = AdaptiveEngine.updateMastery(
                    masteryByTopic[q.microtopic] ?: dao.mastery(q.microtopic), attempt, prior,
                )
                attempts += attempt
                masteryByTopic[q.microtopic] = updatedMastery
                masteryUpdates += updatedMastery
                val repeated = error != null && prior.take(4).count { it.errorType == error.key } >= 1
                val capacity = (8 - dao.openCreditCount(q.microtopic) - (batchCreditCount[q.microtopic] ?: 0)).coerceAtLeast(0)
                val newCredits = AdaptiveEngine.buildCredits(q.microtopic, id, grade, error, repeated, now).take(capacity)
                credits += newCredits
                batchCreditCount[q.microtopic] = (batchCreditCount[q.microtopic] ?: 0) + newCredits.size
            }
            val review = current.copy(phase = "review", reviewPosition = 0, updatedEpochMs = now)
            database.withTransaction {
                dao.persistSubmittedSession(review, attempts, masteryUpdates, credits)
                if (current.pool in setOf("SIM1", "SIM2")) {
                    val scores = AdaptiveEngine.reliableScore(attempts)
                    val leak = Regex("leak=(\\d+)").find(current.mode)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    val duration = attempts.sumOf { it.solveSeconds }
                    dao.upsertSimulation(
                        SimulationResultEntity(
                            pool = current.pool,
                            date = current.date,
                            questionIdsJson = current.questionIdsJson,
                            subjectReliableJson = mapJson(scores).toString(),
                            durationSeconds = duration,
                            leakCount = leak,
                            passed = AdaptiveEngine.simulationPassed(scores, leak, duration),
                            remediationJson = remediationMap(attempts).toString(),
                        )
                    )
                }
            }
            SessionSummary(review, ids.firstOrNull()?.let(bank::question), answers.length(), ids.size)
        }
    }

    /** A reviewed SIM witness and the corresponding active-session completion must commit together. */
    suspend fun finishReview(now: Long = System.currentTimeMillis()) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val active = dao.activeSession() ?: return@withContext
            require(sessionCompatible(active)) { "Malformed active session cannot be completed" }
            database.withTransaction {
                if (active.phase == "review" && active.pool in setOf("SIM1", "SIM2")) {
                    dao.markSimulationReviewed(active.pool, now)
                }
                dao.upsertSession(active.copy(phase = "done", updatedEpochMs = now))
            }
        }
    }

    suspend fun currentOutcome(): SessionOutcome? = withContext(Dispatchers.IO) {
        val active = dao.activeSession() ?: return@withContext null
        if (active.phase !in setOf("review", "done")) return@withContext null
        val key = "${active.date}-${active.pool}-${active.startedEpochMs}"
        val attempts = dao.attemptsForSession(key)
        if (attempts.isEmpty()) return@withContext null
        val bySubject = attempts.groupBy { it.subject }.mapValues { (_, rows) ->
            SubjectOutcome(
                correct = rows.count { it.status == "correct" },
                wrong = rows.count { it.status == "wrong" },
                blank = rows.count { it.status == "blank" },
            )
        }
        SessionOutcome(
            correct = attempts.count { it.status == "correct" },
            wrong = attempts.count { it.status == "wrong" },
            blank = attempts.count { it.status == "blank" },
            total = attempts.size,
            bySubject = bySubject,
        )
    }

    /** V5 parity: rebuild only an unsubmitted test block; submitted history is never erased. */
    suspend fun restartUnsubmittedSession(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val active = dao.activeSession() ?: return@withContext false
            if (active.phase != "test") return@withContext false
            val raw = sessionJson(active).toString()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_restart_${active.startedEpochMs}", raw, sha256(raw), System.currentTimeMillis()))
            dao.deleteSession(active.name)
            true
        }
    }

    /** V5 parity: destructive progress reset with an internal recovery snapshot; bank and UI preferences are preserved. */
    suspend fun wipeProgress(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val before = exportBackup()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_wipe_${System.currentTimeMillis()}", before, sha256(before), System.currentTimeMillis()))
            database.withTransaction {
                dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations(); dao.clearLegacyImport()
            }
            true
        }
    }

    suspend fun saveSettings(value: AppSettingsEntity) = withContext(Dispatchers.IO) { dao.upsertSettings(value.copy(id = 1)) }

    suspend fun safetyState(): SafetyState = withContext(Dispatchers.IO) {
        val recurring = dao.allMastery().any { it.recurringError != null && it.mastery < .65 }
        val spacedConfidentTopics = dao.allAttempts()
            .filter { it.spacedRetrieval && it.status == "correct" && it.confidence == Confidence.CONFIDENT.name }
            .map { it.microtopic }
            .distinct()
            .size
        AdaptiveEngine.safetyState(dao.simulations(), recurring, spacedConfidentTopics)
    }

    private fun remediationMap(attempts: List<AttemptEntity>): JSONObject {
        fun ids(predicate: (AttemptEntity) -> Boolean) = JSONArray(attempts.filter(predicate).map { it.questionId })
        val recurring = attempts.mapNotNull { it.errorType }.groupingBy { it }.eachCount().filterValues { it >= 2 }.keys
        return JSONObject()
            .put("high_ROI_wrong", ids { it.status == "wrong" })
            .put("blank", ids { it.status == "blank" })
            .put("unsure", ids { it.confidence == Confidence.UNSURE.name })
            .put("recurring_trap", JSONArray(recurring.toList()))
            .put("time_loss", ids { it.solveSeconds > 120 })
            .put("prerequisite_failure", ids { it.errorType == ErrorType.KNOWLEDGE_GAP.key || it.errorType == ErrorType.FORGOTTEN_RULE.key })
            .put("low_confidence_correct", ids { it.status == "correct" && it.confidence == Confidence.UNSURE.name })
    }

    suspend fun exportBackup(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
            .put("kind", "radiology1405_v6_1_progress")
            .put("schema", 4)
            .put("bank_sha256", BankStore.EXPECTED_DB_SHA256)
            .put("exported_epoch_ms", System.currentTimeMillis())
        dao.activeSession()?.let { root.put("active_session", sessionJson(it)) }
        root.put("attempts", JSONArray(dao.allAttempts().map(::attemptJson)))
        root.put("mastery", JSONArray(dao.allMastery().map(::masteryJson)))
        root.put("credits", JSONArray(dao.allCredits().map(::creditJson)))
        root.put("simulations", JSONArray(dao.simulations().map(::simulationJson)))
        dao.settings()?.let { root.put("settings", settingsJson(it)) }
        val raw = root.toString(2)
        dao.upsertSnapshot(ProgressSnapshotEntity("latest_export", raw, sha256(raw), System.currentTimeMillis()))
        raw
    }

    /** Import is called only after an explicit UI confirmation; all payloads validate before any Room row is cleared. */
    suspend fun restoreBackup(raw: String): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val root = runCatching { JSONObject(raw) }.getOrNull() ?: return@withContext false
            if (root.optString("kind") == "radiology1405_progress" || (root.optString("kind").isBlank() && root.has("state"))) {
                val importer = LegacyProgressImporter(appContext, dao, bank)
                if (!importer.isValidExternalPayload(raw)) return@withContext false
                val before = exportBackup()
                dao.upsertSnapshot(ProgressSnapshotEntity("pre_v5_external_restore", before, sha256(before), System.currentTimeMillis()))
                return@withContext runCatching {
                    database.withTransaction {
                        dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations(); dao.clearSettings(); dao.clearLegacyImport()
                        val status = importer.importExternal(raw)
                        require(status.startsWith("converted")) { "Malformed legacy restore" }
                        if (dao.settings() == null) dao.upsertSettings(AppSettingsEntity())
                        isolateIncompatibleV6Session()
                    }
                    true
                }.getOrDefault(false)
            }
            if (root.optString("bank_sha256") !in setOf(
                    "87488c9adc8635a8433fa957c72aaf5950fc5b7af2968bf4511bf933399270ab",
                    BankStore.EXPECTED_DB_SHA256,
                )) return@withContext false
            if (!ProgressPayloadValidator.backup(root, bank::question, ::sessionCompatible)) return@withContext false
            val parsed = runCatching {
                RestoredProgress(
                    active = root.optJSONObject("active_session")?.let(::sessionFromJson),
                    attempts = jsonObjects(root.optJSONArray("attempts")).map(::attemptFromJson),
                    mastery = jsonObjects(root.optJSONArray("mastery")).map(::masteryFromJson),
                    credits = jsonObjects(root.optJSONArray("credits")).map(::creditFromJson),
                    simulations = jsonObjects(root.optJSONArray("simulations")).map(::simulationFromJson),
                    settings = root.optJSONObject("settings")?.let(::settingsFromJson),
                )
            }.getOrNull() ?: return@withContext false
            val before = exportBackup()
            dao.upsertSnapshot(ProgressSnapshotEntity("pre_restore", before, sha256(before), System.currentTimeMillis()))
            runCatching {
                database.withTransaction {
                    dao.clearSessions(); dao.clearAttempts(); dao.clearMastery(); dao.clearCredits(); dao.clearSimulations()
                    parsed.active?.let { dao.upsertSession(it) }
                    if (parsed.attempts.isNotEmpty()) dao.insertAttempts(parsed.attempts)
                    parsed.mastery.forEach { dao.upsertMastery(it) }
                    if (parsed.credits.isNotEmpty()) dao.insertCredits(parsed.credits)
                    parsed.simulations.forEach { dao.upsertSimulation(it) }
                    parsed.settings?.let { dao.upsertSettings(it) }
                }
            }.isSuccess
        }
    }

    override fun close() = bank.close()

    private data class RestoredProgress(
        val active: ActiveSessionEntity?,
        val attempts: List<AttemptEntity>,
        val mastery: List<MasteryEntity>,
        val credits: List<DueCreditEntity>,
        val simulations: List<SimulationResultEntity>,
        val settings: AppSettingsEntity?,
    )

    private fun jsonStringList(raw: String): List<String> {
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) add(array.getString(i)) }
    }

    private fun jsonObject(raw: String): JSONObject = runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
    private fun mapJson(values: Map<String, Double>) = JSONObject().also { o -> values.forEach { (k, v) -> o.put(k, v) } }
    private fun jsonObjects(array: JSONArray?): List<JSONObject> = if (array == null) emptyList() else buildList {
        for (i in 0 until array.length()) add(array.getJSONObject(i))
    }
    private fun sha256(raw: String) = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun sessionJson(x: ActiveSessionEntity) = JSONObject().apply {
        put("name", x.name); put("date", x.date); put("mode", x.mode); put("pool", x.pool); put("phase", x.phase)
        put("questionIdsJson", x.questionIdsJson); put("position", x.position); put("reviewPosition", x.reviewPosition)
        put("answersJson", x.answersJson); put("confidenceJson", x.confidenceJson); put("optionOrdersJson", x.optionOrdersJson)
        put("flagsJson", x.flagsJson); put("elapsedJson", x.elapsedJson); put("analysesSeenJson", x.analysesSeenJson)
        put("errorTypesJson", x.errorTypesJson); put("startedEpochMs", x.startedEpochMs); put("updatedEpochMs", x.updatedEpochMs)
        put("cueShown", x.cueShown)
    }
    private fun sessionFromJson(o: JSONObject) = ActiveSessionEntity(
        o.getString("name"), o.getString("date"), o.getString("mode"), o.getString("pool"), o.getString("phase"),
        o.getString("questionIdsJson"), o.getInt("position"), o.getInt("reviewPosition"), o.getString("answersJson"),
        o.getString("confidenceJson"), o.getString("optionOrdersJson"), o.getString("flagsJson"), o.getString("elapsedJson"),
        o.getString("analysesSeenJson"), o.getString("errorTypesJson"), o.getLong("startedEpochMs"), o.getLong("updatedEpochMs"),
        o.optBoolean("cueShown"),
    )
    private fun attemptJson(x: AttemptEntity) = JSONObject().apply {
        put("questionId", x.questionId); put("sessionName", x.sessionName); put("date", x.date); put("subject", x.subject)
        put("microtopic", x.microtopic); put("pool", x.pool); put("selectedOriginal", x.selectedOriginal ?: JSONObject.NULL)
        put("correctIndex", x.correctIndex); put("status", x.status); put("confidence", x.confidence)
        put("errorType", x.errorType ?: JSONObject.NULL); put("solveSeconds", x.solveSeconds)
        put("difficulty", x.difficulty); put("scenarioFamily", x.scenarioFamily)
        put("strictOrVerifiedReal", x.strictOrVerifiedReal); put("spacedRetrieval", x.spacedRetrieval)
        put("createdEpochMs", x.createdEpochMs)
    }
    private fun attemptFromJson(o: JSONObject) = AttemptEntity(
        questionId = o.getString("questionId"), sessionName = o.getString("sessionName"), date = o.getString("date"),
        subject = o.getString("subject"), microtopic = o.getString("microtopic"), pool = o.getString("pool"),
        selectedOriginal = if (o.isNull("selectedOriginal")) null else o.getInt("selectedOriginal"), correctIndex = o.getInt("correctIndex"),
        status = o.getString("status"), confidence = o.getString("confidence"),
        errorType = if (o.isNull("errorType")) null else o.getString("errorType"), solveSeconds = o.getInt("solveSeconds"),
        difficulty = o.optInt("difficulty", 2), scenarioFamily = o.optString("scenarioFamily"),
        strictOrVerifiedReal = o.optBoolean("strictOrVerifiedReal"), spacedRetrieval = o.optBoolean("spacedRetrieval"),
        createdEpochMs = o.getLong("createdEpochMs"),
    )
    private fun masteryJson(x: MasteryEntity) = JSONObject().apply {
        put("microtopic", x.microtopic); put("subject", x.subject); put("mastery", x.mastery); put("memoryStrength", x.memoryStrength)
        put("attempts", x.attempts); put("distinctQuestions", x.distinctQuestions); put("examAttempts", x.examAttempts)
        put("confidentCorrectStreak", x.confidentCorrectStreak); put("recurringError", x.recurringError ?: JSONObject.NULL)
        put("lastAttemptEpochMs", x.lastAttemptEpochMs); put("nextDueEpochMs", x.nextDueEpochMs)
    }
    private fun masteryFromJson(o: JSONObject) = MasteryEntity(
        o.getString("microtopic"), o.getString("subject"), o.getDouble("mastery"), o.getDouble("memoryStrength"),
        o.getInt("attempts"), o.getInt("distinctQuestions"), o.getInt("examAttempts"), o.getInt("confidentCorrectStreak"),
        if (o.isNull("recurringError")) null else o.getString("recurringError"), o.getLong("lastAttemptEpochMs"), o.getLong("nextDueEpochMs"),
    )
    private fun creditJson(x: DueCreditEntity) = JSONObject().apply {
        put("microtopic", x.microtopic); put("reason", x.reason); put("priority", x.priority); put("remaining", x.remaining)
        put("dueEpochMs", x.dueEpochMs); put("sourceQuestionId", x.sourceQuestionId); put("createdEpochMs", x.createdEpochMs); put("consumed", x.consumed)
    }
    private fun creditFromJson(o: JSONObject) = DueCreditEntity(
        microtopic = o.getString("microtopic"), reason = o.getString("reason"), priority = o.getInt("priority"), remaining = o.getInt("remaining"),
        dueEpochMs = o.getLong("dueEpochMs"), sourceQuestionId = o.getString("sourceQuestionId"), createdEpochMs = o.getLong("createdEpochMs"),
        consumed = o.optBoolean("consumed"),
    )
    private fun simulationJson(x: SimulationResultEntity) = JSONObject().apply {
        put("pool", x.pool); put("date", x.date); put("questionIdsJson", x.questionIdsJson); put("subjectReliableJson", x.subjectReliableJson)
        put("durationSeconds", x.durationSeconds); put("leakCount", x.leakCount); put("passed", x.passed)
        put("remediationJson", x.remediationJson)
        put("reviewedEpochMs", x.reviewedEpochMs ?: JSONObject.NULL)
    }
    private fun simulationFromJson(o: JSONObject) = SimulationResultEntity(
        o.getString("pool"), o.getString("date"), o.getString("questionIdsJson"), o.getString("subjectReliableJson"),
        o.getInt("durationSeconds"), o.getInt("leakCount"), o.getBoolean("passed"), o.optString("remediationJson", "{}"),
        if (o.isNull("reviewedEpochMs")) null else o.optLong("reviewedEpochMs"),
    )
    private fun settingsJson(x: AppSettingsEntity) = JSONObject().apply {
        put("theme", x.theme); put("studyMode", x.studyMode); put("motion", x.motion); put("textScale", x.textScale)
        put("focusMode", x.focusMode); put("longStudyMode", x.longStudyMode); put("breaksEnabled", x.breaksEnabled); put("breakEvery", x.breakEvery)
    }
    private fun settingsFromJson(o: JSONObject) = AppSettingsEntity(
        theme = o.getString("theme"), studyMode = o.getString("studyMode"), motion = o.getString("motion"), textScale = o.getInt("textScale").coerceIn(90, 140),
        focusMode = o.getBoolean("focusMode"), longStudyMode = o.getBoolean("longStudyMode"), breaksEnabled = o.getBoolean("breaksEnabled"),
        breakEvery = o.getInt("breakEvery").coerceIn(20, 90),
    )
}
